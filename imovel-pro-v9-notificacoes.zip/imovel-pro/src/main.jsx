import React from 'react'
import { registerSW } from 'virtual:pwa-register'

// Registra o Service Worker e mostra prompt de instalação
registerSW({ immediate: true })
import ReactDOM from 'react-dom/client'
import Root from './Root.jsx'
import Captacao from './Captacao.jsx'

// Detecta rota de captação por parâmetro OU por path /captacao
const params = new URLSearchParams(window.location.search);
const pathname = window.location.pathname;
const isCaptacao =
  params.has('captacao') ||
  pathname.startsWith('/captacao') ||  // cobre /captacao e /captacao/
  (params.has('uid') && params.has('wa')); // link gerado pelo app (qualquer path)

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    {isCaptacao ? <Captacao /> : <Root />}
  </React.StrictMode>
)
