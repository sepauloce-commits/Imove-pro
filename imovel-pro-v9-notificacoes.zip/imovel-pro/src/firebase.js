import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDOYzoLywqI08udV1lN2HUC71Q17M7K0g4",
  authDomain: "imove-pro-4d827.firebaseapp.com",
  projectId: "imove-pro-4d827",
  storageBucket: "imove-pro-4d827.firebasestorage.app",
  messagingSenderId: "271774421747",
  appId: "1:271774421747:web:f3d7e84971b52d724f5d86"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
