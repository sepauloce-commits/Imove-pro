import { useState } from "react";
import { db } from "./firebase";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";

const C = {
  bg: "#0A0E1A", card: "#111827", border: "#1E293B",
  accent: "#F59E0B", green: "#10B981",
  text: "#F1F5F9", muted: "#64748B", surface: "#1E293B",
};

export default function Captacao() {
  const params = new URLSearchParams(window.location.search);
  // Compatível com /captacao?uid=... e /?captacao=1&uid=...
  const CORRETOR_UID = params.get("uid")    || "sem-corretor";
  const CORRETOR_WA  = params.get("wa")     || "";
  const origem       = params.get("origem") || "Link";
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    nome: "", telefone: "", email: "",
    interesse: "Comprar", tipo: "Apartamento",
    faixa: "Até R$ 300 mil", bairro: "", mensagem: ""
  });

  const salvar = async () => {
    if (!form.nome.trim() || !form.telefone.trim()) {
      alert("Preencha nome e telefone!"); return;
    }
    setSaving(true);
    try {
      await addDoc(collection(db, "negocios"), {
        nome: form.nome,
        telefone: form.telefone,
        email: form.email || "",
        interesse: `${form.tipo} para ${form.interesse} - ${form.faixa}${form.bairro ? " - " + form.bairro : ""}`,
        valorEstimado: 0,
        etapa: "lead",
        tags: ["quente"],
        origem: origem,
        observacoes: form.mensagem || `Lead captado via ${origem}`,
        uid: CORRETOR_UID,
        createdAt: serverTimestamp(),
        ultimoContato: serverTimestamp(),
      });

      const msg = `🎯 *Novo Lead — ImóvelPro!*\n\n👤 Nome: ${form.nome}\n📱 WhatsApp: ${form.telefone}\n🏠 Interesse: ${form.interesse} ${form.tipo}\n💰 Faixa: ${form.faixa}\n📍 Bairro: ${form.bairro || "Não informado"}\n📡 Origem: ${origem}${form.mensagem ? "\n💬 " + form.mensagem : ""}`;
      setTimeout(() => window.open(`https://wa.me/${CORRETOR_WA}?text=${encodeURIComponent(msg)}`, "_blank"), 500);
      setStep(2);
    } catch(e) {
      alert("Erro ao salvar: " + e.message);
    }
    setSaving(false);
  };

  if (step === 2) return (
    <div style={{ background: C.bg, minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "system-ui" }}>
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 24, padding: 40, maxWidth: 400, width: "100%", textAlign: "center" }}>
        <div style={{ width: 72, height: 72, background: C.green, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, margin: "0 auto 20px" }}>✓</div>
        <h2 style={{ color: C.text, fontSize: 22, fontWeight: 800, marginBottom: 10 }}>Recebido! 🎉</h2>
        <p style={{ color: C.muted, fontSize: 14, lineHeight: 1.6, marginBottom: 28 }}>
          Suas informações foram enviadas!<br />
          <strong style={{ color: C.text }}>Logo entraremos em contato. 😊</strong>
        </p>
        <a href={`https://wa.me/${CORRETOR_WA}?text=${encodeURIComponent(`Olá! Me cadastrei no formulário. Sou ${form.nome}, quero mais informações sobre imóveis!`)}`}
          target="_blank"
          style={{ display: "block", background: "#25D366", color: "#fff", borderRadius: 14, padding: 16, fontWeight: 800, fontSize: 16, textDecoration: "none" }}>
          💬 Falar no WhatsApp agora
        </a>
      </div>
    </div>
  );

  const F = ({ label, value, onChange, type="text", placeholder="" }) => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 14px", color: C.text, fontSize: 15, boxSizing: "border-box", outline: "none" }} />
    </div>
  );

  const S = ({ label, value, onChange, opts }) => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 5, fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</label>
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 14px", color: C.text, fontSize: 15 }}>
        {opts.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "system-ui" }}>
      <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ width: 38, height: 38, background: C.accent, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>🏡</div>
        <div>
          <div style={{ color: C.text, fontWeight: 800, fontSize: 15 }}>Encontre seu Imóvel</div>
          <div style={{ color: C.muted, fontSize: 11 }}>Preencha e te ajudamos!</div>
        </div>
        <div style={{ marginLeft: "auto", background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 20, padding: "4px 12px", fontSize: 11, color: C.accent, fontWeight: 600 }}>
          {origem.toLowerCase().includes("instagram") || origem.toLowerCase().includes("ig") ? "📸" : origem.toLowerCase().includes("facebook") || origem.toLowerCase().includes("fb") ? "📘" : "💬"} {origem}
        </div>
      </div>

      <div style={{ padding: "20px 16px", maxWidth: 460, margin: "0 auto" }}>
        <h2 style={{ color: C.text, fontSize: 20, fontWeight: 800, marginBottom: 4 }}>Seus dados de contato</h2>
        <p style={{ color: C.muted, fontSize: 13, marginBottom: 20 }}>Rápido e sem compromisso! 🏡</p>

        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 18, padding: 20, marginBottom: 14 }}>
          <F label="Nome Completo *" value={form.nome} onChange={v => setForm({...form, nome:v})} placeholder="Ex: João da Silva" />
          <F label="WhatsApp *" value={form.telefone} onChange={v => setForm({...form, telefone:v})} placeholder="(85) 99999-0000" />
          <F label="E-mail (opcional)" type="email" value={form.email} onChange={v => setForm({...form, email:v})} placeholder="seu@email.com" />
        </div>

        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 18, padding: 20, marginBottom: 14 }}>
          <div style={{ color: C.text, fontWeight: 700, fontSize: 14, marginBottom: 14 }}>🏠 O que você procura?</div>

          <div style={{ marginBottom: 14 }}>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 8, fontWeight: 700, textTransform: "uppercase" }}>Objetivo</label>
            <div style={{ display: "flex", gap: 8 }}>
              {[["🏠","Comprar"],["🔑","Alugar"],["📈","Investir"]].map(([ic, op]) => (
                <button key={op} onClick={() => setForm({...form, interesse:op})}
                  style={{ flex: 1, padding: "10px 0", background: form.interesse===op ? C.accent : C.surface, color: form.interesse===op ? "#0A0E1A" : C.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 12 }}>
                  {ic} {op}
                </button>
              ))}
            </div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 8, fontWeight: 700, textTransform: "uppercase" }}>Tipo de Imóvel</label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[["🏢","Apartamento"],["🏡","Casa"],["🏬","Comercial"],["🌿","Terreno"]].map(([ic, tp]) => (
                <button key={tp} onClick={() => setForm({...form, tipo:tp})}
                  style={{ flex: "1 1 40%", padding: "10px 0", background: form.tipo===tp ? C.accent : C.surface, color: form.tipo===tp ? "#0A0E1A" : C.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 12 }}>
                  {ic} {tp}
                </button>
              ))}
            </div>
          </div>

          <S label="Faixa de Preço" value={form.faixa} onChange={v => setForm({...form, faixa:v})}
            opts={["Até R$ 200 mil","Até R$ 300 mil","Até R$ 500 mil","Até R$ 800 mil","Até R$ 1 milhão","Acima de R$ 1 milhão"]} />
          <F label="Bairro / Região" value={form.bairro} onChange={v => setForm({...form, bairro:v})} placeholder="Ex: Meireles, Aldeota..." />
        </div>

        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 18, padding: 20, marginBottom: 20 }}>
          <F label="Mensagem (opcional)" value={form.mensagem} onChange={v => setForm({...form, mensagem:v})} placeholder="Algum detalhe extra..." />
        </div>

        <button onClick={salvar} disabled={saving}
          style={{ width: "100%", background: C.accent, color: "#0A0E1A", border: "none", borderRadius: 16, padding: 18, fontWeight: 800, fontSize: 17, cursor: saving ? "not-allowed" : "pointer", opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Enviando..." : "🚀 Quero ser Atendido!"}
        </button>
        <p style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 10 }}>🔒 Seus dados são privados.</p>
      </div>
    </div>
  );
}
