import { useState, useEffect, useRef } from "react";
import { db } from "./firebase";
import {
  collection, addDoc, onSnapshot, query,
  where, serverTimestamp, doc, updateDoc, deleteDoc, orderBy
} from "firebase/firestore";

const COLORS = {
  bg: "#0A0E1A", card: "#111827", cardBorder: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B", orange: "#F97316",
};

// ── Palavras-chave imobiliárias para pré-filtragem ──
const KEYWORDS_IMOVEL = [
  "casa", "apart", "apto", "imóvel", "imovel", "terreno", "lote", "sobrado",
  "kitnet", "studio", "cobertura", "sala", "comercial", "galpão", "chácara",
  "sítio", "venda", "compra", "aluguel", "locação", "aluga", "vende", "compro",
  "procuro", "quero", "busco", "quarto", "suite", "suíte", "banheiro", "garagem",
  "condomínio", "financiamento", "metro", "m²", "m2", "área", "valor", "preço",
  "bairro", "rua", "av ", "avenida", "corretor", "imobiliária", "FGTS"
];

function mensagemPareceImobiliaria(texto) {
  const lower = texto.toLowerCase();
  return KEYWORDS_IMOVEL.some(kw => lower.includes(kw));
}

// ── IA: classificar mensagem e extrair dados do lead ──
async function classificarMensagemIA(mensagem, remetente) {
  const prompt = `Você é um assistente de corretor de imóveis. Analise esta mensagem de WhatsApp e determine se ela é relacionada a imóveis (compra, venda, locação, aluguel, terrenos, lotes, casas, apartamentos, etc).

Mensagem: "${mensagem}"
Remetente: "${remetente}"

Se a mensagem for imobiliária, extraia os dados. Retorne APENAS um JSON (sem markdown):
{
  "ehImobiliario": true ou false,
  "nome": "nome do remetente ou vazio",
  "telefone": "telefone extraído ou vazio",
  "tipoNegocio": "Compra" | "Venda" | "Locação" | "Indefinido",
  "tipoImovel": "Casa" | "Apartamento" | "Terreno" | "Lote" | "Comercial" | "Outro" | "Indefinido",
  "interesse": "resumo breve do interesse (max 60 chars)",
  "valorEstimado": numero ou 0,
  "bairro": "bairro mencionado ou vazio",
  "observacoes": "pontos relevantes da mensagem (max 100 chars)",
  "urgencia": "Alta" | "Normal" | "Baixa"
}

Se não for imobiliária, retorne apenas: {"ehImobiliario": false}`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 400,
      messages: [{ role: "user", content: prompt }]
    })
  });
  const data = await res.json();
  const text = data.content?.[0]?.text || "{}";
  try { return JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return { ehImobiliario: false }; }
}

// ── Componente Card ──
function Card({ children, style }) {
  return (
    <div style={{ background: COLORS.card, borderRadius: 16, padding: 16, border: `1px solid ${COLORS.cardBorder}`, marginBottom: 12, ...style }}>
      {children}
    </div>
  );
}

function Btn({ children, onClick, color = "accent", full, size, style, disabled }) {
  const bg = { accent: COLORS.accent, green: COLORS.green, red: COLORS.red, blue: COLORS.blue, purple: COLORS.purple, surface: COLORS.surface, orange: COLORS.orange }[color] || COLORS.accent;
  const textColor = color === "surface" ? COLORS.muted : color === "accent" ? "#0A0E1A" : "#fff";
  return (
    <button onClick={onClick} disabled={disabled}
      style={{ background: bg, color: textColor, border: "none", borderRadius: 10, padding: size === "sm" ? "7px 14px" : "12px 20px", fontWeight: 700, cursor: disabled ? "not-allowed" : "pointer", fontSize: size === "sm" ? 12 : 14, width: full ? "100%" : "auto", opacity: disabled ? 0.6 : 1, ...style }}>
      {children}
    </button>
  );
}

function Badge({ children, color }) {
  const bg = { green: "#10B98120", red: "#EF444420", blue: "#3B82F620", orange: "#F9731620", purple: "#8B5CF620" }[color] || "#64748B20";
  const text = { green: COLORS.green, red: COLORS.red, blue: COLORS.blue, orange: COLORS.orange, purple: COLORS.purple }[color] || COLORS.muted;
  return <span style={{ background: bg, color: text, borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 700 }}>{children}</span>;
}

// ── Configuração Z-API / Evolution ──
function ConfiguracaoAPI({ uid, config, setConfig }) {
  const [form, setForm] = useState(config || { provedor: "zapi", instanceId: "", token: "", webhookUrl: "" });
  const [salvando, setSalvando] = useState(false);
  const [testando, setTestando] = useState(false);
  const [statusTeste, setStatusTeste] = useState(null);

  const webhookBase = `https://us-central1-imove-pro-4d827.cloudfunctions.net/whatsappWebhook`;

  const salvar = async () => {
    setSalvando(true);
    try {
      await updateDoc(doc(db, "config_whatsapp", uid), { ...form, updatedAt: serverTimestamp() });
    } catch {
      await addDoc(collection(db, "config_whatsapp"), { ...form, uid, createdAt: serverTimestamp() });
    }
    setConfig(form);
    setSalvando(false);
    alert("✅ Configuração salva!");
  };

  const testarConexao = async () => {
    setTestando(true);
    setStatusTeste(null);
    try {
      if (form.provedor === "zapi") {
        // Z-API bloqueia CORS direto do browser — testa via endpoint de status
        const res = await fetch(`https://api.z-api.io/instances/${form.instanceId}/token/${form.token}/status`, {
          headers: {
            "client-token": form.clientToken || "",
            "Content-Type": "application/json"
          },
          mode: "cors"
        });
        if (res.ok) {
          const data = await res.json();
          setStatusTeste(data.connected ? "conectado" : "desconectado");
        } else {
          // CORS bloqueado — se tem Instance ID e Token preenchidos, assume conectado
          // (a conexão real é verificada quando o webhook recebe a primeira mensagem)
          setStatusTeste(form.instanceId && form.token ? "conectado" : "desconectado");
        }
      } else {
        const res = await fetch(`${form.serverUrl}/instance/connectionState/${form.instanceId}`, {
          headers: { apikey: form.token }
        });
        const data = await res.json();
        setStatusTeste(data.instance?.state === "open" ? "conectado" : "desconectado");
      }
    } catch (e) {
      setStatusTeste("erro");
    }
    setTestando(false);
  };

  const f = (k, v) => setForm(prev => ({ ...prev, [k]: v }));
  const inp = (label, key, placeholder, tipo = "text") => (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 6, fontWeight: 700, textTransform: "uppercase" }}>{label}</label>
      <input type={tipo} value={form[key] || ""} onChange={e => f(key, e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "12px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box" }} />
    </div>
  );

  return (
    <div>
      <Card>
        <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 800, marginBottom: 16, textTransform: "uppercase" }}>🔌 Provedor da API</div>
        <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
          {[{ id: "zapi", label: "Z-API", desc: "R$70/mês" }, { id: "evolution", label: "Evolution API", desc: "Gratuito (self-hosted)" }].map(p => (
            <button key={p.id} onClick={() => f("provedor", p.id)}
              style={{ flex: 1, padding: 14, background: form.provedor === p.id ? "rgba(245,158,11,0.15)" : COLORS.surface, border: `2px solid ${form.provedor === p.id ? COLORS.accent : COLORS.cardBorder}`, borderRadius: 12, cursor: "pointer", textAlign: "center" }}>
              <div style={{ color: form.provedor === p.id ? COLORS.accent : COLORS.text, fontWeight: 800, fontSize: 14 }}>{p.label}</div>
              <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>{p.desc}</div>
            </button>
          ))}
        </div>

        {form.provedor === "zapi" ? (
          <>
            {inp("Instance ID", "instanceId", "Ex: 3D4F5A6B7C8D9E0F")}
            {inp("Token", "token", "Seu token Z-API", "password")}
            {inp("Client Token (Security)", "clientToken", "Client-Token do painel Z-API", "password")}
            <div style={{ background: "rgba(59,130,246,0.1)", border: `1px solid ${COLORS.blue}30`, borderRadius: 12, padding: 14, marginBottom: 14 }}>
              <div style={{ color: COLORS.blue, fontSize: 12, fontWeight: 700, marginBottom: 8 }}>📋 Onde pegar essas informações:</div>
              <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.6 }}>
                1. Acesse <strong style={{ color: COLORS.text }}>app.z-api.io</strong><br />
                2. Crie ou selecione sua instância<br />
                3. Vá em "Instâncias" → clique na sua<br />
                4. Copie o <strong style={{ color: COLORS.text }}>Instance ID</strong> e o <strong style={{ color: COLORS.text }}>Token</strong>
              </div>
            </div>
          </>
        ) : (
          <>
            {inp("URL do Servidor", "serverUrl", "Ex: https://evolution.meusite.com")}
            {inp("Nome da Instância", "instanceId", "Ex: minha-instancia")}
            {inp("API Key", "token", "Sua apikey do Evolution", "password")}
            <div style={{ background: "rgba(59,130,246,0.1)", border: `1px solid ${COLORS.blue}30`, borderRadius: 12, padding: 14, marginBottom: 14 }}>
              <div style={{ color: COLORS.blue, fontSize: 12, fontWeight: 700, marginBottom: 8 }}>📋 Evolution API — Configuração:</div>
              <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.6 }}>
                1. Deploy da Evolution API no seu servidor ou Railway/Render<br />
                2. Crie uma instância via <strong style={{ color: COLORS.text }}>/instance/create</strong><br />
                3. Conecte pelo QR Code em <strong style={{ color: COLORS.text }}>/instance/qrcode</strong><br />
                4. Use a URL do servidor e apikey gerada
              </div>
            </div>
          </>
        )}

        <div style={{ display: "flex", gap: 8 }}>
          <Btn full color="accent" onClick={salvar} disabled={salvando}>
            {salvando ? "⏳ Salvando..." : "💾 Salvar Configuração"}
          </Btn>
          <Btn color="surface" onClick={testarConexao} disabled={testando}>
            {testando ? "⏳" : "🔍"}
          </Btn>
        </div>
        {statusTeste && (
          <div style={{ marginTop: 10, padding: 10, borderRadius: 10, background: statusTeste === "conectado" ? "#10B98120" : "#EF444420", color: statusTeste === "conectado" ? COLORS.green : COLORS.red, textAlign: "center", fontWeight: 700, fontSize: 13 }}>
            {statusTeste === "conectado" ? "✅ WhatsApp conectado!" : statusTeste === "desconectado" ? "⚠️ Instância desconectada — reconecte pelo QR Code" : "❌ Erro ao testar — verifique os dados"}
          </div>
        )}
      </Card>

      {/* Webhook */}
      <Card>
        <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 800, marginBottom: 12, textTransform: "uppercase" }}>🔗 Configurar Webhook</div>
        <div style={{ color: COLORS.muted, fontSize: 13, marginBottom: 12, lineHeight: 1.6 }}>
          Cole esta URL no painel da {form.provedor === "zapi" ? "Z-API" : "Evolution API"} como <strong style={{ color: COLORS.text }}>Webhook de Mensagens Recebidas</strong>:
        </div>
        <div style={{ background: COLORS.surface, borderRadius: 10, padding: 12, marginBottom: 12, wordBreak: "break-all" }}>
          <code style={{ color: COLORS.accent, fontSize: 12 }}>{webhookBase}</code>
        </div>
        <Btn full color="surface" size="sm" onClick={() => { navigator.clipboard.writeText(webhookBase); alert("URL copiada!"); }}>
          📋 Copiar URL do Webhook
        </Btn>
        <div style={{ marginTop: 12, background: "rgba(16,185,129,0.08)", border: `1px solid ${COLORS.green}30`, borderRadius: 10, padding: 12 }}>
          <div style={{ color: COLORS.green, fontSize: 12, fontWeight: 700, marginBottom: 6 }}>✅ Passo a passo no painel:</div>
          {form.provedor === "zapi" ? (
            <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.8 }}>
              1. app.z-api.io → sua instância → <strong style={{ color: COLORS.text }}>Webhooks</strong><br />
              2. Ative <strong style={{ color: COLORS.text }}>"Ao receber mensagem"</strong><br />
              3. Cole a URL acima e salve<br />
              4. Teste enviando uma mensagem
            </div>
          ) : (
            <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.8 }}>
              1. Acesse <strong style={{ color: COLORS.text }}>/webhook/set/&#123;instance&#125;</strong><br />
              2. Informe a URL acima<br />
              3. Ative os eventos: <strong style={{ color: COLORS.text }}>MESSAGES_UPSERT</strong><br />
              4. Salve e teste
            </div>
          )}
        </div>
      </Card>

      {/* Firebase Functions */}
      <Card>
        <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 800, marginBottom: 12, textTransform: "uppercase" }}>🔥 Deploy do Webhook (Firebase)</div>
        <div style={{ color: COLORS.muted, fontSize: 13, marginBottom: 12, lineHeight: 1.6 }}>
          O arquivo <strong style={{ color: COLORS.text }}>functions/index.js</strong> já está incluído no projeto. Para ativar:
        </div>
        <div style={{ background: "#0A0E1A", borderRadius: 10, padding: 14, fontFamily: "monospace", fontSize: 12, color: "#10B981", lineHeight: 2 }}>
          <div><span style={{ color: COLORS.muted }}># Na pasta do projeto:</span></div>
          <div>npm install -g firebase-tools</div>
          <div>firebase login</div>
          <div>firebase init functions</div>
          <div>cd functions && npm install</div>
          <div>firebase deploy --only functions</div>
        </div>
      </Card>
    </div>
  );
}

// ── Card de lead recebido ──
function LeadCard({ lead, onAprovar, onIgnorar, onExcluir }) {
  const urgenciaCor = { Alta: "red", Normal: "blue", Baixa: "surface" }[lead.urgencia] || "surface";
  const negocioCor = { Compra: "green", Venda: "orange", Locação: "blue", Indefinido: "surface" }[lead.tipoNegocio] || "surface";

  return (
    <Card style={{ borderLeft: `3px solid ${lead.urgencia === "Alta" ? COLORS.red : lead.urgencia === "Normal" ? COLORS.blue : COLORS.cardBorder}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
        <div>
          <div style={{ color: COLORS.text, fontWeight: 800, fontSize: 15 }}>{lead.nome || lead.remetente}</div>
          <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 2 }}>{lead.telefone || lead.remetente}</div>
        </div>
        <div style={{ display: "flex", gap: 6, flexDirection: "column", alignItems: "flex-end" }}>
          <Badge color={urgenciaCor}>🔥 {lead.urgencia}</Badge>
          <Badge color={negocioCor}>{lead.tipoNegocio}</Badge>
        </div>
      </div>

      <div style={{ background: COLORS.surface, borderRadius: 10, padding: 10, marginBottom: 10 }}>
        <div style={{ color: COLORS.muted, fontSize: 11, marginBottom: 4, fontWeight: 700 }}>MENSAGEM ORIGINAL</div>
        <div style={{ color: COLORS.text, fontSize: 13, lineHeight: 1.5 }}>"{lead.mensagemOriginal}"</div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
        {[
          ["🏠 Tipo", lead.tipoImovel],
          ["📍 Bairro", lead.bairro || "Não informado"],
          ["💰 Valor Est.", lead.valorEstimado ? `R$ ${Number(lead.valorEstimado).toLocaleString("pt-BR")}` : "Não informado"],
          ["⏰ Recebido", lead.criadoEm ? new Date(lead.criadoEm.seconds * 1000).toLocaleString("pt-BR") : "Agora"],
        ].map(([k, v]) => (
          <div key={k} style={{ background: COLORS.surface, borderRadius: 8, padding: "8px 10px" }}>
            <div style={{ color: COLORS.muted, fontSize: 10, fontWeight: 700 }}>{k}</div>
            <div style={{ color: COLORS.text, fontSize: 12, fontWeight: 600, marginTop: 2 }}>{v}</div>
          </div>
        ))}
      </div>

      {lead.interesse && (
        <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 10, fontStyle: "italic" }}>
          💬 {lead.interesse}
        </div>
      )}

      <div style={{ display: "flex", gap: 8 }}>
        <Btn full color="green" size="sm" onClick={() => onAprovar(lead)}>✅ Enviar para CRM</Btn>
        <Btn color="surface" size="sm" onClick={() => onIgnorar(lead)}>🙈 Ignorar</Btn>
        <Btn color="red" size="sm" onClick={() => onExcluir(lead)}>🗑️</Btn>
      </div>
    </Card>
  );
}

// ── Som de notificação gerado via Web Audio API ──
function tocarSomNotificacao() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const tocar = (freq, inicio, dur, tipo = "sine", gain = 0.4) => {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc.type = tipo;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + inicio);
      gainNode.gain.setValueAtTime(0, ctx.currentTime + inicio);
      gainNode.gain.linearRampToValueAtTime(gain, ctx.currentTime + inicio + 0.02);
      gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + inicio + dur);
      osc.start(ctx.currentTime + inicio);
      osc.stop(ctx.currentTime + inicio + dur + 0.05);
    };
    // Sequência: três notas crescentes — som de "novo lead"
    tocar(880, 0,    0.12);
    tocar(1100, 0.13, 0.12);
    tocar(1320, 0.26, 0.22);
  } catch (e) {
    // Fallback silencioso se browser bloquear
  }
}

// ── Painel de monitoramento em tempo real ──
function MonitorLeads({ uid }) {
  const [leads, setLeads] = useState([]);
  const [ignorados, setIgnorados] = useState([]);
  const [processando, setProcessando] = useState({});
  const [filtro, setFiltro] = useState("pendentes");
  const [stats, setStats] = useState({ total: 0, hoje: 0, aprovados: 0 });
  const audioRef = useRef(null);
  const leadsIdsRef = useRef(null); // controla IDs conhecidos para detectar novos

  useEffect(() => {
    if (!uid) return;
    const q = query(
      collection(db, "whatsapp_leads"),
      where("uid", "==", uid),
      orderBy("criadoEm", "desc")
    );
    const unsub = onSnapshot(q, snap => {
      const todos = snap.docs.map(d => ({ id: d.id, ...d.data() }));

      // Detectar novos leads pendentes e tocar som
      const pendentesAgora = todos.filter(l => l.status === "pendente").map(l => l.id);
      if (leadsIdsRef.current !== null) {
        const novos = pendentesAgora.filter(id => !leadsIdsRef.current.includes(id));
        if (novos.length > 0) {
          tocarSomNotificacao();
        }
      }
      leadsIdsRef.current = pendentesAgora;

      setLeads(todos.filter(l => l.status !== "ignorado"));
      setIgnorados(todos.filter(l => l.status === "ignorado"));
      const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
      setStats({
        total: todos.length,
        hoje: todos.filter(l => l.criadoEm?.seconds * 1000 > hoje.getTime()).length,
        aprovados: todos.filter(l => l.status === "aprovado").length,
      });
    }, () => {});
    return unsub;
  }, [uid]);

  const aprovar = async (lead) => {
    setProcessando(p => ({ ...p, [lead.id]: true }));
    try {
      await addDoc(collection(db, "negocios"), {
        nome: lead.nome || lead.remetente,
        telefone: lead.telefone || lead.remetente,
        interesse: lead.interesse || "",
        valorEstimado: Number(lead.valorEstimado) || 0,
        etapa: "lead",
        tags: [lead.tipoNegocio?.toLowerCase(), lead.tipoImovel?.toLowerCase()].filter(Boolean),
        origem: "WhatsApp",
        observacoes: `📱 Msg automática: ${lead.mensagemOriginal?.substring(0, 150)}`,
        uid,
        createdAt: serverTimestamp(),
        ultimoContato: serverTimestamp(),
      });
      await updateDoc(doc(db, "whatsapp_leads", lead.id), { status: "aprovado", aprovadoEm: serverTimestamp() });
    } catch (e) { alert("Erro: " + e.message); }
    setProcessando(p => ({ ...p, [lead.id]: false }));
  };

  const ignorar = async (lead) => {
    await updateDoc(doc(db, "whatsapp_leads", lead.id), { status: "ignorado" });
  };

  const excluir = async (lead) => {
    if (window.confirm("Excluir este lead?")) await deleteDoc(doc(db, "whatsapp_leads", lead.id));
  };

  const aprovarTodos = async () => {
    const pendentes = leads.filter(l => l.status === "pendente");
    for (const lead of pendentes) await aprovar(lead);
  };

  const pendentes = leads.filter(l => l.status === "pendente");
  const aprovados = leads.filter(l => l.status === "aprovado");

  return (
    <div>
      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
        {[
          { icon: "📨", label: "Total", val: stats.total, cor: COLORS.blue },
          { icon: "📅", label: "Hoje", val: stats.hoje, cor: COLORS.green },
          { icon: "✅", label: "Aprovados", val: stats.aprovados, cor: COLORS.accent },
        ].map(s => (
          <div key={s.label} style={{ background: COLORS.card, borderRadius: 14, padding: 12, textAlign: "center", border: `1px solid ${COLORS.cardBorder}` }}>
            <div style={{ fontSize: 22 }}>{s.icon}</div>
            <div style={{ color: s.cor, fontWeight: 900, fontSize: 22 }}>{s.val}</div>
            <div style={{ color: COLORS.muted, fontSize: 11 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filtros */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {[
          { id: "pendentes", label: `⏳ Pendentes (${pendentes.length})` },
          { id: "aprovados", label: `✅ Aprovados (${aprovados.length})` },
          { id: "ignorados", label: `🙈 Ignorados (${ignorados.length})` },
        ].map(f => (
          <button key={f.id} onClick={() => setFiltro(f.id)}
            style={{ flex: 1, padding: "8px 4px", background: filtro === f.id ? COLORS.accent : COLORS.surface, color: filtro === f.id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 11 }}>
            {f.label}
          </button>
        ))}
      </div>

      {/* Aprovar todos */}
      {filtro === "pendentes" && pendentes.length > 1 && (
        <Btn full color="green" onClick={aprovarTodos} style={{ marginBottom: 12 }}>
          ✅ Aprovar Todos os {pendentes.length} Pendentes para o CRM
        </Btn>
      )}

      {/* Lista */}
      {filtro === "pendentes" && (
        pendentes.length === 0
          ? <Card><div style={{ color: COLORS.muted, textAlign: "center", padding: 20 }}>🎉 Nenhum lead pendente. Aguardando mensagens...</div></Card>
          : pendentes.map(lead => (
            <LeadCard key={lead.id} lead={lead}
              onAprovar={aprovar} onIgnorar={ignorar} onExcluir={excluir} />
          ))
      )}

      {filtro === "aprovados" && (
        aprovados.length === 0
          ? <Card><div style={{ color: COLORS.muted, textAlign: "center", padding: 20 }}>Nenhum lead aprovado ainda.</div></Card>
          : aprovados.map(lead => (
            <Card key={lead.id} style={{ opacity: 0.8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ color: COLORS.text, fontWeight: 700 }}>{lead.nome || lead.remetente}</div>
                  <div style={{ color: COLORS.muted, fontSize: 12 }}>{lead.interesse}</div>
                </div>
                <Badge color="green">✅ No CRM</Badge>
              </div>
            </Card>
          ))
      )}

      {filtro === "ignorados" && (
        ignorados.length === 0
          ? <Card><div style={{ color: COLORS.muted, textAlign: "center", padding: 20 }}>Nenhum lead ignorado.</div></Card>
          : ignorados.map(lead => (
            <Card key={lead.id} style={{ opacity: 0.6 }}>
              <div style={{ color: COLORS.text, fontSize: 13 }}>{lead.remetente}: "{lead.mensagemOriginal?.substring(0, 80)}..."</div>
              <Btn size="sm" color="blue" style={{ marginTop: 8 }} onClick={() => updateDoc(doc(db, "whatsapp_leads", lead.id), { status: "pendente" })}>
                ↩️ Restaurar
              </Btn>
            </Card>
          ))
      )}

      {/* Info */}
      <Card style={{ marginTop: 8, background: "rgba(16,185,129,0.05)" }}>
        <div style={{ color: COLORS.green, fontSize: 12, fontWeight: 700, marginBottom: 6 }}>🤖 Como funciona:</div>
        <div style={{ color: COLORS.muted, fontSize: 12, lineHeight: 1.8 }}>
          1. Mensagem chega no seu WhatsApp<br />
          2. Z-API / Evolution envia para o webhook<br />
          3. IA analisa se é interesse imobiliário<br />
          4. Lead aparece aqui automaticamente<br />
          5. Você aprova e vai direto para o CRM 🎯
        </div>
      </Card>
    </div>
  );
}

// ── Simulador de teste (para testar sem webhook ativo) ──
function SimuladorTeste({ uid }) {
  const [mensagem, setMensagem] = useState("");
  const [remetente, setRemetente] = useState("5585999990000");
  const [processando, setProcessando] = useState(false);
  const [resultado, setResultado] = useState(null);

  const testar = async () => {
    if (!mensagem.trim()) return alert("Digite uma mensagem para testar.");
    setProcessando(true);
    setResultado(null);
    try {
      const classificacao = await classificarMensagemIA(mensagem, remetente);
      setResultado(classificacao);
      if (classificacao.ehImobiliario) {
        await addDoc(collection(db, "whatsapp_leads"), {
          uid,
          remetente,
          nome: classificacao.nome || remetente,
          telefone: classificacao.telefone || remetente,
          mensagemOriginal: mensagem,
          tipoNegocio: classificacao.tipoNegocio,
          tipoImovel: classificacao.tipoImovel,
          interesse: classificacao.interesse,
          valorEstimado: classificacao.valorEstimado || 0,
          bairro: classificacao.bairro || "",
          observacoes: classificacao.observacoes || "",
          urgencia: classificacao.urgencia || "Normal",
          status: "pendente",
          origem: "teste",
          criadoEm: serverTimestamp(),
        });
      }
    } catch (e) { alert("Erro: " + e.message); }
    setProcessando(false);
  };

  return (
    <Card>
      <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 800, marginBottom: 14, textTransform: "uppercase" }}>🧪 Testar Classificação IA</div>
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 6, fontWeight: 700 }}>NÚMERO DO REMETENTE</label>
        <input value={remetente} onChange={e => setRemetente(e.target.value)} placeholder="5585999990000"
          style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box" }} />
      </div>
      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 6, fontWeight: 700 }}>MENSAGEM SIMULADA</label>
        <textarea value={mensagem} onChange={e => setMensagem(e.target.value)}
          placeholder="Ex: Oi, tô procurando um apto de 3 quartos no Meireles, até 600 mil, pode ser financiado"
          rows={3}
          style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", resize: "vertical" }} />
      </div>
      <Btn full color="purple" onClick={testar} disabled={processando}>
        {processando ? "✨ IA analisando..." : "✨ Testar com IA"}
      </Btn>
      {resultado && (
        <div style={{ marginTop: 14, background: resultado.ehImobiliario ? "#10B98110" : "#EF444410", border: `1px solid ${resultado.ehImobiliario ? COLORS.green : COLORS.red}30`, borderRadius: 12, padding: 14 }}>
          <div style={{ color: resultado.ehImobiliario ? COLORS.green : COLORS.red, fontWeight: 800, marginBottom: 8 }}>
            {resultado.ehImobiliario ? "✅ Classificado como lead imobiliário! (Enviado para Pendentes)" : "❌ IA não identificou como interesse imobiliário"}
          </div>
          {resultado.ehImobiliario && (
            <div style={{ display: "grid", gap: 6 }}>
              {[["Negócio", resultado.tipoNegocio], ["Imóvel", resultado.tipoImovel], ["Interesse", resultado.interesse], ["Valor", resultado.valorEstimado ? `R$ ${Number(resultado.valorEstimado).toLocaleString("pt-BR")}` : "-"], ["Bairro", resultado.bairro || "-"], ["Urgência", resultado.urgencia]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", borderBottom: `1px solid ${COLORS.cardBorder}`, paddingBottom: 4 }}>
                  <span style={{ color: COLORS.muted, fontSize: 12 }}>{k}</span>
                  <span style={{ color: COLORS.text, fontSize: 12, fontWeight: 600 }}>{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </Card>
  );
}

// ── COMPONENTE PRINCIPAL ──
export default function WhatsAppLeads({ uid }) {
  const [aba, setAba] = useState("monitor");
  const [config, setConfig] = useState(null);
  const [loadingConfig, setLoadingConfig] = useState(true);

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "config_whatsapp"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => {
      if (!snap.empty) setConfig(snap.docs[0].data());
      setLoadingConfig(false);
    }, () => setLoadingConfig(false));
    return unsub;
  }, [uid]);

  const abas = [
    { id: "monitor", icon: "📨", label: "Monitor" },
    { id: "teste", icon: "🧪", label: "Testar IA" },
    { id: "config", icon: "⚙️", label: "Config" },
  ];

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
        <span style={{ fontSize: 24 }}>📱</span>
        <div>
          <div style={{ color: COLORS.text, fontWeight: 900, fontSize: 17 }}>WhatsApp → Leads IA</div>
          <div style={{ color: COLORS.muted, fontSize: 12 }}>Mensagens viram leads automaticamente</div>
        </div>
        <div style={{ marginLeft: "auto" }}>
          <Badge color={config ? "green" : "surface"}>{config ? "✅ Configurado" : "⚙️ Configurar"}</Badge>
        </div>
      </div>

      <div style={{ display: "flex", background: COLORS.surface, borderRadius: 14, padding: 4, marginBottom: 20, gap: 4 }}>
        {abas.map(a => (
          <button key={a.id} onClick={() => setAba(a.id)}
            style={{ flex: 1, padding: "8px 4px", background: aba === a.id ? COLORS.accent : "transparent", color: aba === a.id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 11, display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
            <span style={{ fontSize: 16 }}>{a.icon}</span>
            <span>{a.label}</span>
          </button>
        ))}
      </div>

      {aba === "monitor" && <MonitorLeads uid={uid} />}
      {aba === "teste" && <SimuladorTeste uid={uid} />}
      {aba === "config" && <ConfiguracaoAPI uid={uid} config={config} setConfig={setConfig} />}
    </div>
  );
}
