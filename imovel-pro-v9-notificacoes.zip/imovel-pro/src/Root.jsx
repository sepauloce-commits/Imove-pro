import { useState, useEffect } from "react";
import { auth, db } from "./firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp } from "firebase/firestore";
import Auth from "./Auth.jsx";
import { tocarSomDinheiro } from "./sons";
import Assinatura from "./Assinatura.jsx";
import App from "./App.jsx";
import Admin from "./Admin.jsx";
import CorrespondentePro from "./CorrespondentePro.jsx";

// Coloque aqui o e-mail da sua conta de admin
const ADMIN_EMAILS = ["sepauloce@gmail.com"];

// ─── Detecta acesso de correspondente via URL ─────────────────────────────
// Exemplo de URL:  https://seu-app.com/?correspondente=ABC123processoId
function getCorrespondentId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("correspondente") || null;
}

export default function Root() {
  const [user, setUser] = useState(undefined); // undefined = carregando
  const [assinatura, setAssinatura] = useState(null); // null = carregando
  const [verificando, setVerificando] = useState(false);

  // Se a URL tiver ?correspondente=<id>, abre portal direto — sem login
  const correspondentId = getCorrespondentId();

  useEffect(() => {
    if (correspondentId) return; // não inicia auth listener se é portal
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        setVerificando(true);
        await verificarAssinatura(u);
        setVerificando(false);
      } else {
        setAssinatura(null);
      }
    });
    return () => unsub();
  }, []);

  const verificarAssinatura = async (u) => {
    try {
      const ref = doc(db, "assinaturas", u.uid);
      const snap = await getDoc(ref);
      if (snap.exists()) {
        const data = snap.data();
        // Verificar se assinatura está ativa
        const agora = new Date();
        const vencimento = data.vencimento?.toDate?.() || null;
        const ativa = data.status === "ativa" && (!vencimento || vencimento > agora);
        setAssinatura({ ...data, ativa });
      } else {
        // Criar registro de assinatura trial (7 dias grátis)
        const vencimentoTrial = new Date();
        vencimentoTrial.setDate(vencimentoTrial.getDate() + 7);
        const novaAssinatura = {
          uid: u.uid,
          email: u.email,
          nome: u.displayName || "",
          status: "trial",
          ativa: true,
          plano: "trial",
          vencimento: vencimentoTrial,
          criadoEm: serverTimestamp(),
        };
        await setDoc(ref, novaAssinatura);
        setAssinatura({ ...novaAssinatura, ativa: true });
        tocarSomDinheiro(); // 💰 Novo cadastro!
      }
    } catch (e) {
      console.error("Erro ao verificar assinatura:", e);
      setAssinatura({ ativa: false });
    }
  };

  const recarregarAssinatura = async () => {
    if (user) {
      setVerificando(true);
      await verificarAssinatura(user);
      setVerificando(false);
    }
  };

  // Portal do correspondente — abre direto sem login
  if (correspondentId) return <CorrespondentePro processoId={correspondentId} />;

  // Carregando
  if (user === undefined || verificando) {
    return (
      <div style={{ background: "#0A0E1A", minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
        <div style={{ width: 72, height: 72, borderRadius: 20, background: "#F59E0B", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, marginBottom: 20 }}>🏡</div>
        <div style={{ color: "#F59E0B", fontWeight: 800, fontSize: 22, marginBottom: 8 }}>ImóvelPro</div>
        <div style={{ color: "#64748B", fontSize: 14 }}>Carregando...</div>
        <div style={{ marginTop: 24, width: 40, height: 4, background: "#1E293B", borderRadius: 4, overflow: "hidden" }}>
          <div style={{ width: "60%", height: "100%", background: "#F59E0B", borderRadius: 4, animation: "none" }} />
        </div>
      </div>
    );
  }

  // Não logado
  if (!user) return <Auth />;

  // Admin
  if (ADMIN_EMAILS.includes(user.email)) return <Admin user={user} />;

  // Logado mas sem assinatura ativa
  if (assinatura && !assinatura.ativa) {
    return <Assinatura user={user} assinatura={assinatura} onAtualizar={recarregarAssinatura} onSair={() => signOut(auth)} />;
  }

  // Logado e com assinatura ativa — mostra o app
  return <App uid={user.uid} user={user} assinatura={assinatura} onSair={() => signOut(auth)} />;
}
