import { useState, useEffect } from "react";
import { db } from "./firebase";
import { abrirWhatsApp } from "./sons";
import {
  collection, addDoc, updateDoc, deleteDoc,
  doc, onSnapshot, serverTimestamp, query, where
} from "firebase/firestore";

const COLORS = {
  bg: "#0A0E1A", card: "#111827", cardBorder: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B", orange: "#F97316",
};

function Input({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", outline: "none" }} />
    </div>
  );
}

function Sel({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
        {options.map(o => typeof o === "string" ? <option key={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, color = "accent", size = "md", full = false, style = {} }) {
  const bg = { accent: COLORS.accent, green: COLORS.green, red: COLORS.red, blue: COLORS.blue, surface: COLORS.surface, purple: COLORS.purple, orange: COLORS.orange };
  const tc = { accent: "#0A0E1A", green: "#fff", red: "#fff", blue: "#fff", surface: COLORS.text, purple: "#fff", orange: "#fff" };
  return (
    <button onClick={onClick} style={{ background: bg[color] || COLORS.accent, color: tc[color] || "#fff", border: "none", borderRadius: 10, padding: size === "sm" ? "6px 12px" : "11px 22px", fontSize: size === "sm" ? 12 : 14, fontWeight: 700, cursor: "pointer", width: full ? "100%" : "auto", ...style }}>
      {children}
    </button>
  );
}

// Formata data "YYYY-MM-DD" → "Dom, 12 Mai"
function formatarData(dataStr) {
  if (!dataStr) return "";
  try {
    const [y, m, d] = dataStr.split("-").map(Number);
    const dt = new Date(y, m - 1, d);
    return dt.toLocaleDateString("pt-BR", { weekday: "short", day: "numeric", month: "short" });
  } catch { return dataStr; }
}

// Dias até a data
function diasAte(dataStr) {
  if (!dataStr) return null;
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const [y, m, d] = dataStr.split("-").map(Number);
  const alvo = new Date(y, m - 1, d);
  return Math.round((alvo - hoje) / 86400000);
}

const TIPO_ICON = { Visita: "🏠", Reunião: "🤝", Ligação: "📞", Assinatura: "✍️", Entrega: "🔑", Outro: "📅" };
const TIPO_COR  = { Visita: COLORS.orange, Reunião: COLORS.blue, Ligação: COLORS.green, Assinatura: COLORS.purple, Entrega: COLORS.accent, Outro: COLORS.muted };

export default function Agenda({ uid, imoveis = [], clientes = [] }) {
  const [compromissos, setCompromissos] = useState([]);
  const [view, setView] = useState("list"); // list | form | detalhe
  const [saving, setSaving] = useState(false);
  const [selId, setSelId] = useState(null);
  const [abaDia, setAbaDia] = useState("todos"); // todos | hoje | semana | passados

  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const hojeStr = hoje.toISOString().split("T")[0];
  const semanaStr = new Date(hoje.getTime() + 7 * 86400000).toISOString().split("T")[0];

  const empty = {
    tipo: "Visita",
    titulo: "",
    data: hojeStr,
    hora: "",
    imovelId: "",
    clienteNome: "",
    clienteTel: "",
    local: "",
    observacoes: "",
    status: "agendado", // agendado | concluido | cancelado
  };
  const [form, setForm] = useState(empty);
  const ff = (k, v) => setForm(p => ({ ...p, [k]: v }));

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "agenda"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => {
      setCompromissos(
        snap.docs
          .map(d => ({ id: d.id, ...d.data() }))
          .sort((a, b) => {
            const da = (a.data || "") + (a.hora || "");
            const db2 = (b.data || "") + (b.hora || "");
            return da.localeCompare(db2);
          })
      );
    }, () => {});
    return unsub;
  }, [uid]);

  const salvar = async () => {
    if (!form.titulo.trim()) return alert("Digite um título para o compromisso");
    if (!form.data) return alert("Selecione uma data");
    setSaving(true);
    try {
      const imovel = imoveis.find(i => i.id === form.imovelId);
      const dados = {
        ...form,
        imovelTitulo: imovel?.titulo || "",
        imovelEndereco: imovel?.endereco || "",
        uid,
        updatedAt: serverTimestamp(),
      };
      if (selId) {
        await updateDoc(doc(db, "agenda", selId), dados);
      } else {
        await addDoc(collection(db, "agenda"), { ...dados, createdAt: serverTimestamp() });
      }
      setView("list"); setForm(empty); setSelId(null);
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const excluir = async (id) => {
    if (!window.confirm("Excluir este compromisso?")) return;
    await deleteDoc(doc(db, "agenda", id));
    setView("list"); setSelId(null);
  };

  const concluir = async (id) => {
    await updateDoc(doc(db, "agenda", id), { status: "concluido", updatedAt: serverTimestamp() });
  };

  const cancelar = async (id) => {
    await updateDoc(doc(db, "agenda", id), { status: "cancelado", updatedAt: serverTimestamp() });
  };

  // Filtros por aba
  const filtrados = compromissos.filter(c => {
    if (abaDia === "hoje") return c.data === hojeStr && c.status === "agendado";
    if (abaDia === "semana") return c.data >= hojeStr && c.data <= semanaStr && c.status === "agendado";
    if (abaDia === "passados") return c.data < hojeStr || c.status !== "agendado";
    return true; // todos
  });

  const qtdHoje = compromissos.filter(c => c.data === hojeStr && c.status === "agendado").length;
  const qtdSemana = compromissos.filter(c => c.data >= hojeStr && c.data <= semanaStr && c.status === "agendado").length;
  const qtdAtrasados = compromissos.filter(c => c.data < hojeStr && c.status === "agendado").length;

  // ── FORMULÁRIO ──
  if (view === "form") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => { setView("list"); setForm(empty); setSelId(null); }}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{selId ? "✏️ Editar Compromisso" : "📅 Novo Compromisso"}</h2>
      </div>
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 16, padding: 20 }}>
        <Sel label="Tipo" value={form.tipo} onChange={v => ff("tipo", v)} options={Object.keys(TIPO_ICON)} />
        <Input label="Título" value={form.titulo} onChange={v => ff("titulo", v)} placeholder="Ex: Visita Apto Meireles com João" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Input label="Data" type="date" value={form.data} onChange={v => ff("data", v)} />
          <Input label="Horário" type="time" value={form.hora} onChange={v => ff("hora", v)} />
        </div>
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Imóvel (opcional)</label>
          <select value={form.imovelId} onChange={e => ff("imovelId", e.target.value)}
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
            <option value="">— Nenhum —</option>
            {imoveis.filter(i => i.status === "Disponível").map(i => (
              <option key={i.id} value={i.id}>{i.titulo} — {i.endereco}</option>
            ))}
          </select>
        </div>
        <Input label="Nome do Cliente" value={form.clienteNome} onChange={v => ff("clienteNome", v)} placeholder="Ex: Maria Oliveira" />
        <Input label="Telefone do Cliente" value={form.clienteTel} onChange={v => ff("clienteTel", v)} placeholder="(85) 99999-0000" />
        <Input label="Local / Endereço de Encontro" value={form.local} onChange={v => ff("local", v)} placeholder="Ex: Entrada do condomínio" />
        <Input label="Observações" value={form.observacoes} onChange={v => ff("observacoes", v)} placeholder="Levar proposta, confirmar com porteiro..." />
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : `💾 ${selId ? "Salvar" : "Agendar"}`}
        </Btn>
        {selId && <Btn full color="red" onClick={() => excluir(selId)} style={{ marginTop: 10 }}>🗑️ Excluir</Btn>}
      </div>
    </div>
  );

  // ── LISTA ──
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>📅 Agenda</h2>
        <Btn size="sm" onClick={() => { setForm(empty); setSelId(null); setView("form"); }}>+ Novo</Btn>
      </div>

      {/* Alertas */}
      {qtdAtrasados > 0 && (
        <div style={{ background: "#7F1D1D", borderRadius: 12, padding: "10px 14px", marginBottom: 12, color: "#FCA5A5", fontSize: 13, fontWeight: 700 }}>
          ⚠️ {qtdAtrasados} compromisso{qtdAtrasados > 1 ? "s" : ""} em atraso sem conclusão!
        </div>
      )}

      {/* Abas de filtro */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16, overflowX: "auto" }}>
        {[
          { id: "todos", label: "Todos" },
          { id: "hoje", label: `Hoje${qtdHoje > 0 ? ` (${qtdHoje})` : ""}` },
          { id: "semana", label: `Semana${qtdSemana > 0 ? ` (${qtdSemana})` : ""}` },
          { id: "passados", label: "Passados" },
        ].map(a => (
          <button key={a.id} onClick={() => setAbaDia(a.id)} style={{ background: abaDia === a.id ? COLORS.accent : COLORS.surface, color: abaDia === a.id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>
            {a.label}
          </button>
        ))}
      </div>

      {/* Lista de compromissos */}
      {filtrados.length === 0 ? (
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 32, textAlign: "center" }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>📅</div>
          <div style={{ color: COLORS.muted, fontSize: 14 }}>
            {abaDia === "hoje" ? "Nenhum compromisso para hoje." :
             abaDia === "semana" ? "Nada agendado para os próximos 7 dias." :
             "Nenhum compromisso aqui."}
          </div>
          <Btn color="accent" size="sm" style={{ marginTop: 14 }} onClick={() => { setForm(empty); setSelId(null); setView("form"); }}>
            + Agendar agora
          </Btn>
        </div>
      ) : filtrados.map(c => {
        const dias = diasAte(c.data);
        const cor = TIPO_COR[c.tipo] || COLORS.muted;
        const atrasado = c.status === "agendado" && c.data < hojeStr;
        const statusCor = c.status === "concluido" ? COLORS.green : c.status === "cancelado" ? COLORS.red : atrasado ? "#EF4444" : cor;

        return (
          <div key={c.id} style={{ background: COLORS.card, border: `1px solid ${c.status !== "agendado" ? COLORS.cardBorder : statusCor + "55"}`, borderLeft: `4px solid ${statusCor}`, borderRadius: 14, padding: "14px 16px", marginBottom: 10, opacity: c.status !== "agendado" ? 0.65 : 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
              <div style={{ flex: 1 }}>
                {/* Tipo + status badge */}
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                  <span style={{ fontSize: 18 }}>{TIPO_ICON[c.tipo] || "📅"}</span>
                  <span style={{ color: cor, fontSize: 11, fontWeight: 700, background: cor + "22", padding: "2px 8px", borderRadius: 20 }}>{c.tipo}</span>
                  {c.status === "concluido" && <span style={{ color: COLORS.green, fontSize: 11, fontWeight: 700, background: COLORS.green + "22", padding: "2px 8px", borderRadius: 20 }}>✓ Concluído</span>}
                  {c.status === "cancelado" && <span style={{ color: COLORS.red, fontSize: 11, fontWeight: 700, background: COLORS.red + "22", padding: "2px 8px", borderRadius: 20 }}>✗ Cancelado</span>}
                  {atrasado && <span style={{ color: "#EF4444", fontSize: 11, fontWeight: 700, background: "#EF444422", padding: "2px 8px", borderRadius: 20 }}>⚠️ Atrasado</span>}
                </div>

                {/* Título */}
                <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 15, marginBottom: 4, textDecoration: c.status !== "agendado" ? "line-through" : "none" }}>{c.titulo}</div>

                {/* Data e hora */}
                <div style={{ color: c.data === hojeStr ? COLORS.accent : COLORS.muted, fontSize: 12, fontWeight: 600, marginBottom: 4 }}>
                  📅 {formatarData(c.data)}{c.hora ? ` às ${c.hora}` : ""}
                  {c.status === "agendado" && dias !== null && (
                    <span style={{ marginLeft: 8, color: dias < 0 ? COLORS.red : dias === 0 ? COLORS.accent : COLORS.muted, fontWeight: 700 }}>
                      {dias < 0 ? `(${Math.abs(dias)}d atrás)` : dias === 0 ? "(hoje!)" : `(em ${dias}d)`}
                    </span>
                  )}
                </div>

                {/* Imóvel */}
                {c.imovelTitulo && <div style={{ color: COLORS.muted, fontSize: 12 }}>🏠 {c.imovelTitulo}</div>}
                {c.imovelEndereco && !c.imovelTitulo && <div style={{ color: COLORS.muted, fontSize: 12 }}>📍 {c.imovelEndereco}</div>}

                {/* Cliente */}
                {c.clienteNome && <div style={{ color: COLORS.muted, fontSize: 12 }}>👤 {c.clienteNome}{c.clienteTel ? ` · ${c.clienteTel}` : ""}</div>}

                {/* Observações */}
                {c.observacoes && <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 4, fontStyle: "italic" }}>"{c.observacoes}"</div>}
              </div>

              {/* Ações rápidas */}
              <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
                <Btn size="sm" color="surface" onClick={() => { setForm({ tipo: c.tipo, titulo: c.titulo, data: c.data, hora: c.hora || "", imovelId: c.imovelId || "", clienteNome: c.clienteNome || "", clienteTel: c.clienteTel || "", local: c.local || "", observacoes: c.observacoes || "", status: c.status }); setSelId(c.id); setView("form"); }}>✏️</Btn>
                {c.status === "agendado" && <Btn size="sm" color="green" onClick={() => concluir(c.id)}>✓</Btn>}
              </div>
            </div>

            {/* Botões de ação expandidos */}
            {c.status === "agendado" && (
              <div style={{ display: "flex", gap: 8, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${COLORS.cardBorder}` }}>
                {c.clienteTel && (
                  <Btn size="sm" color="green" style={{ flex: 1 }} onClick={() => {
                    const msg = `Olá ${c.clienteNome || ""}! Confirmando nossa visita em ${formatarData(c.data)}${c.hora ? ` às ${c.hora}` : ""}${c.imovelTitulo ? ` - ${c.imovelTitulo}` : ""}. Confirmado? 😊`;
                    abrirWhatsApp(`https://wa.me/55${c.clienteTel.replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`);
                  }}>💬 Confirmar</Btn>
                )}
                <Btn size="sm" color="orange" style={{ flex: 1 }} onClick={() => cancelar(c.id)}>✗ Cancelar</Btn>
                <Btn size="sm" color="red" style={{ flex: "none" }} onClick={() => excluir(c.id)}>🗑️</Btn>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
