// build-1778533208 v1778531779 build
import { useState, useRef, useEffect, useCallback } from "react";
import { db } from "./firebase";
import CRM from "./CRM";
import Agenda from "./Agenda";
import { tocarSomDinheiro, desbloquearAudio, registrarAbrirWhatsApp, abrirWhatsApp } from "./sons";
import {
  useNotificacoes,
  ToastContainer,
  CentralNotificacoes,
  BotaoNotificacoes,
  BannerPermissaoPush,
} from "./Notificacoes";
import {
  collection, addDoc, updateDoc, deleteDoc, getDoc, setDoc,
  doc, onSnapshot, serverTimestamp, query, where
} from "firebase/firestore";

// Cloudinary config
const CLOUD_NAME = "dtkhubg84";
const UPLOAD_PRESET = "Imovel-pro"; // preset que já funciona (mesmo das fotos)

// ── Som de notificação de processo (correspondente) ──
function tocarSomProcesso() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const tocar = (freq, inicio, dur, tipo = "sine", gain = 0.35) => {
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      osc.connect(gainNode);
      gainNode.connect(ctx.destination);
      osc.type = tipo;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + inicio);
      gainNode.gain.setValueAtTime(0, ctx.currentTime + inicio);
      gainNode.gain.linearRampToValueAtTime(gain, ctx.currentTime + inicio + 0.03);
      gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + inicio + dur);
      osc.start(ctx.currentTime + inicio);
      osc.stop(ctx.currentTime + inicio + dur + 0.05);
    };
    // Duas notas graves — som de "atualização importante"
    tocar(660, 0,    0.18, "triangle");
    tocar(880, 0.20, 0.28, "triangle");
  } catch (e) {
    // Fallback silencioso
  }
}


async function uploadFoto(file) {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("upload_preset", UPLOAD_PRESET);
  formData.append("folder", "imovel-pro");
  const res = await fetch(`https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`, {
    method: "POST",
    body: formData
  });
  const data = await res.json();
  if (!data.secure_url) throw new Error(data.error?.message || "Falha no upload da foto");
  return data.secure_url;
}

// Corrige URLs antigas /raw/upload/ para /image/upload/ (PDFs acessíveis no browser)
function fixUrl(url) {
  if (!url) return url;
  return url.replace("/raw/upload/", "/image/upload/");
}

// Upload de documentos (PDF, Word, etc.)
// Usa o mesmo preset das fotos, sem pasta fixa (evita erro 400 por restrição de pasta).
async function uploadArquivo(file) {
  const fd = new FormData();
  fd.append("file", file);
  fd.append("upload_preset", UPLOAD_PRESET);
  // Sem "folder" — deixa o Cloudinary decidir onde salvar (evita erro 400)

  const res = await fetch(
    `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/image/upload`,
    { method: "POST", body: fd }
  );
  if (!res.ok) throw new Error(`Erro de rede: ${res.status}`);
  const data = await res.json();
  if (data.secure_url) return data.secure_url;

  // Fallback raw para Word, zip, etc.
  const fd2 = new FormData();
  fd2.append("file", file);
  fd2.append("upload_preset", UPLOAD_PRESET);
  const res2 = await fetch(
    `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/raw/upload`,
    { method: "POST", body: fd2 }
  );
  if (!res2.ok) throw new Error(`Erro de rede: ${res2.status}`);
  const data2 = await res2.json();
  if (data2.secure_url) return data2.secure_url;

  // Mostra erro detalhado do Cloudinary para diagnóstico
  const errMsg = data2.error?.message || data.error?.message || "Falha no upload";
  throw new Error(`Cloudinary: ${errMsg}`);
}
// ── IA: Descrição automática via Claude analisando as fotos ──
async function gerarDescricaoIA(fotos, dadosImovel) {
  const fotosValidas = fotos.filter(f => f.url && !f.uploading && !f.url.startsWith("data:"));
  if (fotosValidas.length === 0) throw new Error("Aguarde as fotos terminarem de carregar antes de gerar a descrição.");

  const imageContents = fotosValidas.slice(0, 4).map(f => ({
    type: "image",
    source: { type: "url", url: f.url }
  }));

  const contexto = [
    dadosImovel.tipo && `Tipo: ${dadosImovel.tipo}`,
    dadosImovel.area && `Área: ${dadosImovel.area}m²`,
    dadosImovel.quartos && `Quartos: ${dadosImovel.quartos}`,
    dadosImovel.banheiros && `Banheiros: ${dadosImovel.banheiros}`,
    dadosImovel.garagem && "Tem garagem",
    dadosImovel.quintal && "Tem quintal",
    dadosImovel.endereco && `Endereço: ${dadosImovel.endereco}`,
  ].filter(Boolean).join(", ");

  const prompt = `Você é um especialista em marketing imobiliário brasileiro. Analise as fotos deste imóvel e crie uma descrição comercial atraente e profissional em português do Brasil.\n\nDados do imóvel: ${contexto || "não informados"}\n\nEscreva uma descrição fluida de 3 a 5 frases, destacando os pontos fortes visíveis nas fotos (acabamento, luminosidade, espaço, estilo, ambiente). Use linguagem persuasiva mas sem exageros. NÃO use bullet points, apenas texto corrido. Não mencione preço.`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 500,
      messages: [{ role: "user", content: [...imageContents, { type: "text", text: prompt }] }]
    })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || "Erro na API");
  return data.content?.[0]?.text || "";
}

// ── IA: Gerar texto do cartaz imobiliário ──
async function gerarTextoCartazIA(imovel) {
  const fotosValidas = (imovel.fotos || []).filter(f => {
    const url = f.url || f;
    return url && !String(url).startsWith("data:");
  });

  const imageContents = fotosValidas.slice(0, 3).map(f => ({
    type: "image",
    source: { type: "url", url: f.url || f }
  }));

  const prompt = `Você é um copywriter imobiliário. Analise as fotos e dados do imóvel e crie um texto curto e impactante para um cartaz/flyer imobiliário.\n\nDados:\n- Título: ${imovel.titulo}\n- Tipo: ${imovel.tipo}\n- Valor: R$ ${Number(imovel.valor).toLocaleString("pt-BR")}\n- Área: ${imovel.area}m²\n- Quartos: ${imovel.quartos} | Banheiros: ${imovel.banheiros}\n- Endereço: ${imovel.endereco}\n- Garagem: ${imovel.garagem ? "Sim" : "Não"} | Quintal: ${imovel.quintal ? "Sim" : "Não"}\n\nRetorne APENAS um JSON com esta estrutura (sem markdown):\n{"slogan":"frase curta e impactante (max 8 palavras)","destaque1":"característica principal (max 5 palavras)","destaque2":"segunda característica (max 5 palavras)","destaque3":"terceira característica (max 5 palavras)","chamada":"frase de chamada para ação (max 10 palavras)"}`;

  const messages = [{ role: "user", content: imageContents.length > 0 ? [...imageContents, { type: "text", text: prompt }] : [{ type: "text", text: prompt }] }];

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 400, messages })
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || "Erro na API");
  const text = data.content?.[0]?.text || "{}";
  try { return JSON.parse(text.replace(/```json|```/g, "").trim()); }
  catch { return { slogan: imovel.titulo, destaque1: `${imovel.area}m²`, destaque2: `${imovel.quartos} quartos`, destaque3: `${imovel.banheiros} banheiros`, chamada: "Entre em contato agora!" }; }
}

const COLORS = {
  bg: "#0A0E1A", card: "#111827", cardBorder: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B",
};

const NAV_ITEMS = [
  { id: "dashboard", icon: "🏠", label: "Início" },
  { id: "imoveis", icon: "🏢", label: "Imóveis" },
  { id: "agenda", icon: "📅", label: "Agenda" },
  { id: "bancario", icon: "🏦", label: "Bancário" },
  { id: "calculadora", icon: "🧮", label: "Calculadora" },
  { id: "comissao", icon: "💰", label: "Comissão" },
  { id: "avaliacao", icon: "📊", label: "Avaliação" },
  { id: "documentos", icon: "📄", label: "Contratos" },
  { id: "financeiro", icon: "💵", label: "Financeiro" },
  { id: "crm", icon: "🎯", label: "Leads" },
  { id: "notas", icon: "📝", label: "Notas" },
  { id: "meulink", icon: "🔗", label: "Meu Link" },
  { id: "perfil", icon: "👤", label: "Perfil" },
];

const ETAPAS = ["Solicitação", "Análise de Crédito", "Avaliação do Imóvel", "Aprovação", "Assinatura", "Liberação"];

// ─── COMPONENTES BASE ───
function Badge({ color, children }) {
  const colors = { green: { bg: "#064E3B", text: "#6EE7B7" }, red: { bg: "#7F1D1D", text: "#FCA5A5" }, yellow: { bg: "#78350F", text: "#FCD34D" }, blue: { bg: "#1E3A8A", text: "#93C5FD" }, purple: { bg: "#4C1D95", text: "#C4B5FD" } };
  const c = colors[color] || colors.blue;
  return <span style={{ background: c.bg, color: c.text, padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{children}</span>;
}

function Card({ children, style = {} }) {
  return <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 16, padding: 20, ...style }}>{children}</div>;
}

function Input({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", outline: "none" }} />
    </div>
  );
}

function Sel({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, color = "accent", size = "md", full = false, style = {} }) {
  const bg = { accent: COLORS.accent, green: COLORS.green, red: COLORS.red, blue: COLORS.blue, surface: COLORS.surface, purple: COLORS.purple };
  const tc = { accent: "#0A0E1A", green: "#fff", red: "#fff", blue: "#fff", surface: COLORS.text, purple: "#fff" };
  return (
    <button onClick={onClick} style={{ background: bg[color] || COLORS.accent, color: tc[color] || "#fff", border: "none", borderRadius: 10, padding: size === "sm" ? "6px 12px" : "11px 22px", fontSize: size === "sm" ? 12 : 14, fontWeight: 700, cursor: "pointer", width: full ? "100%" : "auto", ...style }}>
      {children}
    </button>
  );
}

function ConfirmModal({ msg, onOk, onCancel }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 20, padding: 28, width: "100%", maxWidth: 320, textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 12 }}>⚠️</div>
        <p style={{ color: COLORS.text, fontSize: 16, marginBottom: 24, lineHeight: 1.5 }}>{msg}</p>
        <div style={{ display: "flex", gap: 10 }}>
          <Btn full color="surface" onClick={onCancel}>Cancelar</Btn>
          <Btn full color="red" onClick={onOk}>🗑️ Excluir</Btn>
        </div>
      </div>
    </div>
  );
}

function Loading() {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 40 }}>
      <div style={{ fontSize: 36, marginBottom: 12 }}>⏳</div>
      <div style={{ color: COLORS.muted, fontSize: 14 }}>Carregando dados...</div>
    </div>
  );
}

// ─── DASHBOARD ───
// ─── DASHBOARD v9 — ALERTAS INTELIGENTES ───

// Calcula dias desde um Firestore Timestamp ou segundos epoch
function diasDesde(ts) {
  if (!ts) return null;
  const secs = ts?.seconds ?? ts;
  return Math.floor((Date.now() / 1000 - secs) / 86400);
}

function gerarAlertas({ imoveis, clientes, processos, compromissos, tarefas, negócios, tarefasCRM }) {
  const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
  const hojeStr = hoje.toISOString().split("T")[0];
  const alertas = [];

  // ═══════════════════════════════════════
  //  ALERTAS DE LEADS (bloco dedicado)
  // ═══════════════════════════════════════

  const ativos = (negócios || []).filter(n => n.etapa !== "fechado" && n.etapa !== "perdido");

  // 1. Lead VIP/Urgente sem qualquer contato há 1+ dia
  ativos.filter(n => n.tags?.includes("urgente") || n.tags?.includes("vip")).forEach(n => {
    const dias = diasDesde(n.ultimoContato || n.createdAt);
    if (dias >= 1)
      alertas.push({
        id: `lead-vip-${n.id}`, tipo: "urgente", icone: "⭐",
        titulo: `${n.tags?.includes("vip") ? "Lead VIP" : "Lead Urgente"} esperando!`,
        desc: `${n.nome} — sem retorno há ${dias} dia${dias > 1 ? "s" : ""}`,
        nav: "crm",
      });
  });

  // 2. Lead 🔥 Quente sem contato há 3+ dias
  ativos.filter(n => n.tags?.includes("quente") && !n.tags?.includes("urgente") && !n.tags?.includes("vip")).forEach(n => {
    const dias = diasDesde(n.ultimoContato || n.updatedAt || n.createdAt);
    if (dias >= 3)
      alertas.push({
        id: `lead-quente-${n.id}`, tipo: "urgente", icone: "🔥",
        titulo: "Lead quente esfriando!",
        desc: `${n.nome} sem contato há ${dias} dias — ${n.interesse || "interesse não definido"}`,
        nav: "crm",
      });
  });

  // 3. Lead na etapa "proposta" há 5+ dias sem movimentação
  ativos.filter(n => n.etapa === "proposta").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 5)
      alertas.push({
        id: `lead-proposta-${n.id}`, tipo: "urgente", icone: "📋",
        titulo: "Proposta parada!",
        desc: `${n.nome} com proposta aberta há ${dias} dias sem resposta`,
        nav: "crm",
      });
  });

  // 4. Lead na etapa "visita" há 3+ dias — follow-up necessário
  ativos.filter(n => n.etapa === "visita").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 3)
      alertas.push({
        id: `lead-visita-${n.id}`, tipo: "atencao", icone: "🏠",
        titulo: "Follow-up pós-visita",
        desc: `${n.nome} visitou há ${dias} dias — hora de ligar!`,
        nav: "crm",
      });
  });

  // 5. Lead na etapa "contato" há 5+ dias sem avançar
  ativos.filter(n => n.etapa === "contato").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 5)
      alertas.push({
        id: `lead-contato-${n.id}`, tipo: "atencao", icone: "📞",
        titulo: "Lead sem avançar no funil",
        desc: `${n.nome} em "Contato" há ${dias} dias — tente agendar visita`,
        nav: "crm",
      });
  });

  // 6. Lead frio na entrada do funil há 7+ dias
  ativos.filter(n => n.etapa === "lead").forEach(n => {
    const dias = diasDesde(n.createdAt);
    if (dias >= 7)
      alertas.push({
        id: `lead-frio-${n.id}`, tipo: "aviso", icone: "❄️",
        titulo: "Lead parado na entrada",
        desc: `${n.nome} sem contato inicial há ${dias} dias`,
        nav: "crm",
      });
  });

  // 7. Tarefas de follow-up do CRM vencidas hoje
  const hojeDate = new Date().toISOString().split("T")[0];
  const followUpsHoje = (tarefasCRM || []).filter(t => t.status === "pendente" && t.prazo === hojeDate);
  const followUpsAtrasados = (tarefasCRM || []).filter(t => t.status === "pendente" && t.prazo && t.prazo < hojeDate);
  if (followUpsHoje.length > 0)
    alertas.push({
      id: "followup-hoje", tipo: "urgente", icone: "📞",
      titulo: `${followUpsHoje.length} follow-up${followUpsHoje.length > 1 ? "s" : ""} para HOJE`,
      desc: followUpsHoje.map(t => t.titulo).slice(0, 2).join(" · "),
      nav: "crm",
    });
  if (followUpsAtrasados.length > 0)
    alertas.push({
      id: "followup-atrasado", tipo: "urgente", icone: "⚠️",
      titulo: `${followUpsAtrasados.length} follow-up${followUpsAtrasados.length > 1 ? "s" : ""} atrasado${followUpsAtrasados.length > 1 ? "s" : ""}`,
      desc: followUpsAtrasados.map(t => t.titulo).slice(0, 2).join(" · "),
      nav: "crm",
    });

  // 8. Pipeline com alto valor parado (≥ R$500k e etapa inicial)
  const leadRico = ativos.find(n => (Number(n.valorEstimado) || 0) >= 500000 && (n.etapa === "lead" || n.etapa === "contato"));
  if (leadRico) {
    const dias = diasDesde(leadRico.updatedAt || leadRico.createdAt);
    if (dias >= 2)
      alertas.push({
        id: `lead-rico-${leadRico.id}`, tipo: "urgente", icone: "💰",
        titulo: "Negócio de alto valor parado!",
        desc: `${leadRico.nome} — R$ ${Number(leadRico.valorEstimado).toLocaleString("pt-BR")} em jogo há ${dias} dias`,
        nav: "crm",
      });
  }

  // ═══════════════════════════════════════
  //  OUTROS ALERTAS
  // ═══════════════════════════════════════

  // Compromissos de hoje e amanhã
  (compromissos || []).forEach(c => {
    if (!c.data) return;
    const diff = Math.round((new Date(c.data + "T00:00:00") - hoje) / 86400000);
    if (diff === 0)
      alertas.push({ id: `comp-${c.id}`, tipo: "urgente", icone: "📅", titulo: "Compromisso HOJE", desc: `${c.tipo || "Evento"}: ${c.titulo || c.cliente || ""}`, nav: "agenda" });
    else if (diff === 1)
      alertas.push({ id: `comp1-${c.id}`, tipo: "atencao", icone: "⏰", titulo: "Compromisso amanhã", desc: `${c.tipo || "Evento"}: ${c.titulo || c.cliente || ""}`, nav: "agenda" });
  });

  // Imóveis sem atualização há 30+ dias
  (imoveis || []).filter(i => i.status !== "Vendido").forEach(i => {
    const dias = diasDesde(i.updatedAt || i.createdAt);
    if (dias >= 30)
      alertas.push({ id: `imovel-${i.id}`, tipo: "aviso", icone: "🏢", titulo: "Imóvel parado", desc: `"${i.titulo || i.tipo || "Imóvel"}" sem atualização há ${dias} dias`, nav: "imoveis" });
  });

  // Processos bancários parados há 15+ dias
  (processos || []).filter(p => p.status !== "Concluído" && p.status !== "Cancelado").forEach(p => {
    const dias = diasDesde(p.updatedAt || p.createdAt);
    if (dias >= 15)
      alertas.push({ id: `proc-${p.id}`, tipo: "atencao", icone: "🏦", titulo: "Processo parado", desc: `${p.cliente || "Cliente"} — ${p.status || "Em andamento"} há ${dias} dias`, nav: "bancario" });
  });

  // Tarefas urgentes (módulo Notas)
  const tarefasAlta = (tarefas || []).filter(t => !t.feita && t.prioridade === "alta");
  if (tarefasAlta.length > 0)
    alertas.push({ id: "tarefas-alta", tipo: "urgente", icone: "📝", titulo: `${tarefasAlta.length} tarefa${tarefasAlta.length > 1 ? "s" : ""} urgente${tarefasAlta.length > 1 ? "s" : ""}`, desc: tarefasAlta[0].texto, nav: "notas" });

  // Portfólio vazio
  const disponiveis = (imoveis || []).filter(i => i.status === "Disponível").length;
  if (imoveis.length > 0 && disponiveis === 0)
    alertas.push({ id: "sem-disponiveis", tipo: "aviso", icone: "🏘️", titulo: "Portfólio vazio", desc: "Nenhum imóvel disponível para venda. Hora de captar!", nav: "imoveis" });

  // Conquista: primeira venda
  const vendidos = (imoveis || []).filter(i => i.status === "Vendido").length;
  if (vendidos === 1)
    alertas.push({ id: "first-sale", tipo: "conquista", icone: "🏆", titulo: "Primeira venda!", desc: "Parabéns pelo seu primeiro imóvel vendido!", nav: "imoveis" });

  // Conquista: primeiro lead fechado
  const fechados = (negócios || []).filter(n => n.etapa === "fechado").length;
  if (fechados === 1)
    alertas.push({ id: "first-deal", tipo: "conquista", icone: "🎯", titulo: "Primeiro negócio fechado!", desc: "Seu funil converteu. Continue assim!", nav: "crm" });

  const ordem = { urgente: 0, atencao: 1, aviso: 2, conquista: 3 };
  return alertas.sort((a, b) => ordem[a.tipo] - ordem[b.tipo]).slice(0, 10);
}

function AlertaCard({ alerta, onNav, onDismiss }) {
  const COR = {
    urgente:   { bg: "rgba(239,68,68,0.10)",  border: "#EF4444", ponto: "#EF4444", label: "Urgente" },
    atencao:   { bg: "rgba(245,158,11,0.10)", border: "#F59E0B", ponto: "#F59E0B", label: "Atenção" },
    aviso:     { bg: "rgba(59,130,246,0.10)", border: "#3B82F6", ponto: "#3B82F6", label: "Aviso" },
    conquista: { bg: "rgba(16,185,129,0.10)", border: "#10B981", ponto: "#10B981", label: "🎉" },
  };
  const c = COR[alerta.tipo] || COR.aviso;

  return (
    <div style={{
      background: c.bg, border: `1px solid ${c.border}`, borderRadius: 14,
      padding: "12px 14px", marginBottom: 10, display: "flex", alignItems: "flex-start", gap: 12,
    }}>
      {/* Ícone + ponto pulsante */}
      <div style={{ position: "relative", flexShrink: 0, marginTop: 2 }}>
        <span style={{ fontSize: 22 }}>{alerta.icone}</span>
        {alerta.tipo === "urgente" && (
          <span style={{
            position: "absolute", top: -2, right: -4, width: 8, height: 8,
            borderRadius: "50%", background: c.ponto,
            boxShadow: `0 0 0 2px rgba(239,68,68,0.3)`,
          }} />
        )}
      </div>
      {/* Texto */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
          <span style={{ color: c.border, fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5 }}>{c.label}</span>
        </div>
        <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700, marginBottom: 2, lineHeight: 1.3 }}>{alerta.titulo}</div>
        <div style={{ color: COLORS.muted, fontSize: 11, lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{alerta.desc}</div>
      </div>
      {/* Botões */}
      <div style={{ display: "flex", flexDirection: "column", gap: 4, flexShrink: 0 }}>
        <button onClick={() => onNav(alerta.nav)} style={{
          background: c.border, color: "#0A0E1A", border: "none", borderRadius: 8,
          padding: "4px 10px", fontSize: 11, fontWeight: 800, cursor: "pointer",
        }}>Ver →</button>
        <button onClick={() => onDismiss(alerta.id)} style={{
          background: "transparent", color: COLORS.muted, border: "none",
          fontSize: 16, cursor: "pointer", lineHeight: 1, padding: "2px 4px",
        }}>✕</button>
      </div>
    </div>
  );
}

function Dashboard({ imoveis, clientes, processos, setActive, nomeCompleto, creci, fotoPerfil }) {
  const vendidos = imoveis.filter(i => i.status === "Vendido").length;
  const disponiveis = imoveis.filter(i => i.status === "Disponível").length;
  const [dismissedIds, setDismissedIds] = useState(() => {
    try { return JSON.parse(localStorage.getItem("alertas_dismissed") || "[]"); } catch { return []; }
  });
  const [compromissos, setCompromissos] = useState([]);
  const [tarefas, setTarefas] = useState([]);
  const [negócios, setNegócios] = useState([]);
  const [tarefasCRM, setTarefasCRM] = useState([]);
  const CORRETOR_UID_DASH = clientes[0]?.uid || processos[0]?.uid || imoveis[0]?.uid || null;

  // Carrega todos os dados necessários para os alertas
  useEffect(() => {
    if (!CORRETOR_UID_DASH) return;
    const unsubs = [];
    const q1 = query(collection(db, "compromissos"), where("uid", "==", CORRETOR_UID_DASH));
    unsubs.push(onSnapshot(q1, s => setCompromissos(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {}));
    const q2 = query(collection(db, "notas_tarefas"), where("uid", "==", CORRETOR_UID_DASH));
    unsubs.push(onSnapshot(q2, s => setTarefas(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {}));
    const q3 = query(collection(db, "negocios"), where("uid", "==", CORRETOR_UID_DASH));
    unsubs.push(onSnapshot(q3, s => setNegócios(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {}));
    // Tarefas/follow-ups do CRM (coleção "tarefas", diferente de "notas_tarefas")
    const q4 = query(collection(db, "tarefas"), where("uid", "==", CORRETOR_UID_DASH));
    unsubs.push(onSnapshot(q4, s => setTarefasCRM(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {}));
    return () => unsubs.forEach(u => u());
  }, [CORRETOR_UID_DASH]);

  const todosAlertas = gerarAlertas({ imoveis, clientes, processos, compromissos, tarefas, negócios, tarefasCRM });
  const alertasVisiveis = todosAlertas.filter(a => !dismissedIds.includes(a.id));

  const dispensar = (id) => {
    const novos = [...dismissedIds, id];
    setDismissedIds(novos);
    try { localStorage.setItem("alertas_dismissed", JSON.stringify(novos)); } catch {}
  };

  // Limpa dismissed ao virar o dia
  useEffect(() => {
    const hojeKey = new Date().toISOString().split("T")[0];
    const savedKey = localStorage.getItem("alertas_dismissed_day");
    if (savedKey !== hojeKey) {
      localStorage.removeItem("alertas_dismissed");
      localStorage.setItem("alertas_dismissed_day", hojeKey);
      setDismissedIds([]);
    }
  }, []);

  const saudacao = () => {
    const h = new Date().getHours();
    if (h < 12) return "Bom dia";
    if (h < 18) return "Boa tarde";
    return "Boa noite";
  };

  const statsCards = [
    { label: "Imóveis", value: imoveis.length, icon: "🏢", color: COLORS.blue, sub: `${disponiveis} disponíveis`, nav: "imoveis" },
    { label: "Leads", value: clientes.length, icon: "🎯", color: COLORS.purple, sub: "cadastrados", nav: "crm" },
    { label: "Processos", value: processos.length, icon: "🏦", color: COLORS.green, sub: "bancários", nav: "bancario" },
    { label: "Vendidos", value: vendidos, icon: "🏆", color: COLORS.accent, sub: "concluídos", nav: "imoveis" },
  ];

  const atalhos = [
    { label: "🏢", desc: "Imóveis", id: "imoveis" },
    { label: "🏦", desc: "Bancário", id: "bancario" },
    { label: "🧮", desc: "Calculadora", id: "calculadora" },
    { label: "💰", desc: "Comissão", id: "comissao" },
    { label: "📊", desc: "Avaliação", id: "avaliacao" },
    { label: "📄", desc: "Contratos", id: "documentos" },
    { label: "💵", desc: "Financeiro", id: "financeiro" },
    { label: "🎯", desc: "Leads", id: "crm" },
    { label: "🔗", desc: "Meu Link", id: "meulink" },
  ];

  return (
    <div>
      {/* Header com saudação */}
      <div style={{ marginBottom: 20, display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ flexShrink: 0 }}>
          {fotoPerfil ? (
            <img src={fotoPerfil} alt="Foto" style={{ width: 56, height: 56, borderRadius: "50%", objectFit: "cover", border: "2px solid #F59E0B" }} />
          ) : (
            <div style={{ width: 56, height: 56, borderRadius: "50%", background: "#1E293B", border: "2px solid #334155", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26 }}>🧑‍💼</div>
          )}
        </div>
        <div style={{ flex: 1 }}>
          <h1 style={{ color: COLORS.text, fontSize: 20, fontWeight: 800, margin: 0 }}>
            {saudacao()}, {nomeCompleto?.split(" ")[0] || "Corretor"}! 👋
          </h1>
          {creci ? (
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 3 }}>
              <span style={{ color: "#F59E0B", fontSize: 12, fontWeight: 700, background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 6, padding: "2px 8px" }}>
                CRECI {creci}
              </span>
            </div>
          ) : (
            <p style={{ color: COLORS.muted, margin: "3px 0 0", fontSize: 12 }}>Dados salvos na nuvem ☁️</p>
          )}
        </div>
        {/* Badge de alertas ativos */}
        {alertasVisiveis.length > 0 && (
          <div style={{ flexShrink: 0, position: "relative" }}>
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: "rgba(239,68,68,0.15)", border: "1.5px solid #EF4444", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🔔</div>
            <span style={{ position: "absolute", top: -4, right: -4, background: "#EF4444", color: "#fff", fontSize: 10, fontWeight: 800, borderRadius: "50%", width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {alertasVisiveis.length}
            </span>
          </div>
        )}
      </div>

      {/* ── ALERTAS INTELIGENTES ── */}
      {alertasVisiveis.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <h2 style={{ color: COLORS.text, fontSize: 15, fontWeight: 800, margin: 0 }}>
              🔔 Alertas do Dia
            </h2>
            <span style={{ color: COLORS.muted, fontSize: 11 }}>
              {alertasVisiveis.length} ativ{alertasVisiveis.length > 1 ? "os" : "o"}
            </span>
          </div>
          {alertasVisiveis.map(a => (
            <AlertaCard key={a.id} alerta={a} onNav={setActive} onDismiss={dispensar} />
          ))}
        </div>
      )}

      {/* ── Nenhum alerta — dia tranquilo ── */}
      {alertasVisiveis.length === 0 && todosAlertas.length === 0 && imoveis.length + clientes.length + processos.length > 0 && (
        <div style={{ marginBottom: 20, background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 14, padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 28 }}>✅</span>
          <div>
            <div style={{ color: "#10B981", fontWeight: 800, fontSize: 13 }}>Tudo em dia!</div>
            <div style={{ color: COLORS.muted, fontSize: 11 }}>Nenhum alerta pendente para hoje.</div>
          </div>
        </div>
      )}

      {/* Cards de estatísticas — scroll horizontal para caber todos */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20, overflowX: "auto", paddingBottom: 4, scrollbarWidth: "none" }}>
        {statsCards.map(s => (
          <div key={s.label}
            onClick={() => setActive(s.nav)}
            style={{
              background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`,
              borderRadius: 16, padding: "14px 16px", cursor: "pointer",
              flexShrink: 0, minWidth: 110,
              transition: "opacity 0.15s",
            }}>
            <div style={{ fontSize: 22 }}>{s.icon}</div>
            <div style={{ color: s.color, fontSize: 24, fontWeight: 800, margin: "4px 0 2px" }}>{s.value}</div>
            <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{s.label}</div>
            <div style={{ color: COLORS.muted, fontSize: 11 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Acesso rápido */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 14, fontWeight: 700 }}>📱 Acesso Rápido</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8 }}>
          {atalhos.map(a => (
            <button key={a.id} onClick={() => setActive(a.id)}
              style={{ background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 12, padding: "12px 4px", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 22 }}>{a.label}</span>
              <span style={{ color: COLORS.muted, fontSize: 10, fontWeight: 600 }}>{a.desc}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Ações rápidas */}
      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ color: COLORS.text, margin: "0 0 12px", fontSize: 14, fontWeight: 700 }}>⚡ Ações Rápidas</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          {[
            { label: "➕ Novo Imóvel", id: "imoveis" },
            { label: "🎯 Novo Lead", id: "crm" },
            { label: "🏦 Novo Processo", id: "bancario" },
            { label: "🔗 Meu Link", id: "meulink" },
          ].map(a => (
            <Btn key={a.id} color="surface" full onClick={() => setActive(a.id)} style={{ textAlign: "left", fontSize: 13 }}>{a.label}</Btn>
          ))}
        </div>
      </Card>

      {/* Processos recentes */}
      {processos.length > 0 && (
        <Card>
          <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 14, fontWeight: 700 }}>📋 Processos Recentes</h3>
          {processos.slice(0, 3).map(p => (
            <div key={p.id} onClick={() => setActive("bancario")}
              style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}`, cursor: "pointer" }}>
              <div>
                <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{p.cliente}</div>
                <div style={{ color: COLORS.muted, fontSize: 11 }}>{p.banco}</div>
              </div>
              <Badge color={p.etapa >= 4 ? "green" : "yellow"}>{p.status}</Badge>
            </div>
          ))}
          <Btn full color="surface" size="sm" onClick={() => setActive("bancario")} style={{ marginTop: 12 }}>Ver todos →</Btn>
        </Card>
      )}
    </div>
  );
}

// ─── IMÓVEIS ───
function Toggle({ label, value, onChange }) {
  return (
    <div onClick={() => onChange(!value)} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: COLORS.surface, borderRadius: 10, padding: "11px 14px", marginBottom: 10, cursor: "pointer", border: `1px solid ${value ? COLORS.accent : COLORS.cardBorder}` }}>
      <span style={{ color: value ? COLORS.text : COLORS.muted, fontSize: 14, fontWeight: value ? 600 : 400 }}>{label}</span>
      <div style={{ width: 42, height: 24, borderRadius: 12, background: value ? COLORS.accent : COLORS.surface, border: `2px solid ${value ? COLORS.accent : COLORS.muted}`, position: "relative", transition: "all 0.2s", flexShrink: 0 }}>
        <div style={{ position: "absolute", top: 2, left: value ? 18 : 2, width: 16, height: 16, borderRadius: "50%", background: value ? "#0A0E1A" : COLORS.muted, transition: "left 0.2s" }} />
      </div>
    </div>
  );
}

function SecaoForm({ titulo, children }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12, paddingBottom: 6, borderBottom: `1px solid ${COLORS.cardBorder}` }}>{titulo}</div>
      {children}
    </div>
  );
}

function FotoCarousel({ fotos, onRemove }) {
  const [idx, setIdx] = useState(0);
  if (!fotos || fotos.length === 0) return null;
  const cur = fotos[idx];
  return (
    <div style={{ marginTop: 12 }}>
      {/* Foto principal grande */}
      <div style={{ position: "relative", borderRadius: 12, overflow: "hidden", marginBottom: 8 }}>
        <img src={cur.url || cur} alt="" style={{ width: "100%", height: 200, objectFit: "cover", display: "block", opacity: cur.uploading ? 0.5 : 1 }} />
        {cur.uploading && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.5)" }}>
            <div style={{ color: "#fff", fontSize: 13, fontWeight: 700 }}>⏳ Enviando...</div>
          </div>
        )}
        {/* Navegação esq/dir */}
        {fotos.length > 1 && (
          <>
            <button onClick={() => setIdx(i => (i - 1 + fotos.length) % fotos.length)} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>‹</button>
            <button onClick={() => setIdx(i => (i + 1) % fotos.length)} style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>›</button>
          </>
        )}
        {/* Contador */}
        <div style={{ position: "absolute", bottom: 8, right: 8, background: "rgba(0,0,0,0.7)", borderRadius: 20, padding: "3px 10px", color: "#fff", fontSize: 11, fontWeight: 700 }}>{idx + 1}/{fotos.length}</div>
        {/* Botão remover */}
        <button onClick={() => { onRemove(idx); setIdx(i => Math.min(i, fotos.length - 2)); }} style={{ position: "absolute", top: 8, right: 8, background: COLORS.red, border: "none", borderRadius: "50%", width: 28, height: 28, color: "#fff", fontSize: 16, cursor: "pointer", fontWeight: 700, lineHeight: 1 }}>×</button>
      </div>
      {/* Miniaturas */}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", paddingBottom: 4 }}>
        {fotos.map((f, i) => (
          <div key={i} onClick={() => setIdx(i)} style={{ flexShrink: 0, width: 56, height: 56, borderRadius: 8, overflow: "hidden", border: `2px solid ${i === idx ? COLORS.accent : "transparent"}`, cursor: "pointer" }}>
            <img src={f.url || f} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", opacity: f.uploading ? 0.5 : 1 }} />
          </div>
        ))}
      </div>
    </div>
  );
}

function CardCarousel({ fotos, onClick }) {
  const [ci, setCi] = useState(0);
  const total = fotos.length;
  const prev = (e) => { e.stopPropagation(); setCi(i => (i - 1 + total) % total); };
  const next = (e) => { e.stopPropagation(); setCi(i => (i + 1) % total); };
  const btnStyle = (side) => ({ position: "absolute", [side]: 8, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.55)", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", cursor: "pointer", fontSize: 18, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2 });
  return (
    <div style={{ position: "relative", borderRadius: 10, overflow: "hidden", marginBottom: 12 }} onClick={onClick}>
      <img src={fotos[ci]?.url || fotos[ci]} alt="" style={{ width: "100%", height: 180, objectFit: "cover", display: "block" }} />
      {total > 1 && <>
        <button style={btnStyle("left")} onClick={prev}>‹</button>
        <button style={btnStyle("right")} onClick={next}>›</button>
        <div style={{ position: "absolute", bottom: 8, right: 10, background: "rgba(0,0,0,0.65)", borderRadius: 20, padding: "3px 10px", color: "#fff", fontSize: 11, fontWeight: 700 }}>📷 {ci + 1}/{total}</div>
        <div style={{ position: "absolute", bottom: 8, left: "50%", transform: "translateX(-50%)", display: "flex", gap: 5 }}>
          {fotos.map((_, i) => (
            <div key={i} onClick={e => { e.stopPropagation(); setCi(i); }} style={{ width: i === ci ? 16 : 6, height: 6, borderRadius: 3, background: i === ci ? COLORS.accent : "rgba(255,255,255,0.5)", cursor: "pointer", transition: "all 0.2s" }} />
          ))}
        </div>
      </>}
    </div>
  );
}

function Imoveis({ imoveis, loading, uid, perfilData }) {
  const [view, setView] = useState("list");
  const [editId, setEditId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [filter, setFilter] = useState("Todos");
  const [fotos, setFotos] = useState([]);
  const [saving, setSaving] = useState(false);
  const [detalheId, setDetalheId] = useState(null);
  const [fotoIdx, setFotoIdx] = useState(0);
  const [gerandoDesc, setGerandoDesc] = useState(false);
  const [showCartaz, setShowCartaz] = useState(false);
  const [gerandoCartaz, setGerandoCartaz] = useState(false);
  const [dadosCartaz, setDadosCartaz] = useState(null);
  const [showCompartilhar, setShowCompartilhar] = useState(false);
  // 🔍 BUSCA E FILTROS AVANÇADOS
  const [busca, setBusca] = useState("");
  const [filtroTipo, setFiltroTipo] = useState("Todos");
  const [filtroValorMin, setFiltroValorMin] = useState("");
  const [filtroValorMax, setFiltroValorMax] = useState("");
  const [filtroQuartos, setFiltroQuartos] = useState("Todos");
  const [showFiltros, setShowFiltros] = useState(false);
  const [buscandoLocal, setBuscandoLocal] = useState(false);
  const fileRef = useRef();

  const empty = {
    titulo: "", tipo: "Apartamento", valor: "", area: "", quartos: "", banheiros: "",
    endereco: "", descricao: "", status: "Disponível",
    // Novos campos
    garagem: false, quintal: false,
    parceria: false, nomeParceiroCorretor: "",
    nomeProprietario: "", telefoneProprietario: "", valorPedidoProprietario: "",
    documentacaoCompleta: false,
    tipoEscritura: "Nenhuma", // Nenhuma | Pública | Particular
    latitude: null,
    longitude: null,
  };
  const [form, setForm] = useState(empty);

  const f = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const abrirNovo = () => { setForm(empty); setFotos([]); setEditId(null); setView("form"); };

  // 📤 Exportar imóveis CSV
  const exportarImoveisCSV = () => {
    const header = ["Título", "Tipo", "Status", "Valor (R$)", "Área m²", "Quartos", "Banheiros", "Endereço", "Proprietário", "Parceria", "Escritura"];
    const rows = filtered.map(i => [
      i.titulo || "", i.tipo || "", i.status || "",
      i.valor || "0", i.area || "0", i.quartos || "0", i.banheiros || "0",
      (i.endereco || "").replace(/,/g, ";"),
      i.nomeProprietario || "",
      i.parceria ? "Sim" : "Não",
      i.tipoEscritura || "",
    ]);
    const csv = [header, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "imoveis-imovelPro.csv"; a.click();
    URL.revokeObjectURL(url);
  };
  const abrirEditar = (im) => {
    setForm({
      titulo: im.titulo, tipo: im.tipo, valor: String(im.valor), area: String(im.area),
      quartos: String(im.quartos || ""), banheiros: String(im.banheiros || ""),
      endereco: im.endereco || "", descricao: im.descricao || "", status: im.status,
      garagem: im.garagem || false, quintal: im.quintal || false,
      parceria: im.parceria || false, nomeParceiroCorretor: im.nomeParceiroCorretor || "",
      nomeProprietario: im.nomeProprietario || "", telefoneProprietario: im.telefoneProprietario || "",
      valorPedidoProprietario: String(im.valorPedidoProprietario || ""),
      documentacaoCompleta: im.documentacaoCompleta || false,
      tipoEscritura: im.tipoEscritura || "Nenhuma",
      latitude: im.latitude || null,
      longitude: im.longitude || null,
    });
    setFotos(im.fotos || []);
    setEditId(im.id);
    setView("form");
  };

  const buscarLocalizacaoAtual = () => {
    if (!navigator.geolocation) {
      alert("Seu navegador não suporta GPS. Digite o endereço manualmente.");
      return;
    }
    setBuscandoLocal(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&addressdetails=1`,
            { headers: { "Accept-Language": "pt-BR" } }
          );
          const data = await res.json();
          if (data && data.display_name) {
            const a = data.address || {};
            const partes = [
              a.road || a.pedestrian || a.footway || "",
              a.house_number || "",
              a.suburb || a.neighbourhood || a.quarter || "",
              a.city || a.town || a.village || a.municipality || "",
              a.state || "",
            ].filter(Boolean);
            const enderecoFormatado = partes.join(", ");
            f("endereco", enderecoFormatado || data.display_name);
            f("latitude", latitude);
            f("longitude", longitude);
          } else {
            alert("Não foi possível converter a localização. Digite o endereço manualmente.");
          }
        } catch (e) {
          alert("Erro ao buscar endereço: " + e.message);
        }
        setBuscandoLocal(false);
      },
      (err) => {
        setBuscandoLocal(false);
        if (err.code === 1) alert("Permissão de localização negada. Libere o GPS nas configurações do navegador.");
        else if (err.code === 2) alert("Localização indisponível. Tente novamente.");
        else alert("Erro ao obter localização. Tente novamente.");
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const salvar = async () => {
    if (!form.titulo.trim()) return alert("Digite o título do imóvel");
    if (fotos.some(f => f.uploading)) {
      const ok = window.confirm("Algumas fotos ainda estão sendo enviadas. Salvar mesmo assim? As fotos em andamento não serão salvas.");
      if (!ok) return;
    }
    setSaving(true);
    const fotosInfo = fotos.filter(f2 => !f2.uploading).map(f2 => ({ nome: f2.nome || "foto", url: f2.url || "" }));
    const dados = {
      ...form,
      valor: Number(form.valor) || 0,
      area: Number(form.area) || 0,
      quartos: Number(form.quartos) || 0,
      banheiros: Number(form.banheiros) || 0,
      valorPedidoProprietario: Number(form.valorPedidoProprietario) || 0,
      fotos: fotosInfo,
      uid,
      updatedAt: serverTimestamp()
    };
    try {
      if (editId) {
        await updateDoc(doc(db, "imoveis", editId), dados);
      } else {
        await addDoc(collection(db, "imoveis"), { ...dados, createdAt: serverTimestamp() });
      }
      setView("list");
    } catch (e) { alert("Erro ao salvar: " + e.message); }
    setSaving(false);
  };

  const excluir = async () => {
    try { await deleteDoc(doc(db, "imoveis", deleteId)); } catch (e) { alert("Erro: " + e.message); }
    setDeleteId(null);
    setView("list");
  };

  const handleFotos = async (e) => {
    const files = Array.from(e.target.files);
    for (const file of files) {
      try {
        const uid = `${file.name}_${Date.now()}_${Math.random()}`;
        await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = ev => {
            setFotos(prev => [...prev, { url: ev.target.result, nome: file.name, uploading: true, _uid: uid }]);
            resolve();
          };
          reader.readAsDataURL(file);
        });
        const url = await uploadFoto(file);
        setFotos(prev => prev.map(fx => fx._uid === uid ? { url, nome: file.name, uploading: false, _uid: uid } : fx));
      } catch(err) { console.error("Erro upload foto:", err); }
    }
  };

  const handleGerarDescricaoIA = async () => {
    if (fotos.length === 0) return alert("Adicione pelo menos uma foto antes de gerar a descrição.");
    if (fotos.some(f => f.uploading)) return alert("Aguarde todas as fotos terminarem de carregar antes de gerar a descrição.");
    if (fotos.filter(f => !f.uploading).length === 0) return alert("Adicione pelo menos uma foto antes de gerar a descrição.");
    setGerandoDesc(true);
    try {
      const descricao = await gerarDescricaoIA(fotos, form);
      f("descricao", descricao);
    } catch (e) { alert("Erro ao gerar descrição: " + e.message); }
    setGerandoDesc(false);
  };

  const handleGerarCartaz = async () => {
    setShowCartaz(true);
    setGerandoCartaz(true);
    setDadosCartaz(null);
    try {
      const dados = await gerarTextoCartazIA(detalhe);
      setDadosCartaz(dados);
    } catch (e) { alert("Erro ao gerar cartaz: " + e.message); setShowCartaz(false); }
    setGerandoCartaz(false);
  };

  const statusColors = { "Disponível": "green", "Vendido": "red", "Locação": "blue" };

  // 🔍 Filtragem avançada
  const filtered = imoveis.filter(i => {
    if (filter !== "Todos" && i.status !== filter) return false;
    if (filtroTipo !== "Todos" && i.tipo !== filtroTipo) return false;
    if (filtroValorMin && Number(i.valor) < Number(filtroValorMin)) return false;
    if (filtroValorMax && Number(i.valor) > Number(filtroValorMax)) return false;
    if (filtroQuartos !== "Todos") {
      const q = Number(i.quartos) || 0;
      if (filtroQuartos === "1" && q !== 1) return false;
      if (filtroQuartos === "2" && q !== 2) return false;
      if (filtroQuartos === "3" && q !== 3) return false;
      if (filtroQuartos === "4+" && q < 4) return false;
    }
    if (busca.trim()) {
      const b = busca.toLowerCase();
      const match = (i.titulo || "").toLowerCase().includes(b)
        || (i.endereco || "").toLowerCase().includes(b)
        || (i.descricao || "").toLowerCase().includes(b)
        || (i.nomeProprietario || "").toLowerCase().includes(b)
        || (i.tipo || "").toLowerCase().includes(b);
      if (!match) return false;
    }
    return true;
  });

  const temFiltroAtivo = filtroTipo !== "Todos" || filtroValorMin || filtroValorMax || filtroQuartos !== "Todos";
  const detalhe = detalheId ? imoveis.find(i => i.id === detalheId) : null;

  // ── DETALHE ──
  if (view === "detalhe" && detalhe) {
    const fs = detalhe.fotos || [];
    return (
      <div>
        {deleteId && <ConfirmModal msg={`Excluir "${detalhe.titulo}"?`} onOk={excluir} onCancel={() => setDeleteId(null)} />}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
          <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
          <h2 style={{ color: COLORS.text, margin: 0, fontSize: 17, fontWeight: 800, flex: 1 }}>{detalhe.titulo}</h2>
          <Badge color={statusColors[detalhe.status]}>{detalhe.status}</Badge>
        </div>

        {/* Galeria de fotos */}
        {fs.length > 0 && (
          <div style={{ position: "relative", borderRadius: 16, overflow: "hidden", marginBottom: 16 }}>
            <img src={fs[fotoIdx]?.url || fs[fotoIdx]} alt="" style={{ width: "100%", height: 220, objectFit: "cover", display: "block" }} />
            {fs.length > 1 && (
              <>
                <button onClick={() => setFotoIdx(i => (i - 1 + fs.length) % fs.length)} style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 34, height: 34, color: "#fff", cursor: "pointer", fontSize: 18, fontWeight: 700 }}>‹</button>
                <button onClick={() => setFotoIdx(i => (i + 1) % fs.length)} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 34, height: 34, color: "#fff", cursor: "pointer", fontSize: 18, fontWeight: 700 }}>›</button>
                <div style={{ position: "absolute", bottom: 10, right: 12, background: "rgba(0,0,0,0.7)", borderRadius: 20, padding: "3px 10px", color: "#fff", fontSize: 11, fontWeight: 700 }}>{fotoIdx + 1}/{fs.length}</div>
              </>
            )}
            {/* Miniaturas */}
            {fs.length > 1 && (
              <div style={{ display: "flex", gap: 6, padding: 10, background: "rgba(0,0,0,0.4)", overflowX: "auto" }}>
                {fs.map((ft, i) => (
                  <div key={i} onClick={() => setFotoIdx(i)} style={{ flexShrink: 0, width: 50, height: 50, borderRadius: 8, overflow: "hidden", border: `2px solid ${i === fotoIdx ? COLORS.accent : "transparent"}`, cursor: "pointer" }}>
                    <img src={ft.url || ft} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <Card style={{ marginBottom: 12 }}>
          <div style={{ color: COLORS.accent, fontSize: 22, fontWeight: 900, marginBottom: 4 }}>R$ {Number(detalhe.valor).toLocaleString("pt-BR")}</div>
          <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 14 }}>{detalhe.endereco}</div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 14 }}>
            {[
              { icon: "📐", val: `${detalhe.area}m²` },
              detalhe.quartos && { icon: "🛏️", val: `${detalhe.quartos} quartos` },
              detalhe.banheiros && { icon: "🚿", val: `${detalhe.banheiros} ban.` },
              detalhe.garagem && { icon: "🚗", val: "Garagem" },
              detalhe.quintal && { icon: "🌿", val: "Quintal" },
            ].filter(Boolean).map((d, i) => (
              <span key={i} style={{ color: COLORS.text, fontSize: 12, background: COLORS.surface, padding: "4px 10px", borderRadius: 20 }}>{d.icon} {d.val}</span>
            ))}
          </div>
          {detalhe.descricao && <div style={{ color: COLORS.muted, fontSize: 13, lineHeight: 1.6, marginBottom: 8 }}>{detalhe.descricao}</div>}
        </Card>

        {/* Proprietário */}
        {(detalhe.nomeProprietario || detalhe.telefoneProprietario) && (
          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, marginBottom: 10, textTransform: "uppercase" }}>👤 Proprietário</div>
            {[
              detalhe.nomeProprietario && ["Nome", detalhe.nomeProprietario],
              detalhe.telefoneProprietario && ["Telefone", detalhe.telefoneProprietario],
              detalhe.valorPedidoProprietario && ["Valor pedido", `R$ ${Number(detalhe.valorPedidoProprietario).toLocaleString("pt-BR")}`],
            ].filter(Boolean).map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
                <span style={{ color: COLORS.muted, fontSize: 13 }}>{k}</span>
                <span style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{v}</span>
              </div>
            ))}
            {detalhe.telefoneProprietario && (
              <Btn full color="green" style={{ marginTop: 12 }} onClick={() => abrirWhatsApp(`https://wa.me/55${detalhe.telefoneProprietario.replace(/\D/g, "")}`)}>💬 WhatsApp Proprietário</Btn>
            )}
          </Card>
        )}

        {/* Parceria / Documentação */}
        <Card style={{ marginBottom: 12 }}>
          <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, marginBottom: 10, textTransform: "uppercase" }}>📋 Informações Extras</div>
          {[
            ["🤝 Parceria", detalhe.parceria ? (detalhe.nomeParceiroCorretor ? `Sim — ${detalhe.nomeParceiroCorretor}` : "Sim") : "Não"],
            ["📄 Documentação", detalhe.documentacaoCompleta ? "✅ Completa" : "⚠️ Incompleta"],
            ["📜 Escritura", detalhe.tipoEscritura || "Não informada"],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
              <span style={{ color: COLORS.muted, fontSize: 13 }}>{k}</span>
              <span style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{v}</span>
            </div>
          ))}
        </Card>

        {/* Mapa de Localização */}
        {(detalhe.endereco || (detalhe.latitude && detalhe.longitude)) && (
          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, marginBottom: 10, textTransform: "uppercase" }}>📍 Localização no Mapa</div>
            <div style={{ borderRadius: 12, overflow: "hidden", marginBottom: 10 }}>
              <iframe
                title="Mapa do imóvel"
                width="100%"
                height="220"
                style={{ border: "none", display: "block" }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                src={
                  detalhe.latitude && detalhe.longitude
                    ? `https://maps.google.com/maps?q=${detalhe.latitude},${detalhe.longitude}&output=embed&z=17`
                    : `https://maps.google.com/maps?q=${encodeURIComponent(detalhe.endereco)}&output=embed&z=16`
                }
              />
            </div>
            {detalhe.latitude && detalhe.longitude && (
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8, padding: "5px 8px", background: COLORS.surface, borderRadius: 8 }}>
                <span style={{ fontSize: 12 }}>🎯</span>
                <span style={{ color: COLORS.green, fontSize: 11, fontWeight: 600 }}>Localização exata via GPS</span>
              </div>
            )}
            <Btn
              full
              color="surface"
              onClick={() => window.open(
                detalhe.latitude && detalhe.longitude
                  ? `https://www.google.com/maps/search/?api=1&query=${detalhe.latitude},${detalhe.longitude}`
                  : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(detalhe.endereco)}`,
                "_blank"
              )}
            >
              🗺️ Abrir no Google Maps
            </Btn>
          </Card>
        )}

        <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
          <Btn full color="blue" onClick={() => abrirEditar(detalhe)}>✏️ Editar</Btn>
          <Btn color="red" onClick={() => setDeleteId(detalhe.id)}>🗑️</Btn>
        </div>
        <Btn full color="purple" onClick={handleGerarCartaz} style={{ marginBottom: 8 }}>🪧 Gerar Cartaz com IA</Btn>
        <Btn full color="green" onClick={() => setShowCompartilhar(true)}>💬 Compartilhar no WhatsApp</Btn>

        {/* ── MODAL COMPARTILHAR WHATSAPP ── */}
        {showCompartilhar && (() => {
          const im = detalhe;
          const nomeCorretor = perfilData?.nome
            ? `${perfilData.nome}${perfilData.sobrenome ? " " + perfilData.sobrenome : ""}`
            : "Corretor";
          const telCorretor = perfilData?.telefone?.replace(/\D/g, "") || "";
          const creci = perfilData?.creci ? `CRECI ${perfilData.creci}` : "";
          const instagram = perfilData?.instagram ? `📸 @${perfilData.instagram.replace("@", "")}` : "";
          const valor = `R$ ${Number(im.valor).toLocaleString("pt-BR")}`;
          const extras = [im.garagem && "🚗 Garagem", im.quintal && "🌿 Quintal"].filter(Boolean).join(" | ");
          const linkMaps = im.latitude && im.longitude
            ? `https://maps.google.com/?q=${im.latitude},${im.longitude}`
            : im.endereco ? `https://maps.google.com/?q=${encodeURIComponent(im.endereco)}` : "";

          const modelos = [
            {
              id: "direto",
              icon: "⚡",
              label: "Direto ao Ponto",
              cor: "#3B82F6",
              texto: `🏠 *${im.titulo}*\n📍 ${im.endereco}\n💰 ${valor}\n📐 ${im.area}m²${im.quartos ? ` | 🛏️ ${im.quartos} qtos` : ""}${im.banheiros ? ` | 🚿 ${im.banheiros} ban.` : ""}${extras ? "\n" + extras : ""}\n\n👤 ${nomeCorretor}${creci ? ` — ${creci}` : ""}${telCorretor ? `\n📱 (${telCorretor.slice(0,2)}) ${telCorretor.slice(2,7)}-${telCorretor.slice(7)}` : ""}\n\nInteressado? Me chame! 👇`,
            },
            {
              id: "completo",
              icon: "🌟",
              label: "Apresentação Completa",
              cor: "#F59E0B",
              texto: `✨ *Oportunidade Imperdível!*\n\n🏠 *${im.titulo}*\n\n📍 *Localização:* ${im.endereco}${linkMaps ? `\n🗺️ Ver no Mapa: ${linkMaps}` : ""}\n\n💰 *Valor:* ${valor}\n\n📋 *Detalhes:*\n• 📐 Área: ${im.area}m²${im.quartos ? `\n• 🛏️ Quartos: ${im.quartos}` : ""}${im.banheiros ? `\n• 🚿 Banheiros: ${im.banheiros}` : ""}${im.garagem ? "\n• 🚗 Garagem" : ""}${im.quintal ? "\n• 🌿 Quintal" : ""}${im.documentacaoCompleta ? "\n• ✅ Documentação completa" : ""}\n${im.descricao ? `\n📝 ${im.descricao.slice(0, 150)}${im.descricao.length > 150 ? "..." : ""}\n` : ""}\n🤝 *${nomeCorretor}*${creci ? `\n🏅 ${creci}` : ""}${telCorretor ? `\n📱 ${telCorretor}` : ""}${instagram ? `\n${instagram}` : ""}\n\nAgende sua visita! 📅`,
            },
            {
              id: "visita",
              icon: "📅",
              label: "Convite para Visita",
              cor: "#10B981",
              texto: `Olá! 👋\n\nTenho um imóvel que pode ser exatamente o que você procura:\n\n🏠 *${im.titulo}*\n📍 ${im.endereco}\n💰 ${valor}${im.quartos ? ` | 🛏️ ${im.quartos} quartos` : ""}${im.area ? ` | 📐 ${im.area}m²` : ""}\n\nGostaria de agendar uma visita? Tenho horários disponíveis essa semana! 🗓️\n\n${nomeCorretor}${creci ? ` — ${creci}` : ""}`,
            },
          ];

          return (
            <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 1100,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end" }}>
              <div style={{ background: "#111827", borderRadius: "24px 24px 0 0", width: "100%", maxWidth: 430,
                maxHeight: "90vh", overflowY: "auto", padding: 20, paddingBottom: 32 }}>

                {/* Header */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                  <div>
                    <div style={{ color: "#F1F5F9", fontWeight: 900, fontSize: 17 }}>💬 Compartilhar no WhatsApp</div>
                    <div style={{ color: "#64748B", fontSize: 12, marginTop: 2 }}>Escolha o modelo de mensagem</div>
                  </div>
                  <button onClick={() => setShowCompartilhar(false)}
                    style={{ background: "#1E293B", border: "none", borderRadius: "50%", width: 34, height: 34,
                      color: "#F1F5F9", cursor: "pointer", fontSize: 18, fontWeight: 700 }}>×</button>
                </div>

                {/* Preview do imóvel */}
                <div style={{ background: "#1E293B", borderRadius: 14, padding: "12px 14px", marginBottom: 18,
                  display: "flex", gap: 12, alignItems: "center" }}>
                  {(im.fotos?.[0]?.url || im.fotos?.[0]) ? (
                    <img src={im.fotos[0]?.url || im.fotos[0]} alt=""
                      style={{ width: 52, height: 52, borderRadius: 10, objectFit: "cover", flexShrink: 0 }} />
                  ) : (
                    <div style={{ width: 52, height: 52, borderRadius: 10, background: "#0A0E1A",
                      display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>🏠</div>
                  )}
                  <div style={{ minWidth: 0 }}>
                    <div style={{ color: "#F1F5F9", fontWeight: 800, fontSize: 14,
                      whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{im.titulo}</div>
                    <div style={{ color: "#F59E0B", fontWeight: 700, fontSize: 13 }}>{valor}</div>
                    <div style={{ color: "#64748B", fontSize: 11 }}>{im.endereco}</div>
                  </div>
                </div>

                {/* Modelos */}
                {modelos.map(m => (
                  <div key={m.id} style={{ marginBottom: 12 }}>
                    <button
                      onClick={() => {
                        abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(m.texto)}`);
                        setShowCompartilhar(false);
                      }}
                      style={{ width: "100%", background: "#1E293B", border: `1.5px solid #1E293B`,
                        borderRadius: 14, padding: "14px 16px", cursor: "pointer", textAlign: "left",
                        transition: "all 0.15s" }}
                      onMouseEnter={e => e.currentTarget.style.borderColor = m.cor}
                      onMouseLeave={e => e.currentTarget.style.borderColor = "#1E293B"}
                    >
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                        <span style={{ fontSize: 18 }}>{m.icon}</span>
                        <span style={{ color: m.cor, fontWeight: 800, fontSize: 14 }}>{m.label}</span>
                        <span style={{ marginLeft: "auto", background: m.cor, color: "#0A0E1A",
                          fontSize: 11, fontWeight: 800, padding: "3px 10px", borderRadius: 20 }}>Enviar ↗</span>
                      </div>
                      <div style={{ color: "#475569", fontSize: 11, lineHeight: 1.5,
                        whiteSpace: "pre-line", maxHeight: 60, overflow: "hidden",
                        WebkitMaskImage: "linear-gradient(to bottom, black 60%, transparent 100%)" }}>
                        {m.texto}
                      </div>
                    </button>
                  </div>
                ))}

                {/* Enviar para cliente específico */}
                {perfilData?.telefone && (
                  <div style={{ marginTop: 4, padding: "12px 14px", background: "#064E3B",
                    border: "1px solid #10B981", borderRadius: 12 }}>
                    <div style={{ color: "#6EE7B7", fontSize: 11, fontWeight: 700, marginBottom: 2 }}>
                      💡 Dica
                    </div>
                    <div style={{ color: "#94A3B8", fontSize: 12 }}>
                      Selecione o modelo → abrirá o WhatsApp para você escolher o contato do cliente.
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })()}

        {/* Modal Cartaz IA */}
        {showCartaz && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 1000, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 16 }}>
            <div style={{ background: COLORS.card, borderRadius: 20, width: "100%", maxWidth: 440, maxHeight: "90vh", overflowY: "auto", padding: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <h3 style={{ color: COLORS.accent, margin: 0, fontSize: 16, fontWeight: 800 }}>🪧 Cartaz Imobiliário IA</h3>
                <button onClick={() => { setShowCartaz(false); setDadosCartaz(null); }} style={{ background: COLORS.surface, border: "none", borderRadius: "50%", width: 32, height: 32, color: COLORS.text, cursor: "pointer", fontSize: 16, fontWeight: 700 }}>×</button>
              </div>
              {gerandoCartaz ? (
                <div style={{ textAlign: "center", padding: 40 }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>✨</div>
                  <div style={{ color: COLORS.muted, fontSize: 14 }}>A IA está criando seu cartaz...</div>
                </div>
              ) : dadosCartaz ? (
                <div>
                  {/* Preview do Cartaz */}
                  <div style={{ background: "linear-gradient(135deg, #1E293B 0%, #0F172A 100%)", borderRadius: 16, overflow: "hidden", marginBottom: 16, border: `2px solid ${COLORS.accent}` }}>
                    {/* Foto principal */}
                    {detalhe.fotos && detalhe.fotos.length > 0 && (
                      <div style={{ position: "relative" }}>
                        <img src={detalhe.fotos[0]?.url || detalhe.fotos[0]} alt="" style={{ width: "100%", height: 200, objectFit: "cover", display: "block" }} />
                        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 40%, rgba(10,14,26,0.95) 100%)" }} />
                        <div style={{ position: "absolute", bottom: 12, left: 14, right: 14 }}>
                          <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 2, marginBottom: 4 }}>{detalhe.tipo} • {detalhe.status}</div>
                          <div style={{ color: "#fff", fontSize: 18, fontWeight: 900, lineHeight: 1.2 }}>{dadosCartaz.slogan}</div>
                        </div>
                      </div>
                    )}
                    <div style={{ padding: 16 }}>
                      <div style={{ color: COLORS.accent, fontSize: 26, fontWeight: 900, marginBottom: 4 }}>R$ {Number(detalhe.valor).toLocaleString("pt-BR")}</div>
                      <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 16 }}>📍 {detalhe.endereco}</div>
                      {/* Destaques */}
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
                        {[dadosCartaz.destaque1, dadosCartaz.destaque2, dadosCartaz.destaque3].map((d, i) => (
                          <div key={i} style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 10, padding: "8px 6px", textAlign: "center" }}>
                            <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700 }}>{d}</div>
                          </div>
                        ))}
                      </div>
                      {/* Specs */}
                      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 14 }}>
                        {[
                          { icon: "📐", val: `${detalhe.area}m²` },
                          detalhe.quartos && { icon: "🛏️", val: `${detalhe.quartos} quartos` },
                          detalhe.banheiros && { icon: "🚿", val: `${detalhe.banheiros} ban.` },
                          detalhe.garagem && { icon: "🚗", val: "Garagem" },
                        ].filter(Boolean).map((d, i) => (
                          <span key={i} style={{ color: COLORS.text, fontSize: 12, background: COLORS.surface, padding: "4px 10px", borderRadius: 20 }}>{d.icon} {d.val}</span>
                        ))}
                      </div>
                      {/* CTA */}
                      <div style={{ background: COLORS.accent, borderRadius: 10, padding: "12px 16px", textAlign: "center" }}>
                        <div style={{ color: "#0A0E1A", fontWeight: 900, fontSize: 14 }}>{dadosCartaz.chamada}</div>
                      </div>
                    </div>
                  </div>
                  <Btn full color="green" onClick={() => {
                    const msg = `🏠 *${dadosCartaz.slogan}*\n\n📍 ${detalhe.endereco}\n💰 R$ ${Number(detalhe.valor).toLocaleString("pt-BR")}\n📐 ${detalhe.area}m² | 🛏️ ${detalhe.quartos} qtos\n\n✨ ${dadosCartaz.destaque1} | ${dadosCartaz.destaque2} | ${dadosCartaz.destaque3}\n\n${dadosCartaz.chamada}`;
                    abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`);
                  }}>💬 Compartilhar Cartaz no WhatsApp</Btn>
                  <Btn full color="surface" style={{ marginTop: 8 }} onClick={handleGerarCartaz}>🔄 Gerar Novamente</Btn>
                </div>
              ) : null}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── FORMULÁRIO ──
  if (view === "form") return (
    <div>
      {deleteId && <ConfirmModal msg={`Excluir "${form.titulo}"?`} onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{editId ? "✏️ Editar Imóvel" : "➕ Novo Imóvel"}</h2>
      </div>
      <Card>

        <SecaoForm titulo="📋 Dados Básicos">
          <Input label="Título do Imóvel" value={form.titulo} onChange={v => f("titulo", v)} placeholder="Ex: Apartamento Vista Mar" />
          <Sel label="Tipo" value={form.tipo} onChange={v => f("tipo", v)} options={["Apartamento", "Casa", "Comercial", "Terreno", "Cobertura"]} />
          <Input label="Valor Anunciado (R$)" type="number" value={form.valor} onChange={v => f("valor", v)} placeholder="850000" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
            <Input label="Área m²" type="number" value={form.area} onChange={v => f("area", v)} placeholder="120" />
            <Input label="Quartos" type="number" value={form.quartos} onChange={v => f("quartos", v)} placeholder="3" />
            <Input label="Banheiros" type="number" value={form.banheiros} onChange={v => f("banheiros", v)} placeholder="2" />
          </div>
          <Input label="Endereço" value={form.endereco} onChange={v => { f("endereco", v); f("latitude", null); f("longitude", null); }} placeholder="Rua das Flores, 123" />
          {form.latitude && form.longitude ? (
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              <button
                onClick={() => window.open(`https://www.google.com/maps/search/?api=1&query=${form.latitude},${form.longitude}`, "_blank")}
                style={{ flex: 1, background: COLORS.green, border: "none", borderRadius: 10, padding: "11px 0", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}
              >
                🗺️ Ver no mapa
              </button>
              <button
                onClick={buscarLocalizacaoAtual}
                disabled={buscandoLocal}
                style={{ flex: 1, background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "11px 0", color: COLORS.muted, fontWeight: 700, fontSize: 13, cursor: buscandoLocal ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, opacity: buscandoLocal ? 0.6 : 1 }}
              >
                {buscandoLocal ? "⏳ Buscando..." : "🔄 Atualizar GPS"}
              </button>
              <button
                onClick={() => { f("latitude", null); f("longitude", null); }}
                style={{ background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "11px 14px", color: COLORS.muted, fontWeight: 700, fontSize: 14, cursor: "pointer" }}
                title="Remover localização GPS"
              >
                ✕
              </button>
            </div>
          ) : (
            <button
              onClick={buscarLocalizacaoAtual}
              disabled={buscandoLocal}
              style={{ width: "100%", background: buscandoLocal ? COLORS.surface : COLORS.blue, border: "none", borderRadius: 10, padding: "11px 0", color: buscandoLocal ? COLORS.muted : "#fff", fontWeight: 700, fontSize: 13, cursor: buscandoLocal ? "not-allowed" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 4, opacity: buscandoLocal ? 0.7 : 1 }}
            >
              {buscandoLocal ? "⏳ Buscando localização..." : "📍 Usar minha localização atual"}
            </button>
          )}
          <Input label="Descrição" value={form.descricao} onChange={v => f("descricao", v)} placeholder="Descreva o imóvel..." />
          <Sel label="Status" value={form.status} onChange={v => f("status", v)} options={["Disponível", "Vendido", "Locação"]} />
        </SecaoForm>

        <SecaoForm titulo="🏠 Características">
          <Toggle label="🚗 Tem Garagem" value={form.garagem} onChange={v => f("garagem", v)} />
          <Toggle label="🌿 Tem Quintal" value={form.quintal} onChange={v => f("quintal", v)} />
        </SecaoForm>

        <SecaoForm titulo="👤 Proprietário">
          <Input label="Nome do Proprietário" value={form.nomeProprietario} onChange={v => f("nomeProprietario", v)} placeholder="Ex: José da Silva" />
          <Input label="Telefone do Proprietário" value={form.telefoneProprietario} onChange={v => f("telefoneProprietario", v)} placeholder="(85) 99999-0000" />
          <Input label="Valor Pedido pelo Proprietário (R$)" type="number" value={form.valorPedidoProprietario} onChange={v => f("valorPedidoProprietario", v)} placeholder="900000" />
        </SecaoForm>

        <SecaoForm titulo="🤝 Parceria">
          <Toggle label="Imóvel em parceria com outro corretor" value={form.parceria} onChange={v => f("parceria", v)} />
          {form.parceria && (
            <Input label="Nome do Corretor Parceiro" value={form.nomeParceiroCorretor} onChange={v => f("nomeParceiroCorretor", v)} placeholder="Ex: Maria Oliveira CRECI 12345" />
          )}
        </SecaoForm>

        <SecaoForm titulo="📄 Documentação">
          <Toggle label="✅ Documentação Completa" value={form.documentacaoCompleta} onChange={v => f("documentacaoCompleta", v)} />
          <div style={{ marginTop: 4 }}>
            <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 8, fontWeight: 600, textTransform: "uppercase" }}>Tipo de Escritura</label>
            <div style={{ display: "flex", gap: 8 }}>
              {["Nenhuma", "Pública", "Particular"].map(op => (
                <button key={op} onClick={() => f("tipoEscritura", op)} style={{ flex: 1, padding: "10px 0", background: form.tipoEscritura === op ? COLORS.accent : COLORS.surface, color: form.tipoEscritura === op ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 12 }}>{op}</button>
              ))}
            </div>
          </div>
        </SecaoForm>

        <SecaoForm titulo="📷 Fotos">
          <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleFotos} style={{ display: "none" }} />
          <div onClick={() => fileRef.current.click()} style={{ background: COLORS.surface, borderRadius: 12, padding: 20, textAlign: "center", border: `2px dashed ${COLORS.cardBorder}`, cursor: "pointer" }}>
            <div style={{ fontSize: 32 }}>📷</div>
            <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 700, marginTop: 6 }}>Toque para adicionar fotos</div>
            <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>Passe entre as fotos no carrossel abaixo</div>
          </div>
          <FotoCarousel fotos={fotos} onRemove={i => setFotos(prev => prev.filter((_, j) => j !== i))} />
          {fotos.length > 0 && (
            <Btn full color="purple" onClick={handleGerarDescricaoIA} style={{ opacity: (gerandoDesc || fotos.some(f => f.uploading)) ? 0.6 : 1, marginTop: 8 }}>
              {gerandoDesc ? "✨ A IA está analisando as fotos..." : fotos.some(f => f.uploading) ? "⏳ Aguardando upload das fotos..." : "✨ Descrever Imóvel com IA"}
            </Btn>
          )}
        </SecaoForm>

        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando na nuvem..." : `💾 ${editId ? "Salvar Alterações" : "Cadastrar Imóvel"}`}
        </Btn>
        {editId && <Btn full color="red" onClick={() => setDeleteId(editId)} style={{ marginTop: 10 }}>🗑️ Excluir Este Imóvel</Btn>}
      </Card>
    </div>
  );

  // ── LISTA ──
  return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir este imóvel?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>🏢 Imóveis</h2>
        <div style={{ display: "flex", gap: 8 }}>
          {imoveis.length > 0 && <Btn color="surface" size="sm" onClick={exportarImoveisCSV} style={{ fontSize: 11 }}>📤 CSV</Btn>}
          <Btn size="sm" onClick={abrirNovo}>+ Adicionar</Btn>
        </div>
      </div>

      {/* 🔍 Barra de busca */}
      <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
        <div style={{ flex: 1, position: "relative" }}>
          <span style={{ position: "absolute", left: 12, top: "50%", transform: "translateY(-50%)", fontSize: 15, color: COLORS.muted }}>🔍</span>
          <input
            value={busca}
            onChange={e => setBusca(e.target.value)}
            placeholder="Buscar por título, endereço, tipo..."
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${busca ? COLORS.accent : COLORS.cardBorder}`, borderRadius: 10, padding: "10px 12px 10px 36px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", outline: "none" }}
          />
          {busca && (
            <button onClick={() => setBusca("")} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: COLORS.muted, cursor: "pointer", fontSize: 16, padding: 0, lineHeight: 1 }}>×</button>
          )}
        </div>
        <button
          onClick={() => setShowFiltros(v => !v)}
          style={{ background: temFiltroAtivo ? COLORS.accent : COLORS.surface, border: `1px solid ${temFiltroAtivo ? COLORS.accent : COLORS.cardBorder}`, borderRadius: 10, padding: "0 14px", color: temFiltroAtivo ? "#0A0E1A" : COLORS.muted, fontWeight: 700, fontSize: 13, cursor: "pointer", flexShrink: 0 }}>
          ⚙️{temFiltroAtivo ? " ●" : ""}
        </button>
      </div>

      {/* Painel de filtros avançados */}
      {showFiltros && (
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 16, marginBottom: 14 }}>
          <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 700, marginBottom: 12, textTransform: "uppercase" }}>⚙️ Filtros Avançados</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
            <div>
              <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 600, marginBottom: 4 }}>TIPO</div>
              <select value={filtroTipo} onChange={e => setFiltroTipo(e.target.value)} style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, padding: "8px 10px", color: COLORS.text, fontSize: 13 }}>
                {["Todos", "Apartamento", "Casa", "Comercial", "Terreno", "Cobertura"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 600, marginBottom: 4 }}>QUARTOS</div>
              <select value={filtroQuartos} onChange={e => setFiltroQuartos(e.target.value)} style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, padding: "8px 10px", color: COLORS.text, fontSize: 13 }}>
                {["Todos", "1", "2", "3", "4+"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
            <div>
              <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 600, marginBottom: 4 }}>VALOR MÍN (R$)</div>
              <input type="number" value={filtroValorMin} onChange={e => setFiltroValorMin(e.target.value)} placeholder="Ex: 200000" style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, padding: "8px 10px", color: COLORS.text, fontSize: 13, boxSizing: "border-box", outline: "none" }} />
            </div>
            <div>
              <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 600, marginBottom: 4 }}>VALOR MÁX (R$)</div>
              <input type="number" value={filtroValorMax} onChange={e => setFiltroValorMax(e.target.value)} placeholder="Ex: 800000" style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, padding: "8px 10px", color: COLORS.text, fontSize: 13, boxSizing: "border-box", outline: "none" }} />
            </div>
          </div>
          <button onClick={() => { setFiltroTipo("Todos"); setFiltroValorMin(""); setFiltroValorMax(""); setFiltroQuartos("Todos"); }} style={{ background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, padding: "7px 14px", color: COLORS.muted, fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
            🔄 Limpar Filtros
          </button>
        </div>
      )}

      {/* Chips de status */}
      <div style={{ display: "flex", gap: 8, marginBottom: 14, overflowX: "auto", paddingBottom: 4 }}>
        {["Todos", "Disponível", "Vendido", "Locação"].map(fv => (
          <button key={fv} onClick={() => setFilter(fv)} style={{ background: filter === fv ? COLORS.accent : COLORS.surface, color: filter === fv ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>{fv}</button>
        ))}
      </div>

      {/* Contador de resultados */}
      {(busca || temFiltroAtivo) && (
        <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 12, fontWeight: 600 }}>
          {filtered.length === 0 ? "Nenhum imóvel encontrado" : `${filtered.length} imóvel${filtered.length > 1 ? "is" : ""} encontrado${filtered.length > 1 ? "s" : ""}`}
        </div>
      )}
      {loading ? <Loading /> : filtered.length === 0 ? (
        <Card><p style={{ color: COLORS.muted, textAlign: "center", margin: 0 }}>Nenhum imóvel encontrado.</p></Card>
      ) : filtered.map(im => (
        <Card key={im.id} style={{ marginBottom: 12, cursor: "pointer" }} onClick={() => { setDetalheId(im.id); setView("detalhe"); }}>
          {/* Carrossel de fotos deslizável na lista */}
          {im.fotos && im.fotos.length > 0 && (
            <CardCarousel fotos={im.fotos} onClick={e => e.stopPropagation()} />
          )}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
            <div style={{ flex: 1 }}>
              <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 15 }}>{im.titulo}</div>
              <div style={{ color: COLORS.muted, fontSize: 12 }}>{im.endereco}</div>
            </div>
            <Badge color={statusColors[im.status]}>{im.status}</Badge>
          </div>
          <div style={{ color: COLORS.accent, fontSize: 18, fontWeight: 800, marginBottom: 8 }}>R$ {Number(im.valor).toLocaleString("pt-BR")}</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
            {[
              { icon: "📐", val: `${im.area}m²` },
              im.quartos && { icon: "🛏️", val: `${im.quartos} qtos` },
              im.banheiros && { icon: "🚿", val: `${im.banheiros} ban` },
              im.garagem && { icon: "🚗", val: "Garagem" },
              im.quintal && { icon: "🌿", val: "Quintal" },
              im.parceria && { icon: "🤝", val: "Parceria" },
              im.documentacaoCompleta && { icon: "✅", val: "Doc. OK" },
            ].filter(Boolean).map((d, i) => (
              <span key={i} style={{ color: COLORS.muted, fontSize: 11, background: COLORS.surface, padding: "3px 8px", borderRadius: 20 }}>{d.icon} {d.val}</span>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8 }} onClick={e => e.stopPropagation()}>
            <Btn size="sm" color="blue" onClick={() => abrirEditar(im)}>✏️ Editar</Btn>
            <Btn size="sm" color="red" onClick={() => setDeleteId(im.id)}>🗑️</Btn>
            <Btn size="sm" color="green" onClick={() => {
              const extras = [im.garagem && "🚗 Garagem", im.quintal && "🌿 Quintal"].filter(Boolean).join(" | ");
              const msg = `🏠 *${im.titulo}*\n📍 ${im.endereco}\n💰 R$ ${Number(im.valor).toLocaleString("pt-BR")}\n📐 ${im.area}m²${extras ? "\n" + extras : ""}\n\nInteressado? Entre em contato!`;
              abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`);
            }}>💬 WA</Btn>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ─── CLIENTES ───
function Clientes({ clientes, loading, uid }) {
  const [view, setView] = useState("list");
  const [editId, setEditId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [selId, setSelId] = useState(null);
  const [saving, setSaving] = useState(false);
  const docProprietarioRef = useRef();
  const [uploadandoDocProp, setUploadandoDocProp] = useState(false);

  const empty = { nome: "", telefone: "", email: "", cpf: "", renda: "", interesse: "Compra", status: "Ativo" };
  const [form, setForm] = useState(empty);

  const abrirNovo = () => { setForm(empty); setEditId(null); setView("form"); };
  const abrirEditar = (c) => { setForm({ nome: c.nome, telefone: c.telefone || "", email: c.email || "", cpf: c.cpf || "", renda: String(c.renda || ""), interesse: c.interesse || "Compra", status: c.status || "Ativo" }); setEditId(c.id); setView("form"); };

  const salvar = async () => {
    if (!form.nome.trim()) return alert("Digite o nome do cliente");
    setSaving(true);
    const dados = { ...form, renda: Number(form.renda) || 0, uid, updatedAt: serverTimestamp() };
    try {
      if (editId) { await updateDoc(doc(db, "clientes", editId), dados); }
      else { await addDoc(collection(db, "clientes"), { ...dados, docsProprietario: [], createdAt: serverTimestamp() }); }
      setView("list");
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const excluir = async () => {
    try { await deleteDoc(doc(db, "clientes", deleteId)); } catch (e) { alert("Erro: " + e.message); }
    setDeleteId(null); setView("list");
  };

  const handleDocProprietario = async (e, clienteId) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploadandoDocProp(true);
    for (const file of files) {
      const nomeUnico = Date.now() + "_" + file.name;
      try {
        const url = await uploadArquivo(file);
        const snap = await getDoc(doc(db, "clientes", clienteId));
        const docsAtuais = snap.data()?.docsProprietario || [];
        await updateDoc(doc(db, "clientes", clienteId), {
          docsProprietario: [...docsAtuais, { nome: file.name, nomeUnico, tipo: file.type, url, size: (file.size / 1024).toFixed(0) }],
          updatedAt: serverTimestamp()
        });
      } catch (err) { alert("Erro ao enviar: " + file.name + "\n" + err.message); }
    }
    setUploadandoDocProp(false);
    e.target.value = "";
  };

  const removerDocProprietario = async (clienteId, idx, docsAtuais) => {
    const novos = docsAtuais.filter((_, i) => i !== idx);
    await updateDoc(doc(db, "clientes", clienteId), { docsProprietario: novos, updatedAt: serverTimestamp() });
  };

  const sel = selId ? clientes.find(c => c.id === selId) : null;

  if (view === "detalhe" && sel) return (
    <div>
      {deleteId && <ConfirmModal msg={`Excluir ${sel.nome}?`} onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <input ref={docProprietarioRef} type="file" multiple accept="image/*,.pdf,.doc,.docx" onChange={e => handleDocProprietario(e, sel.id)} style={{ display: "none" }} />
      <Btn color="surface" size="sm" onClick={() => setView("list")} style={{ marginBottom: 16 }}>← Voltar</Btn>
      <Card style={{ marginBottom: 12 }}>
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div style={{ width: 64, height: 64, borderRadius: "50%", background: COLORS.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, margin: "0 auto 10px" }}>👤</div>
          <div style={{ color: COLORS.text, fontWeight: 800, fontSize: 20 }}>{sel.nome}</div>
          <Badge color="green">{sel.status}</Badge>
        </div>
        {[["📱 WhatsApp", sel.telefone], ["📧 Email", sel.email], ["🪪 CPF", sel.cpf], ["💵 Renda", `R$ ${Number(sel.renda).toLocaleString("pt-BR")}`], ["🎯 Interesse", sel.interesse]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ color: COLORS.muted, fontSize: 13 }}>{k}</span>
            <span style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{v}</span>
          </div>
        ))}
        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
          <Btn full color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${(sel.telefone || "").replace(/\D/g, "")}`)}>💬 WhatsApp</Btn>
          <Btn full color="surface" onClick={() => window.open(`mailto:${sel.email}`, "_blank")}>📧 Email</Btn>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
          <Btn full color="blue" onClick={() => abrirEditar(sel)}>✏️ Editar</Btn>
          <Btn full color="red" onClick={() => setDeleteId(sel.id)}>🗑️ Excluir</Btn>
        </div>
      </Card>

      {/* ── Documentos do Proprietário ── */}
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <h3 style={{ color: COLORS.text, margin: 0, fontSize: 15, fontWeight: 700 }}>📋 Docs do Proprietário</h3>
          <Btn size="sm" color="blue" onClick={() => docProprietarioRef.current.click()} disabled={uploadandoDocProp}>
            {uploadandoDocProp ? "⏳ Enviando..." : "📎 Anexar"}
          </Btn>
        </div>
        <div style={{ color: COLORS.muted, fontSize: 11, marginBottom: 12 }}>RG, CPF, comprovante de renda, escritura — visíveis pelo correspondente bancário</div>
        {(!sel.docsProprietario || sel.docsProprietario.length === 0) ? (
          <div style={{ textAlign: "center", padding: "20px 0", color: COLORS.muted }}>
            <div style={{ fontSize: 36 }}>📂</div>
            <div style={{ fontSize: 13, marginTop: 8 }}>Nenhum documento anexado ainda</div>
          </div>
        ) : sel.docsProprietario.map((d, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ fontSize: 24 }}>{d.tipo?.includes("image") ? "🖼️" : "📄"}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</div>
              <div style={{ color: COLORS.muted, fontSize: 11 }}>{d.size} KB</div>
            </div>
            {d.url && (
              <a href={fixUrl(d.url)} target="_blank" rel="noopener noreferrer"
                style={{ background: COLORS.blue, border: "none", borderRadius: 8, width: 32, height: 32, color: "#fff", cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", textDecoration: "none" }}>👁️</a>
            )}
            <button onClick={() => removerDocProprietario(sel.id, i, sel.docsProprietario)}
              style={{ background: COLORS.red, border: "none", borderRadius: 8, width: 32, height: 32, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>×</button>
          </div>
        ))}
      </Card>
    </div>
  );

  if (view === "form") return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir este cliente?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{editId ? "✏️ Editar Cliente" : "👤 Novo Cliente"}</h2>
      </div>
      <Card>
        <Input label="Nome Completo" value={form.nome} onChange={v => setForm({ ...form, nome: v })} placeholder="João da Silva" />
        <Input label="Telefone/WhatsApp" value={form.telefone} onChange={v => setForm({ ...form, telefone: v })} placeholder="(11) 99999-0000" />
        <Input label="E-mail" type="email" value={form.email} onChange={v => setForm({ ...form, email: v })} placeholder="cliente@email.com" />
        <Input label="CPF" value={form.cpf} onChange={v => setForm({ ...form, cpf: v })} placeholder="000.000.000-00" />
        <Input label="Renda Mensal (R$)" type="number" value={form.renda} onChange={v => setForm({ ...form, renda: v })} placeholder="10000" />
        <Sel label="Interesse" value={form.interesse} onChange={v => setForm({ ...form, interesse: v })} options={["Compra", "Locação", "Venda", "Investimento"]} />
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : `💾 ${editId ? "Salvar Alterações" : "Cadastrar Cliente"}`}
        </Btn>
        {editId && <Btn full color="red" onClick={() => setDeleteId(editId)} style={{ marginTop: 10 }}>🗑️ Excluir Cliente</Btn>}
      </Card>
    </div>
  );

  return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir este cliente?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>👥 Clientes</h2>
        <Btn size="sm" onClick={abrirNovo}>+ Adicionar</Btn>
      </div>
      {loading ? <Loading /> : clientes.length === 0 ? (
        <Card><p style={{ color: COLORS.muted, textAlign: "center", margin: 0 }}>Nenhum cliente cadastrado.</p></Card>
      ) : clientes.map(c => (
        <Card key={c.id} style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, cursor: "pointer" }} onClick={() => { setSelId(c.id); setView("detalhe"); }}>
              <div style={{ width: 46, height: 46, borderRadius: "50%", background: COLORS.surface, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>👤</div>
              <div>
                <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>{c.nome}</div>
                <div style={{ color: COLORS.muted, fontSize: 12 }}>{c.telefone}</div>
                <div style={{ color: COLORS.muted, fontSize: 11 }}>{c.interesse} • R$ {Number(c.renda).toLocaleString("pt-BR")}/mês</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
              <Btn size="sm" color="blue" onClick={() => abrirEditar(c)}>✏️</Btn>
              <Btn size="sm" color="red" onClick={() => setDeleteId(c.id)}>🗑️</Btn>
              <Btn size="sm" color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${(c.telefone || "").replace(/\D/g, "")}`)}>💬</Btn>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}


// ─── CORRESPONDENTES ───
function Correspondentes({ correspondentes, loading, uid }) {
  const [view, setView] = useState("list");
  const [editId, setEditId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [saving, setSaving] = useState(false);

  const empty = { nome: "", telefone: "", email: "", cpf: "", banco: "", observacao: "" };
  const [form, setForm] = useState(empty);

  const abrirNovo = () => { setForm(empty); setEditId(null); setView("form"); };
  const abrirEditar = (c) => {
    setForm({ nome: c.nome || "", telefone: c.telefone || "", email: c.email || "", cpf: c.cpf || "", banco: c.banco || "", observacao: c.observacao || "" });
    setEditId(c.id); setView("form");
  };

  const salvar = async () => {
    if (!form.nome.trim()) return alert("Digite o nome do correspondente");
    if (!form.telefone.trim()) return alert("Digite o WhatsApp do correspondente");
    setSaving(true);
    const dados = { ...form, uid, updatedAt: serverTimestamp() };
    try {
      if (editId) { await updateDoc(doc(db, "correspondentes", editId), dados); }
      else { await addDoc(collection(db, "correspondentes"), { ...dados, createdAt: serverTimestamp() }); }
      setView("list");
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const excluir = async () => {
    try { await deleteDoc(doc(db, "correspondentes", deleteId)); } catch (e) { alert("Erro: " + e.message); }
    setDeleteId(null); setView("list");
  };

  if (view === "form") return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir este correspondente?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{editId ? "✏️ Editar Correspondente" : "👔 Novo Correspondente"}</h2>
      </div>
      <Card>
        <Input label="Nome Completo" value={form.nome} onChange={v => setForm({ ...form, nome: v })} placeholder="Carlos Souza" />
        <Input label="WhatsApp" value={form.telefone} onChange={v => setForm({ ...form, telefone: v })} placeholder="(11) 99999-0000" />
        <Input label="E-mail" type="email" value={form.email} onChange={v => setForm({ ...form, email: v })} placeholder="correspondente@email.com" />
        <Input label="CPF" value={form.cpf} onChange={v => setForm({ ...form, cpf: v })} placeholder="000.000.000-00" />
        <Input label="Banco / Instituição" value={form.banco} onChange={v => setForm({ ...form, banco: v })} placeholder="Ex: Caixa Econômica, Bradesco..." />
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Observações</label>
          <textarea value={form.observacao} onChange={e => setForm({ ...form, observacao: e.target.value })}
            placeholder="Especialidades, taxas, regiões atendidas..."
            rows={3}
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", resize: "vertical", outline: "none", fontFamily: "'Segoe UI', system-ui, sans-serif" }} />
        </div>
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : `💾 ${editId ? "Salvar Alterações" : "Cadastrar Correspondente"}`}
        </Btn>
        {editId && <Btn full color="red" onClick={() => setDeleteId(editId)} style={{ marginTop: 10 }}>🗑️ Excluir</Btn>}
      </Card>
    </div>
  );

  return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir correspondente?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>👔 Correspondentes</h2>
        <Btn size="sm" onClick={abrirNovo}>+ Adicionar</Btn>
      </div>
      {loading ? <Loading /> : correspondentes.length === 0 ? (
        <Card>
          <div style={{ textAlign: "center", padding: "20px 0", color: COLORS.muted }}>
            <div style={{ fontSize: 48 }}>👔</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.text, marginTop: 10 }}>Nenhum correspondente cadastrado</div>
            <div style={{ fontSize: 12, marginTop: 6 }}>Cadastre seus correspondentes bancários para selecioná-los rapidamente ao abrir um processo.</div>
          </div>
        </Card>
      ) : correspondentes.map(c => (
        <Card key={c.id} style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div style={{ flex: 1 }}>
              <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 15 }}>👔 {c.nome}</div>
              {c.banco && <div style={{ color: COLORS.accent, fontSize: 12, marginTop: 2 }}>🏦 {c.banco}</div>}
              <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 2 }}>📱 {c.telefone}</div>
              {c.email && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>📧 {c.email}</div>}
              {c.observacao && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 6, fontStyle: "italic" }}>{c.observacao}</div>}
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
              <Btn size="sm" color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${(c.telefone || "").replace(/\D/g, "")}`)}>💬</Btn>
              <Btn size="sm" color="blue" onClick={() => abrirEditar(c)}>✏️</Btn>
              <Btn size="sm" color="red" onClick={() => setDeleteId(c.id)}>🗑️</Btn>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ─── BANCÁRIO ───
function Bancario({ processos, clientes, imoveis = [], loading, uid, correspondentes = [], loadingCorrespondentes = false }) {
  // sub-abas: "processos" | "correspondentes"
  const [aba, setAba] = useState("processos");

  // ── estados de processos ──
  const [view, setView] = useState("list");
  const [selId, setSelId] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef();
  const docPropRef = useRef();

  const empty = { cliente: "", banco: "Caixa Econômica", nomeCorrespondente: "", telCorrespondente: "", imovel: "", valor: "" };
  const [form, setForm] = useState(empty);
  const [clienteSelecionado, setClienteSelecionado] = useState(null); // objeto cliente completo
  const [uploadandoProp, setUploadandoProp] = useState(false);

  const bancos = ["Caixa Econômica", "Banco do Brasil", "Bradesco", "Itaú", "Santander", "Sicoob", "Sicredi"];
  const etapaCor = ["blue", "yellow", "yellow", "purple", "green", "green"];

  // ── estados de correspondentes ──
  const [corrView, setCorrView] = useState("list");
  const [corrEditId, setCorrEditId] = useState(null);
  const [corrDeleteId, setCorrDeleteId] = useState(null);
  const [corrSaving, setCorrSaving] = useState(false);
  const emptyCorr = { nome: "", telefone: "", email: "", cpf: "", banco: "", observacao: "" };
  const [corrForm, setCorrForm] = useState(emptyCorr);

  // ── handlers processos ──
  const salvar = async () => {
    if (!form.cliente) return alert("Selecione o cliente");
    setSaving(true);
    try {
      await addDoc(collection(db, "processos"), { ...form, valor: Number(form.valor) || 0, data: new Date().toISOString().split("T")[0], etapa: 0, status: "Solicitação", docs: [], uid, createdAt: serverTimestamp() });
      setForm(empty); setClienteSelecionado(null); setView("list");
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const excluir = async () => {
    try { await deleteDoc(doc(db, "processos", deleteId)); } catch (e) { alert("Erro: " + e.message); }
    setDeleteId(null); setView("list");
  };

  const avancar = async (p) => {
    if (p.etapa >= ETAPAS.length - 1) return;
    const novaEtapa = p.etapa + 1;
    await updateDoc(doc(db, "processos", p.id), { etapa: novaEtapa, status: ETAPAS[novaEtapa], updatedAt: serverTimestamp() });
  };

  const voltarEtapa = async (p) => {
    if (p.etapa <= 0) return;
    if (!window.confirm("Voltar para a etapa anterior?")) return;
    const novaEtapa = p.etapa - 1;
    await updateDoc(doc(db, "processos", p.id), { etapa: novaEtapa, status: ETAPAS[novaEtapa], updatedAt: serverTimestamp() });
  };

  const handleAnexo = async (e, pId) => {
    const files = Array.from(e.target.files);
    await Promise.all(files.map(async (file) => {
      const nomeUnico = `${Date.now()}_${file.name}`;
      const placeholder = { nome: file.name, nomeUnico, tipo: file.type, url: "", size: (file.size / 1024).toFixed(0), enviando: true };
      const snap0 = await getDoc(doc(db, "processos", pId));
      const docsAtuais0 = snap0.data()?.docs || [];
      await updateDoc(doc(db, "processos", pId), { docs: [...docsAtuais0, placeholder], updatedAt: serverTimestamp() });
      try {
        const url = await uploadArquivo(file);
        const snap1 = await getDoc(doc(db, "processos", pId));
        const docsAtuais1 = snap1.data()?.docs || [];
        const novosDocs = docsAtuais1.map(d => d.nomeUnico === nomeUnico ? { nome: file.name, nomeUnico, tipo: file.type, url, size: (file.size / 1024).toFixed(0) } : d);
        await updateDoc(doc(db, "processos", pId), { docs: novosDocs, updatedAt: serverTimestamp() });
      } catch (err) {
        const msgErro = err.message || "Erro desconhecido";
        alert("❌ Falha ao enviar: " + file.name + "\n\n" + "Detalhe: " + msgErro);
        const snap2 = await getDoc(doc(db, "processos", pId));
        const docsAtuais2 = snap2.data()?.docs || [];
        const semErro = docsAtuais2.filter(d => d.nomeUnico !== nomeUnico);
        await updateDoc(doc(db, "processos", pId), { docs: semErro, updatedAt: serverTimestamp() });
      }
    }));
  };

  // Upload de documento do proprietário vinculado ao processo
  const handleDocProprietario = async (e, pId) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    setUploadandoProp(true);
    for (const file of files) {
      const nomeUnico = Date.now() + "_" + file.name;
      try {
        const url = await uploadArquivo(file);
        const snap = await getDoc(doc(db, "processos", pId));
        const docsAtuais = snap.data()?.docsProprietario || [];
        await updateDoc(doc(db, "processos", pId), {
          docsProprietario: [...docsAtuais, { nome: file.name, nomeUnico, tipo: file.type, url, size: (file.size / 1024).toFixed(0) }],
          updatedAt: serverTimestamp()
        });
      } catch (err) { alert("Erro ao enviar: " + file.name + "\n" + err.message); }
    }
    setUploadandoProp(false);
    e.target.value = "";
  };

  const removerDocProprietario = async (pId, idx, docsAtuais) => {
    const novos = docsAtuais.filter((_, i) => i !== idx);
    await updateDoc(doc(db, "processos", pId), { docsProprietario: novos, updatedAt: serverTimestamp() });
  };

  const removerDoc = async (pId, idx) => {
    const p = processos.find(x => x.id === pId);
    const novosDocs = (p.docs || []).filter((_, i) => i !== idx);
    await updateDoc(doc(db, "processos", pId), { docs: novosDocs, updatedAt: serverTimestamp() });
  };

  const proc = selId ? processos.find(x => x.id === selId) : null;

  const enviarDocsWA = (p) => {
    const tel = (p.telCorrespondente || "").replace(/\D/g, "");
    const lista = (p.docs || []).length > 0 ? (p.docs || []).map(d => `📎 ${d.nome}`).join("\n") : "Nenhum documento ainda.";
    const msg = `📋 *Documentos — ${p.cliente}*\n🏦 ${p.banco}\n🏠 ${p.imovel}\n\n${lista}\n\n_ImóvelPro_`;
    window.open(tel ? `https://wa.me/55${tel}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank");
  };

  // ── handlers correspondentes ──
  const corrSalvar = async () => {
    if (!corrForm.nome.trim()) return alert("Digite o nome do correspondente");
    if (!corrForm.telefone.trim()) return alert("Digite o WhatsApp do correspondente");
    setCorrSaving(true);
    const dados = { ...corrForm, uid, updatedAt: serverTimestamp() };
    try {
      if (corrEditId) { await updateDoc(doc(db, "correspondentes", corrEditId), dados); }
      else { await addDoc(collection(db, "correspondentes"), { ...dados, createdAt: serverTimestamp() }); }
      setCorrView("list"); setCorrForm(emptyCorr); setCorrEditId(null);
    } catch (e) { alert("Erro: " + e.message); }
    setCorrSaving(false);
  };

  const corrExcluir = async () => {
    try { await deleteDoc(doc(db, "correspondentes", corrDeleteId)); } catch (e) { alert("Erro: " + e.message); }
    setCorrDeleteId(null); setCorrView("list");
  };

  // ── Detalhes do processo ──
  if (view === "detalhe" && proc) return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir processo?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      <input ref={fileRef} type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.zip" onChange={e => {
        if (e.target.files.length > 10) { alert("Selecione no máximo 10 arquivos por vez."); e.target.value = ""; return; }
        handleAnexo(e, proc.id); e.target.value = "";
      }} style={{ display: "none" }} />
      <input ref={docPropRef} type="file" multiple accept="image/*,.pdf,.doc,.docx" onChange={e => { handleDocProprietario(e, proc.id); e.target.value = ""; }} style={{ display: "none" }} />
      <Btn color="surface" size="sm" onClick={() => setView("list")} style={{ marginBottom: 16 }}>← Voltar</Btn>

      <Card style={{ marginBottom: 12 }}>
        <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 16, fontWeight: 700 }}>🏦 {proc.banco}</h3>
        {[["👤 Cliente", proc.cliente], ["🏠 Imóvel", proc.imovel], ["💰 Valor", `R$ ${Number(proc.valor).toLocaleString("pt-BR")}`], ["📅 Data", proc.data]].map(([k, v]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ color: COLORS.muted, fontSize: 13 }}>{k}</span>
            <span style={{ color: COLORS.text, fontSize: 13, fontWeight: 600 }}>{v}</span>
          </div>
        ))}
        {(proc.nomeCorrespondente || proc.telCorrespondente) && (
          <div style={{ marginTop: 12, background: COLORS.surface, borderRadius: 12, padding: 12 }}>
            <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, marginBottom: 6 }}>👔 CORRESPONDENTE</div>
            {proc.nomeCorrespondente && <div style={{ color: COLORS.text, fontSize: 14, fontWeight: 600 }}>{proc.nomeCorrespondente}</div>}
            {proc.telCorrespondente && (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 6 }}>
                <span style={{ color: COLORS.muted, fontSize: 13 }}>📱 {proc.telCorrespondente}</span>
                <Btn size="sm" color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${proc.telCorrespondente.replace(/\D/g, "")}`)}>💬</Btn>
              </div>
            )}
          </div>
        )}
      </Card>

      <Card style={{ marginBottom: 12 }}>
        <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 15, fontWeight: 700 }}>📊 Andamento</h3>
        {ETAPAS.map((etapa, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: i < proc.etapa ? COLORS.green : i === proc.etapa ? COLORS.accent : COLORS.surface, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: i <= proc.etapa ? "#000" : COLORS.muted, flexShrink: 0 }}>
              {i < proc.etapa ? "✓" : i + 1}
            </div>
            <div>
              <div style={{ color: i <= proc.etapa ? COLORS.text : COLORS.muted, fontSize: 13, fontWeight: i === proc.etapa ? 700 : 400 }}>{etapa}</div>
              {i === proc.etapa && <div style={{ color: COLORS.accent, fontSize: 11 }}>← Etapa atual</div>}
            </div>
          </div>
        ))}
        {proc.etapa < ETAPAS.length - 1
          ? <Btn full color="accent" onClick={() => avancar(proc)}>✅ Avançar: {ETAPAS[proc.etapa + 1]}</Btn>
          : <div style={{ textAlign: "center", padding: 12, background: "#064E3B", borderRadius: 12 }}><span style={{ color: "#6EE7B7", fontWeight: 700 }}>🎉 Processo Concluído!</span></div>
        }
        <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
          {proc.etapa > 0 && <Btn full color="surface" onClick={() => voltarEtapa(proc)}>⬅️ Voltar Etapa</Btn>}
          <Btn full color="red" onClick={() => setDeleteId(proc.id)}>🗑️ Excluir Processo</Btn>
        </div>
      </Card>

      {/* ── Documentos do Processo ── */}
      <Card style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <h3 style={{ color: COLORS.text, margin: 0, fontSize: 15, fontWeight: 700 }}>📎 Documentos do Processo</h3>
          <Btn size="sm" color="blue" onClick={() => fileRef.current.click()}>📎 Anexar</Btn>
        </div>
        {(!proc.docs || proc.docs.length === 0) ? (
          <div style={{ textAlign: "center", padding: 20, color: COLORS.muted }}>
            <div style={{ fontSize: 36 }}>📂</div>
            <div style={{ fontSize: 13, marginTop: 8 }}>Nenhum documento anexado</div>
            <div style={{ fontSize: 11, color: COLORS.accent, marginTop: 4 }}>Fotos, PDF, Word, Excel</div>
          </div>
        ) : proc.docs.map((doc2, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ fontSize: 24 }}>{doc2.enviando ? "⏳" : doc2.tipo?.includes("image") ? "🖼️" : "📄"}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: doc2.enviando ? COLORS.muted : COLORS.text, fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {doc2.nome}{doc2.enviando ? " — enviando..." : ""}
              </div>
              <div style={{ color: COLORS.muted, fontSize: 11 }}>{doc2.size} KB</div>
            </div>
            {doc2.tipo?.includes("image") && doc2.url && <img src={doc2.url} alt="" style={{ width: 40, height: 40, objectFit: "cover", borderRadius: 8 }} />}
            {doc2.url && !doc2.enviando && (
              <a href={fixUrl(doc2.url)} target="_blank" rel="noopener noreferrer"
                style={{ background: COLORS.blue, border: "none", borderRadius: 8, width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", textDecoration: "none" }}>⬇️</a>
            )}
            <button onClick={() => removerDoc(proc.id, i)} style={{ background: COLORS.red, border: "none", borderRadius: 8, width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>×</button>
          </div>
        ))}
        {proc.docs && proc.docs.length > 0 && (
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
            {proc.docs.filter(d => !d.enviando).length > 1 && (
              <Btn full color="surface" onClick={() => {
                proc.docs.filter(d => d.url && !d.enviando).forEach((d, i) => {
                  setTimeout(() => {
                    const a = document.createElement("a");
                    a.href = fixUrl(d.url); a.download = d.nome; a.target = "_blank";
                    document.body.appendChild(a); a.click(); document.body.removeChild(a);
                  }, i * 600);
                });
              }}>⬇️ Baixar Todos ({proc.docs.filter(d => d.url && !d.enviando).length} arquivos)</Btn>
            )}
            <Btn full color="green" onClick={() => enviarDocsWA(proc)}>💬 Enviar para Correspondente</Btn>
          </div>
        )}
      </Card>

      {/* ── Documentos do Proprietário ── */}
      <Card style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <h3 style={{ color: COLORS.text, margin: 0, fontSize: 15, fontWeight: 700 }}>🪪 Docs do Proprietário</h3>
          <Btn size="sm" color="blue" onClick={() => docPropRef.current.click()} disabled={uploadandoProp}>
            {uploadandoProp ? "⏳ Enviando..." : "📎 Anexar"}
          </Btn>
        </div>
        <div style={{ color: COLORS.muted, fontSize: 11, marginBottom: 12 }}>RG, CPF, comprovante de renda, escritura — o correspondente visualiza no portal dele</div>
        {(!proc.docsProprietario || proc.docsProprietario.length === 0) ? (
          <div style={{ textAlign: "center", padding: "16px 0", color: COLORS.muted }}>
            <div style={{ fontSize: 32 }}>📋</div>
            <div style={{ fontSize: 13, marginTop: 6 }}>Nenhum documento do proprietário</div>
          </div>
        ) : proc.docsProprietario.map((d, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ fontSize: 24 }}>{d.tipo?.includes("image") ? "🖼️" : "📄"}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</div>
              <div style={{ color: COLORS.muted, fontSize: 11 }}>{d.size} KB</div>
            </div>
            {d.url && (
              <a href={fixUrl(d.url)} target="_blank" rel="noopener noreferrer"
                style={{ background: COLORS.blue, border: "none", borderRadius: 8, width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", textDecoration: "none" }}>👁️</a>
            )}
            <button onClick={() => removerDocProprietario(proc.id, i, proc.docsProprietario)}
              style={{ background: COLORS.red, border: "none", borderRadius: 8, width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>×</button>
          </div>
        ))}
      </Card>

      {/* ── Observações do Correspondente ── */}
      {proc.notasCorrespondente?.length > 0 && (
        <Card style={{ marginBottom: 12 }}>
          <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 15, fontWeight: 700 }}>📝 Observações do Correspondente</h3>
          {[...proc.notasCorrespondente].reverse().map((n, i) => (
            <div key={i} style={{ background: COLORS.surface, borderRadius: 10, padding: "10px 14px", marginBottom: 8 }}>
              <div style={{ color: COLORS.text, fontSize: 13, lineHeight: 1.5 }}>{n.texto}</div>
              <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>🕐 {n.data}</div>
            </div>
          ))}
        </Card>
      )}

      {/* ── Link do Correspondente ── */}
      <Card style={{ marginBottom: 12 }}>
        <div style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700, marginBottom: 8 }}>🔗 PORTAL DO CORRESPONDENTE</div>
        <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 12, lineHeight: 1.5 }}>
          Envie este link ao correspondente. Ele verá documentos, etapas e docs do proprietário — sem precisar de login.
        </div>
        <Btn full color="blue" onClick={() => {
          const base = window.location.origin + window.location.pathname;
          const link = `${base}?correspondente=${proc.id}`;
          navigator.clipboard?.writeText(link).catch(() => {});
          const msg = `🏦 *Portal do Processo — ${proc.cliente}*\n\nOlá! Aqui está o link para acompanhar e atualizar o processo bancário:\n\n🔗 ${link}\n\n_ImóvelPro_`;
          abrirWhatsApp(`https://wa.me/55${(proc.telCorrespondente || "").replace(/\D/g, "")}?text=${encodeURIComponent(msg)}`);
        }}>
          🔗 Enviar Link ao Correspondente
        </Btn>
        <Btn full color="surface" onClick={() => {
          const base = window.location.origin + window.location.pathname;
          const link = `${base}?correspondente=${proc.id}`;
          navigator.clipboard?.writeText(link).then(() => alert("Link copiado!")).catch(() => alert(`Link:\n${link}`));
        }} style={{ marginTop: 8 }}>
          📋 Copiar Link
        </Btn>
      </Card>

      <div style={{ display: "flex", gap: 8 }}>
        <Btn full color="green" onClick={() => {
          const msg = `Olá *${proc.cliente}*!\n\nAtualização do processo:\n🏦 ${proc.banco}\n📊 Status: *${proc.status}*\nEtapa ${proc.etapa + 1}/${ETAPAS.length}`;
          abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`);
        }}>
          💬 Notificar Cliente
        </Btn>
        <Btn color="red" onClick={() => setDeleteId(proc.id)}>🗑️</Btn>
      </div>
    </div>
  );

  // ── Formulário novo processo ──
  if (view === "form") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>🏦 Novo Processo</h2>
      </div>
      <Card style={{ marginBottom: 12 }}>
        {/* Seleção de cliente */}
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Cliente</label>
          <select value={form.cliente} onChange={e => {
            const nome = e.target.value;
            const obj = clientes.find(c => c.nome === nome) || null;
            setForm(f => ({ ...f, cliente: nome }));
            setClienteSelecionado(obj);
          }}
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
            <option value="">— Selecione o cliente —</option>
            {clientes.map(c => <option key={c.id} value={c.nome}>{c.nome}</option>)}
          </select>
        </div>

        {/* Documentos do proprietário do cliente selecionado */}
        {clienteSelecionado && clienteSelecionado.docsProprietario && clienteSelecionado.docsProprietario.length > 0 && (
          <div style={{ background: COLORS.surface, borderRadius: 12, padding: 12, marginBottom: 14, border: `1px solid ${COLORS.cardBorder}` }}>
            <div style={{ color: COLORS.accent, fontSize: 12, fontWeight: 700, marginBottom: 8 }}>🪪 DOCS DO PROPRIETÁRIO ({clienteSelecionado.docsProprietario.length} arquivo(s))</div>
            {clienteSelecionado.docsProprietario.map((d, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: i < clienteSelecionado.docsProprietario.length - 1 ? `1px solid ${COLORS.cardBorder}` : "none" }}>
                <span style={{ fontSize: 18 }}>{d.tipo?.includes("image") ? "🖼️" : "📄"}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: COLORS.text, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</div>
                </div>
                {d.url && (
                  <a href={fixUrl(d.url)} target="_blank" rel="noopener noreferrer"
                    style={{ background: COLORS.blue, borderRadius: 6, padding: "3px 8px", color: "#fff", fontSize: 11, fontWeight: 700, textDecoration: "none" }}>👁️</a>
                )}
              </div>
            ))}
          </div>
        )}

        <Sel label="Banco" value={form.banco} onChange={v => setForm({ ...form, banco: v })} options={bancos} />
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Imóvel / Endereço</label>
          {imoveis.length > 0 && (
            <select onChange={e => { if (e.target.value) setForm(f => ({ ...f, imovel: e.target.value })); }}
              style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, marginBottom: 6 }}>
              <option value="">— Selecionar imóvel cadastrado —</option>
              {imoveis.map(im => <option key={im.id} value={`${im.titulo} — ${im.endereco}`}>{im.titulo} — {im.endereco}</option>)}
            </select>
          )}
          <input value={form.imovel} onChange={e => setForm(f => ({ ...f, imovel: e.target.value }))}
            placeholder="Ou digite o endereço manualmente"
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box" }} />
        </div>
        <Input label="Valor do Financiamento (R$)" type="number" value={form.valor} onChange={v => setForm({ ...form, valor: v })} placeholder="500000" />

        {/* Correspondente */}
        <div style={{ background: COLORS.surface, borderRadius: 14, padding: 16, marginBottom: 16, border: `1px solid ${COLORS.cardBorder}` }}>
          <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 700, marginBottom: 12 }}>👔 CORRESPONDENTE BANCÁRIO</div>
          {correspondentes.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Selecionar da lista</label>
              <select onChange={e => {
                const c = correspondentes.find(x => x.id === e.target.value);
                if (c) setForm(f => ({ ...f, nomeCorrespondente: c.nome, telCorrespondente: c.telefone }));
              }} style={{ width: "100%", background: "#0A0E1A", border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, marginBottom: 6 }}>
                <option value="">— Selecionar correspondente —</option>
                {correspondentes.map(c => <option key={c.id} value={c.id}>{c.nome}{c.banco ? " • " + c.banco : ""}</option>)}
              </select>
            </div>
          )}
          <Input label="Nome do Correspondente" value={form.nomeCorrespondente} onChange={v => setForm({ ...form, nomeCorrespondente: v })} placeholder="Ex: Carlos Souza" />
          <Input label="WhatsApp do Correspondente" value={form.telCorrespondente} onChange={v => setForm({ ...form, telCorrespondente: v })} placeholder="(11) 99999-0000" />
        </div>

        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : "🚀 Abrir Processo Bancário"}
        </Btn>
      </Card>
    </div>
  );

  // ── Sub-aba: Cadastro de Correspondentes ──
  if (aba === "correspondentes") {
    if (corrView === "form") return (
      <div>
        {corrDeleteId && <ConfirmModal msg="Excluir correspondente?" onOk={corrExcluir} onCancel={() => setCorrDeleteId(null)} />}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
          <Btn color="surface" size="sm" onClick={() => { setCorrView("list"); setCorrForm(emptyCorr); setCorrEditId(null); }}>← Voltar</Btn>
          <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{corrEditId ? "✏️ Editar Correspondente" : "👔 Novo Correspondente"}</h2>
        </div>
        <Card>
          <Input label="Nome Completo *" value={corrForm.nome} onChange={v => setCorrForm({ ...corrForm, nome: v })} placeholder="Carlos Souza" />
          <Input label="WhatsApp *" value={corrForm.telefone} onChange={v => setCorrForm({ ...corrForm, telefone: v })} placeholder="(11) 99999-0000" />
          <Input label="E-mail" type="email" value={corrForm.email} onChange={v => setCorrForm({ ...corrForm, email: v })} placeholder="correspondente@email.com" />
          <Input label="CPF" value={corrForm.cpf} onChange={v => setCorrForm({ ...corrForm, cpf: v })} placeholder="000.000.000-00" />
          <Input label="Banco / Instituição" value={corrForm.banco} onChange={v => setCorrForm({ ...corrForm, banco: v })} placeholder="Ex: Caixa, Bradesco..." />
          <div style={{ marginBottom: 14 }}>
            <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Observações</label>
            <textarea value={corrForm.observacao} onChange={e => setCorrForm({ ...corrForm, observacao: e.target.value })}
              placeholder="Especialidades, taxas, regiões atendidas..."
              rows={3}
              style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", resize: "vertical", outline: "none", fontFamily: "'Segoe UI', system-ui, sans-serif" }} />
          </div>
          <Btn full color="accent" onClick={corrSalvar} style={{ opacity: corrSaving ? 0.7 : 1 }}>
            {corrSaving ? "⏳ Salvando..." : `💾 ${corrEditId ? "Salvar Alterações" : "Cadastrar Correspondente"}`}
          </Btn>
          {corrEditId && <Btn full color="red" onClick={() => setCorrDeleteId(corrEditId)} style={{ marginTop: 10 }}>🗑️ Excluir</Btn>}
        </Card>
      </div>
    );

    return (
      <div>
        {corrDeleteId && <ConfirmModal msg="Excluir correspondente?" onOk={corrExcluir} onCancel={() => setCorrDeleteId(null)} />}
        {/* Tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          <button onClick={() => setAba("processos")} style={{ flex: 1, background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 0", color: COLORS.muted, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
            🏦 Processos
          </button>
          <button onClick={() => setAba("correspondentes")} style={{ flex: 1, background: COLORS.accent, border: "none", borderRadius: 10, padding: "10px 0", color: "#000", fontSize: 13, fontWeight: 800, cursor: "pointer" }}>
            👔 Correspondentes
          </button>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>👔 Correspondentes</h2>
          <Btn size="sm" onClick={() => { setCorrForm(emptyCorr); setCorrEditId(null); setCorrView("form"); }}>+ Adicionar</Btn>
        </div>
        {loadingCorrespondentes ? <Loading /> : correspondentes.length === 0 ? (
          <Card>
            <div style={{ textAlign: "center", padding: "24px 0", color: COLORS.muted }}>
              <div style={{ fontSize: 48 }}>👔</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: COLORS.text, marginTop: 10 }}>Nenhum correspondente cadastrado</div>
              <div style={{ fontSize: 12, marginTop: 6, lineHeight: 1.6 }}>Cadastre seus correspondentes para selecioná-los rapidamente ao abrir um processo bancário.</div>
            </div>
          </Card>
        ) : correspondentes.map(c => (
          <Card key={c.id} style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div style={{ flex: 1 }}>
                <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 15 }}>👔 {c.nome}</div>
                {c.banco && <div style={{ color: COLORS.accent, fontSize: 12, marginTop: 2 }}>🏦 {c.banco}</div>}
                <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 2 }}>📱 {c.telefone}</div>
                {c.email && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>📧 {c.email}</div>}
                {c.observacao && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 6, fontStyle: "italic" }}>{c.observacao}</div>}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
                <Btn size="sm" color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${(c.telefone || "").replace(/\D/g, "")}`)}>💬</Btn>
                <Btn size="sm" color="blue" onClick={() => { setCorrForm({ nome: c.nome || "", telefone: c.telefone || "", email: c.email || "", cpf: c.cpf || "", banco: c.banco || "", observacao: c.observacao || "" }); setCorrEditId(c.id); setCorrView("form"); }}>✏️</Btn>
                <Btn size="sm" color="red" onClick={() => setCorrDeleteId(c.id)}>🗑️</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  // ── Lista de processos (aba principal) ──
  return (
    <div>
      {deleteId && <ConfirmModal msg="Excluir processo?" onOk={excluir} onCancel={() => setDeleteId(null)} />}
      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        <button onClick={() => setAba("processos")} style={{ flex: 1, background: COLORS.accent, border: "none", borderRadius: 10, padding: "10px 0", color: "#000", fontSize: 13, fontWeight: 800, cursor: "pointer" }}>
          🏦 Processos
        </button>
        <button onClick={() => setAba("correspondentes")} style={{ flex: 1, background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 0", color: COLORS.muted, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
          👔 Correspondentes
        </button>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>🏦 Correspondente Bancário</h2>
        <Btn size="sm" onClick={() => setView("form")}>+ Novo</Btn>
      </div>
      {loading ? <Loading /> : processos.length === 0 ? (
        <Card><p style={{ color: COLORS.muted, textAlign: "center", margin: 0 }}>Nenhum processo aberto.</p></Card>
      ) : processos.map(p => (
        <Card key={p.id} style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
            <div>
              <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>{p.cliente}</div>
              <div style={{ color: COLORS.muted, fontSize: 12 }}>{p.banco}</div>
              {p.nomeCorrespondente && <div style={{ color: COLORS.accent, fontSize: 11 }}>👔 {p.nomeCorrespondente}</div>}
            </div>
            <Badge color={etapaCor[p.etapa] || "blue"}>{p.status}</Badge>
          </div>
          <div style={{ color: COLORS.accent, fontSize: 16, fontWeight: 700, marginBottom: 8 }}>R$ {Number(p.valor).toLocaleString("pt-BR")}</div>
          <div style={{ display: "flex", gap: 3, height: 6, marginBottom: 8, overflow: "hidden", borderRadius: 3 }}>
            {ETAPAS.map((_, i) => <div key={i} style={{ flex: 1, background: i <= p.etapa ? COLORS.green : COLORS.surface }} />)}
          </div>
          <div style={{ color: COLORS.muted, fontSize: 11, marginBottom: 12 }}>Etapa {p.etapa + 1}/{ETAPAS.length} • 📎 {(p.docs || []).length} doc(s){p.docsProprietario?.length ? ` • 🪪 ${p.docsProprietario.length} prop.` : ""}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn size="sm" color="blue" onClick={() => { setSelId(p.id); setView("detalhe"); }}>Ver Detalhes →</Btn>
            {p.telCorrespondente && <Btn size="sm" color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${p.telCorrespondente.replace(/\D/g, "")}`)}>💬</Btn>}
            <Btn size="sm" color="red" onClick={() => setDeleteId(p.id)}>🗑️</Btn>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ─── CALCULADORA ───
function Calculadora() {
  const [valor, setValor] = useState("500000"); const [entrada, setEntrada] = useState("100000"); const [prazo, setPrazo] = useState("360"); const [taxa, setTaxa] = useState("0.65"); const [sistema, setSistema] = useState("SAC"); const [res, setRes] = useState(null);
  const calcular = () => { const vf = Number(valor) - Number(entrada), n = Number(prazo), i = Number(taxa) / 100; let p1, pu, total; if (sistema === "PRICE") { const p = vf * (i * Math.pow(1 + i, n)) / (Math.pow(1 + i, n) - 1); p1 = pu = p; total = p * n; } else { const a = vf / n; p1 = a + vf * i; pu = a + a * i; total = (p1 + pu) / 2 * n; } setRes({ vf, p1, pu, total, juros: total - vf, renda: p1 / 0.3 }); };
  return (
    <div>
      <h2 style={{ color: COLORS.text, margin: "0 0 20px", fontSize: 20, fontWeight: 800 }}>🧮 Calculadora de Financiamento</h2>
      <Card style={{ marginBottom: 16 }}>
        <Input label="Valor do Imóvel (R$)" type="number" value={valor} onChange={setValor} placeholder="500000" />
        <Input label="Valor de Entrada (R$)" type="number" value={entrada} onChange={setEntrada} placeholder="100000" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Input label="Prazo (meses)" type="number" value={prazo} onChange={setPrazo} />
          <Input label="Taxa mensal (%)" type="number" value={taxa} onChange={setTaxa} />
        </div>
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>{["SAC", "PRICE"].map(s => <button key={s} onClick={() => setSistema(s)} style={{ flex: 1, padding: 10, background: sistema === s ? COLORS.accent : COLORS.surface, color: sistema === s ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer" }}>{s}</button>)}</div>
        <Btn full color="accent" onClick={calcular}>📊 Calcular</Btn>
      </Card>
      {res && <Card>
        <h3 style={{ color: COLORS.accent, margin: "0 0 16px" }}>📈 Resultado — {sistema}</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          {[{ l: "Financiado", v: res.vf, c: COLORS.blue }, { l: "1ª Parcela", v: res.p1, c: COLORS.accent }, { l: "Última Parcela", v: res.pu, c: COLORS.green }, { l: "Renda Mínima", v: res.renda, c: COLORS.purple }].map(r => (
            <div key={r.l} style={{ background: COLORS.surface, borderRadius: 10, padding: 12, textAlign: "center" }}>
              <div style={{ color: r.c, fontSize: 15, fontWeight: 800 }}>R$ {r.v.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}</div>
              <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>{r.l}</div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderTop: `1px solid ${COLORS.cardBorder}` }}><span style={{ color: COLORS.muted }}>Total Juros</span><span style={{ color: COLORS.red, fontWeight: 700 }}>R$ {res.juros.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}</span></div>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "10px 0" }}><span style={{ color: COLORS.muted }}>Total Pago</span><span style={{ color: COLORS.text, fontWeight: 700 }}>R$ {res.total.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}</span></div>
        <Btn full color="green" onClick={() => { const msg = `Simulação 🏠\nValor: R$ ${Number(valor).toLocaleString("pt-BR")} | Entrada: R$ ${Number(entrada).toLocaleString("pt-BR")}\nPrazo: ${prazo}m | ${sistema}\n1ª Parcela: R$ ${res.p1.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}\nRenda Mínima: R$ ${res.renda.toLocaleString("pt-BR", { maximumFractionDigits: 0 })}`; abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`); }} style={{ marginTop: 12 }}>💬 Enviar por WhatsApp</Btn>
      </Card>}
    </div>
  );
}

// ─── COMISSÃO ───
function Comissao({ imoveis = [] }) {
  const [vi, setVi] = useState("500000"); const [perc, setPerc] = useState("6"); const [split, setSplit] = useState("100"); const [tipo, setTipo] = useState("venda"); const [res, setRes] = useState(null);
  const [imovelSel, setImovelSel] = useState("");
  const calcular = () => { const ct = Number(vi) * Number(perc) / 100, cc = ct * Number(split) / 100, imp = cc * 0.065; setRes({ ct, cc, imp, liq: cc - imp }); };
  const handleSelecionarImovel = (id) => {
    setImovelSel(id);
    if (!id) return;
    const im = imoveis.find(i => i.id === id);
    if (im && im.valor) setVi(String(Number(im.valor)));
    setRes(null);
  };
  return (
    <div>
      <h2 style={{ color: COLORS.text, margin: "0 0 20px", fontSize: 20, fontWeight: 800 }}>💰 Comissão do Corretor</h2>
      <Card style={{ marginBottom: 16 }}>
        {/* Seletor de imóvel cadastrado */}
        {imoveis.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 700, letterSpacing: 1, marginBottom: 6 }}>SELECIONAR IMÓVEL CADASTRADO</div>
            <select
              value={imovelSel}
              onChange={e => handleSelecionarImovel(e.target.value)}
              style={{ width: "100%", padding: "12px 14px", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, color: imovelSel ? COLORS.text : COLORS.muted, fontSize: 14, outline: "none", appearance: "none", cursor: "pointer" }}
            >
              <option value="">🏠 Escolher imóvel cadastrado...</option>
              {imoveis.map(im => (
                <option key={im.id} value={im.id}>
                  {im.titulo || im.tipo} — R$ {Number(im.valor || 0).toLocaleString("pt-BR")}
                </option>
              ))}
            </select>
            {imovelSel && (() => {
              const im = imoveis.find(i => i.id === imovelSel);
              if (!im) return null;
              return (
                <div style={{ marginTop: 8, padding: "10px 12px", background: COLORS.surface, borderRadius: 10, borderLeft: `3px solid ${COLORS.accent}` }}>
                  <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700 }}>{im.titulo || im.tipo}</div>
                  {im.endereco && <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>📍 {im.endereco}</div>}
                  <div style={{ display: "flex", gap: 12, marginTop: 4 }}>
                    {im.area && <span style={{ color: COLORS.muted, fontSize: 11 }}>📐 {im.area}m²</span>}
                    {im.quartos && <span style={{ color: COLORS.muted, fontSize: 11 }}>🛏 {im.quartos} quartos</span>}
                    {im.status && <span style={{ color: COLORS.accent, fontSize: 11, fontWeight: 700 }}>{im.status}</span>}
                  </div>
                </div>
              );
            })()}
          </div>
        )}
        <Input label="Valor do Imóvel (R$)" type="number" value={vi} onChange={v => { setVi(v); setImovelSel(""); setRes(null); }} placeholder="500000" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}><Input label="Percentual (%)" type="number" value={perc} onChange={setPerc} placeholder="6" /><Input label="Minha parte (%)" type="number" value={split} onChange={setSplit} placeholder="100" /></div>
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>{["venda", "locacao"].map(t => <button key={t} onClick={() => setTipo(t)} style={{ flex: 1, padding: 10, background: tipo === t ? COLORS.accent : COLORS.surface, color: tipo === t ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 13 }}>{t === "venda" ? "🏠 Venda" : "🔑 Locação"}</button>)}</div>
        <Btn full color="accent" onClick={calcular}>Calcular</Btn>
      </Card>
      {res && <Card style={{ marginBottom: 16 }}>{[{ l: "Comissão Total", v: res.ct, c: COLORS.blue }, { l: "Minha Comissão", v: res.cc, c: COLORS.accent }, { l: "Impostos ~6.5%", v: res.imp, c: COLORS.red }, { l: "Valor Líquido", v: res.liq, c: COLORS.green }].map(r => <div key={r.l} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}><span style={{ color: COLORS.muted }}>{r.l}</span><span style={{ color: r.c, fontWeight: 700 }}>R$ {r.v.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</span></div>)}</Card>}
    </div>
  );
}

// ─── AVALIAÇÃO ───
function Avaliacao({ uid }) {
  const [form, setForm] = useState({ tipo: "Apartamento", area: "", quartos: "", banheiros: "", andar: "", conservacao: "Bom", localizacao: "Boa" });
  const [res, setRes] = useState(null);
  const [fotos, setFotos] = useState([]);
  const [fotoIdx, setFotoIdx] = useState(0);
  const [salvando, setSalvando] = useState(false);
  const fotoRef = useRef();

  // BUG #3 CORRIGIDO: carrega último rascunho do Firebase
  useEffect(() => {
    if (!uid) return;
    const ref = doc(db, "avaliacoes_rascunho", uid);
    getDoc(ref).then(snap => {
      if (snap.exists()) {
        const d = snap.data();
        if (d.form) setForm(d.form);
        if (d.fotos) setFotos(d.fotos);
      }
    }).catch(() => {});
  }, [uid]);

  // Salva rascunho no Firebase quando form muda
  useEffect(() => {
    if (!uid) return;
    const timer = setTimeout(() => {
      const ref = doc(db, "avaliacoes_rascunho", uid);
      // Salva apenas URLs já persistidas (não base64 local em upload)
      const fotosSalvas = fotos.filter(f => !f.uploading && f.url?.startsWith("http"));
      setDoc(ref, { form, fotos: fotosSalvas, updatedAt: serverTimestamp() }, { merge: true })
        .catch(() => {});
    }, 1000);
    return () => clearTimeout(timer);
  }, [form, fotos, uid]);

  // BUG #5 CORRIGIDO: avaliar usa m² base configurável por região
  const avaliar = () => {
    const a = Number(form.area);
    if (!a) return;
    // m² base por tipo — ajustável pelo usuário via campo "m²Base" no form
    const m2BasePadrao = { Apartamento: 6500, Casa: 5800, Comercial: 7000, Terreno: 3000, Cobertura: 9000 };
    const m2BaseRegional = Number(form.m2base) || m2BasePadrao[form.tipo] || 6000;
    let m2 = m2BaseRegional;
    m2 *= { Excelente: 1.3, Bom: 1.0, Regular: 0.8, Ruim: 0.6 }[form.conservacao] || 1;
    m2 *= { Prime: 1.4, Boa: 1.1, Regular: 0.9, Periférica: 0.7 }[form.localizacao] || 1;
    if (form.quartos >= 4) m2 *= 1.1;
    if (form.andar > 10) m2 *= 1.05;
    const med = a * m2;
    setRes({ m2: m2.toFixed(0), m2base: m2BaseRegional, min: med * 0.85, med, max: med * 1.15, alug: med * 0.005 });
  };
  const fmt = v => v.toLocaleString("pt-BR", { maximumFractionDigits: 0 });
  const handleFotos = async (e) => {
    const files = Array.from(e.target.files);
    for (const file of files) {
      try {
        const uid = `${file.name}_${Date.now()}_${Math.random()}`;
        await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = ev => {
            setFotos(prev => [...prev, { url: ev.target.result, nome: file.name, uploading: true, _uid: uid }]);
            resolve();
          };
          reader.readAsDataURL(file);
        });
        const url = await uploadFoto(file);
        setFotos(prev => prev.map(fx => fx._uid === uid ? { url, nome: file.name, uploading: false, _uid: uid } : fx));
      } catch(err) { console.error("Erro upload foto:", err); }
    }
  };
  const removerFoto = (idx) => { setFotos(prev => prev.filter((_, i) => i !== idx)); setFotoIdx(i => Math.min(i, fotos.length - 2)); };
  return (
    <div>
      <h2 style={{ color: COLORS.text, margin: "0 0 20px", fontSize: 20, fontWeight: 800 }}>📊 Avaliação de Imóveis</h2>
      <Card style={{ marginBottom: 16 }}>
        {/* Fotos do imóvel */}
        <div style={{ marginBottom: 14 }}>
          <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>FOTOS DO IMÓVEL</div>
          {fotos.length > 0 && (
            <div style={{ position: "relative", borderRadius: 12, overflow: "hidden", marginBottom: 10 }}>
              <img src={fotos[fotoIdx]?.url} alt="" style={{ width: "100%", height: 180, objectFit: "cover", display: "block", opacity: fotos[fotoIdx]?.uploading ? 0.5 : 1 }} />
              {fotos[fotoIdx]?.uploading && <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.4)", color: "#fff", fontSize: 13 }}>Enviando...</div>}
              {fotos.length > 1 && <>
                <button onClick={() => setFotoIdx(i => (i - 1 + fotos.length) % fotos.length)} style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>‹</button>
                <button onClick={() => setFotoIdx(i => (i + 1) % fotos.length)} style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", background: "rgba(0,0,0,0.6)", border: "none", borderRadius: "50%", width: 30, height: 30, color: "#fff", cursor: "pointer", fontSize: 16, fontWeight: 700 }}>›</button>
              </>}
              <div style={{ position: "absolute", bottom: 8, right: 8, background: "rgba(0,0,0,0.7)", borderRadius: 20, padding: "2px 9px", color: "#fff", fontSize: 11, fontWeight: 700 }}>{fotoIdx + 1}/{fotos.length}</div>
              <button onClick={() => removerFoto(fotoIdx)} style={{ position: "absolute", top: 8, right: 8, background: COLORS.red, border: "none", borderRadius: "50%", width: 26, height: 26, color: "#fff", fontSize: 15, cursor: "pointer", fontWeight: 700, lineHeight: 1 }}>×</button>
            </div>
          )}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <button onClick={() => { fotoRef.current.setAttribute("capture", "environment"); fotoRef.current.click(); }} style={{ padding: "12px 8px", background: COLORS.surface, border: `1px dashed ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.text, cursor: "pointer", fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>📷 Tirar Foto</button>
            <button onClick={() => { fotoRef.current.removeAttribute("capture"); fotoRef.current.click(); }} style={{ padding: "12px 8px", background: COLORS.surface, border: `1px dashed ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.text, cursor: "pointer", fontSize: 13, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>🖼️ Galeria</button>
          </div>
          <input ref={fotoRef} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={handleFotos} />
        </div>
        <Sel label="Tipo" value={form.tipo} onChange={v => setForm({ ...form, tipo: v })} options={["Apartamento", "Casa", "Comercial", "Terreno", "Cobertura"]} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Input label="Área m²" type="number" value={form.area} onChange={v => setForm({ ...form, area: v })} placeholder="120" />
          <Input label="Quartos" type="number" value={form.quartos} onChange={v => setForm({ ...form, quartos: v })} placeholder="3" />
          <Input label="Banheiros" type="number" value={form.banheiros} onChange={v => setForm({ ...form, banheiros: v })} placeholder="2" />
          <Input label="Andar" type="number" value={form.andar} onChange={v => setForm({ ...form, andar: v })} placeholder="5" />
          <Sel label="Conservação" value={form.conservacao} onChange={v => setForm({ ...form, conservacao: v })} options={["Excelente", "Bom", "Regular", "Ruim"]} />
          <Sel label="Localização" value={form.localizacao} onChange={v => setForm({ ...form, localizacao: v })} options={["Prime", "Boa", "Regular", "Periférica"]} />
        </div>
        {/* BUG #5 CORRIGIDO: campo de m²/base configurável por região */}
        <div style={{ marginTop: 10, padding: "12px 14px", background: COLORS.surface, borderRadius: 10, border: `1px solid ${COLORS.cardBorder}` }}>
          <div style={{ color: COLORS.muted, fontSize: 11, fontWeight: 700, marginBottom: 6 }}>⚙️ CALIBRAÇÃO REGIONAL (opcional)</div>
          <Input label="Preço médio do m² na sua região (R$)" type="number" value={form.m2base || ""} onChange={v => setForm({ ...form, m2base: v })} placeholder={`Padrão: R$ ${{ Apartamento: 6500, Casa: 5800, Comercial: 7000, Terreno: 3000, Cobertura: 9000 }[form.tipo] || 6000}/m²`} />
          <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 4 }}>💡 Deixe em branco para usar o padrão nacional. Ajuste conforme a sua cidade/bairro.</div>
        </div>
        <Btn full color="accent" onClick={avaliar} style={{ marginTop: 12 }}>📊 Avaliar</Btn>
      </Card>
      {res && <Card>
        <div style={{ textAlign: "center", padding: "16px 0", borderBottom: `1px solid ${COLORS.cardBorder}`, marginBottom: 16 }}>
          <div style={{ color: COLORS.muted, fontSize: 12 }}>Valor Estimado</div>
          <div style={{ color: COLORS.accent, fontSize: 28, fontWeight: 900 }}>R$ {fmt(res.med)}</div>
          <div style={{ color: COLORS.muted, fontSize: 12 }}>R$ {res.m2}/m² ajustado · base R$ {res.m2base}/m²</div>
        </div>
        {[{ l: "🔻 Mínimo", v: res.min, c: COLORS.red }, { l: "✅ Médio", v: res.med, c: COLORS.green }, { l: "🔺 Máximo", v: res.max, c: COLORS.blue }, { l: "🔑 Aluguel/mês", v: res.alug, c: COLORS.purple }].map(r => (
          <div key={r.l} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
            <span style={{ color: COLORS.muted, fontSize: 13 }}>{r.l}</span><span style={{ color: r.c, fontWeight: 700 }}>R$ {fmt(r.v)}</span>
          </div>
        ))}
        <Btn full color="green" onClick={() => { const msg = `📊 Avaliação\n${form.tipo} | ${form.area}m² | ${form.conservacao} | ${form.localizacao}\n\n💰 Estimado: R$ ${fmt(res.med)}\nFaixa: R$ ${fmt(res.min)} — R$ ${fmt(res.max)}\n🔑 Aluguel: R$ ${fmt(res.alug)}/mês`; abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`); }} style={{ marginTop: 14 }}>💬 Enviar por WhatsApp</Btn>
      </Card>}
    </div>
  );
}

// ─── CONTRATOS ───
function Documentos({ uid }) {
  const [tipo, setTipo] = useState("aluguel");
  const [tel, setTel] = useState("");
  const fileRefs = useRef({});

  const contratos = {
    aluguel: {
      titulo: "Contrato de Aluguel",
      docs: [
        { nome: "RG ou CNH do Inquilino", obrig: true },
        { nome: "CPF do Inquilino", obrig: true },
        { nome: "Comprovante de Renda (3 meses)", obrig: true },
        { nome: "Comprovante de Residência Anterior", obrig: true },
        { nome: "Fiador (RG, CPF, Renda)", obrig: false },
        { nome: "Seguro Fiança ou Caução", obrig: false },
        { nome: "Referência de Emprego", obrig: false },
        { nome: "Declaração de IR", obrig: false },
      ]
    },
    locacao: {
      titulo: "Contrato de Locação Comercial",
      docs: [
        { nome: "CNPJ da Empresa", obrig: true },
        { nome: "Contrato Social", obrig: true },
        { nome: "RG/CPF do Sócio", obrig: true },
        { nome: "Comprovante de Faturamento", obrig: true },
        { nome: "Certidão Negativa Federal", obrig: true },
        { nome: "Certidão Negativa Estadual", obrig: true },
        { nome: "Fiador ou Seguro Fiança", obrig: false },
      ]
    },
    venda: {
      titulo: "Contrato de Compra e Venda",
      docs: [
        { nome: "RG ou CNH do Comprador", obrig: true },
        { nome: "CPF do Comprador", obrig: true },
        { nome: "Certidão de Casamento/Nascimento", obrig: true },
        { nome: "Comprovante de Renda (3 meses)", obrig: true },
        { nome: "Extrato bancário (3 meses)", obrig: true },
        { nome: "FGTS – Extrato (se usar)", obrig: false },
        { nome: "Declaração de IR", obrig: false },
        { nome: "Certidão de Matrícula do Imóvel", obrig: true },
        { nome: "ITBI – Guia paga", obrig: true },
      ]
    }
  };

  // BUG #4 CORRIGIDO: estado de contratos salvo no Firebase
  const [arquivos, setArquivos] = useState({});
  const [contrAtual, setContrAtual] = useState({}); // contrato modelo por tipo
  const contrFileRefs = useRef({});
  const [carregandoDocs, setCarregandoDocs] = useState(true);

  // Carrega contratos salvos do Firebase
  useEffect(() => {
    if (!uid) { setCarregandoDocs(false); return; }
    const ref = doc(db, "contratos_modelos", uid);
    getDoc(ref).then(snap => {
      if (snap.exists()) {
        const d = snap.data();
        if (d.contrAtual) setContrAtual(d.contrAtual);
      }
      setCarregandoDocs(false);
    }).catch(() => setCarregandoDocs(false));
  }, [uid]);

  // Salva contratos no Firebase quando mudar
  useEffect(() => {
    if (carregandoDocs || !uid) return;
    const ref = doc(db, "contratos_modelos", uid);
    // Salva apenas contratos com URL do Cloudinary (não base64 local)
    const contrSalvos = Object.fromEntries(
      Object.entries(contrAtual).filter(([, v]) => v?.url?.startsWith("http"))
    );
    if (Object.keys(contrSalvos).length === 0) return;
    setDoc(ref, { contrAtual: contrSalvos, updatedAt: serverTimestamp() }, { merge: true })
      .catch(() => {});
  }, [contrAtual, carregandoDocs, uid]);

  const handleAnexar = (key, e) => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setArquivos(prev => ({ ...prev, [key]: { nome: file.name, url: ev.target.result, tipo: file.type, size: (file.size / 1024).toFixed(0) } }));
    reader.readAsDataURL(file);
  };

  const handleAnexarContrato = async (tipoKey, e) => {
    const file = e.target.files[0]; if (!file) return;
    try {
      const url = await uploadArquivo(file);
      setContrAtual(prev => ({ ...prev, [tipoKey]: { nome: file.name, url, tipo: file.type, size: (file.size / 1024).toFixed(0) } }));
    } catch(err) {
      // fallback local preview
      const reader = new FileReader();
      reader.onload = ev => setContrAtual(prev => ({ ...prev, [tipoKey]: { nome: file.name, url: ev.target.result, tipo: file.type, size: (file.size / 1024).toFixed(0) } }));
      reader.readAsDataURL(file);
    }
  };

  const atual = contratos[tipo];
  const ok = atual.docs.filter((_, i) => arquivos[`${tipo}-${i}`]).length;
  const contratoAnexado = contrAtual[tipo];

  const enviarWhatsApp = () => {
    const lista = atual.docs.map((d, i) => `${arquivos[`${tipo}-${i}`] ? "✅" : "❌"} ${d.nome}${d.obrig ? " *" : ""}`).join("\n");
    const msg = `📋 *${atual.titulo}*\n\n${lista}\n\n* Obrigatório\n\n_ImóvelPro_`;
    const num = tel.replace(/\D/g, "");
    window.open(num ? `https://wa.me/55${num}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank");
  };

  return (
    <div>
      <h2 style={{ color: COLORS.text, margin: "0 0 20px", fontSize: 20, fontWeight: 800 }}>📄 Contratos</h2>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["aluguel", "🔑 Aluguel"], ["locacao", "🏬 Locação Com."], ["venda", "🏠 Compra/Venda"]].map(([id, label]) => (
          <button key={id} onClick={() => setTipo(id)} style={{ flex: 1, padding: "10px 0", background: tipo === id ? COLORS.accent : COLORS.surface, color: tipo === id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 11 }}>{label}</button>
        ))}
      </div>

      {/* ── Contrato modelo ── */}
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <div>
            <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>📝 Contrato Modelo</div>
            <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>Anexe seu contrato pronto para usar como base</div>
          </div>
          {contratoAnexado && <span style={{ color: COLORS.green, fontSize: 18 }}>✅</span>}
        </div>

        <input
          ref={el => contrFileRefs.current[tipo] = el}
          type="file"
          accept=".pdf,.doc,.docx,image/*"
          style={{ display: "none" }}
          onChange={e => handleAnexarContrato(tipo, e)}
        />

        {!contratoAnexado ? (
          <button
            onClick={() => contrFileRefs.current[tipo].click()}
            style={{ width: "100%", padding: "18px 12px", background: COLORS.surface, border: `2px dashed ${COLORS.accent}`, borderRadius: 12, color: COLORS.accent, cursor: "pointer", fontSize: 14, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}
          >
            📎 Anexar {atual.titulo}
          </button>
        ) : (
          <div style={{ background: COLORS.surface, borderRadius: 10, padding: "12px 14px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ fontSize: 28 }}>{contratoAnexado.tipo?.includes("image") ? "🖼️" : "📄"}</span>
              <div style={{ flex: 1, overflow: "hidden" }}>
                <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{contratoAnexado.nome}</div>
                <div style={{ color: COLORS.muted, fontSize: 11 }}>{contratoAnexado.size}KB</div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <a href={contratoAnexado.url} target="_blank" rel="noopener noreferrer" style={{ background: COLORS.blue, border: "none", borderRadius: 8, padding: "6px 10px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer", textDecoration: "none" }}>👁️ Ver</a>
                <button onClick={() => setContrAtual(p => { const n = {...p}; delete n[tipo]; return n; })} style={{ background: COLORS.red, border: "none", borderRadius: 8, padding: "6px 10px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>✕</button>
              </div>
            </div>
            <button
              onClick={() => contrFileRefs.current[tipo].click()}
              style={{ marginTop: 10, width: "100%", padding: "8px", background: "transparent", border: `1px solid ${COLORS.cardBorder}`, borderRadius: 8, color: COLORS.muted, cursor: "pointer", fontSize: 12 }}
            >🔄 Substituir arquivo</button>
          </div>
        )}
      </Card>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
          <span style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>{atual.titulo}</span>
          <span style={{ color: COLORS.accent, fontWeight: 700 }}>{ok}/{atual.docs.length}</span>
        </div>
        <div style={{ background: COLORS.surface, borderRadius: 8, height: 8, marginBottom: 16 }}>
          <div style={{ background: COLORS.green, height: 8, borderRadius: 8, width: `${(ok / atual.docs.length) * 100}%`, transition: "width 0.5s" }} />
        </div>
        {atual.docs.map((doc, i) => {
          const key = `${tipo}-${i}`;
          const arq = arquivos[key];
          return (
            <div key={i} style={{ padding: "12px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
              <input ref={el => fileRefs.current[key] = el} type="file" accept="image/*,.pdf,.doc,.docx" onChange={e => handleAnexar(key, e)} style={{ display: "none" }} />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ color: COLORS.text, fontSize: 13 }}>{doc.nome}</div>
                  {doc.obrig && <span style={{ color: COLORS.red, fontSize: 10, fontWeight: 700 }}>OBRIGATÓRIO</span>}
                </div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ fontSize: 16 }}>{arq ? "✅" : "❌"}</span>
                  {!arq
                    ? <Btn size="sm" color="blue" onClick={() => fileRefs.current[key].click()}>📎 Anexar</Btn>
                    : <button onClick={() => setArquivos(p => { const n = { ...p }; delete n[key]; return n; })} style={{ background: COLORS.red, border: "none", borderRadius: 8, width: 28, height: 28, color: "#fff", cursor: "pointer", fontSize: 16 }}>×</button>
                  }
                </div>
              </div>
              {arq && (
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 8, background: COLORS.surface, borderRadius: 8, padding: "6px 10px" }}>
                  {arq.tipo?.includes("image") && <img src={arq.url} alt="" style={{ width: 32, height: 32, objectFit: "cover", borderRadius: 6 }} />}
                  <span style={{ color: COLORS.green, fontSize: 12, fontWeight: 600, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>📎 {arq.nome}</span>
                  <span style={{ color: COLORS.muted, fontSize: 11 }}>{arq.size}KB</span>
                </div>
              )}
            </div>
          );
        })}
      </Card>
      <Card>
        <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 14, fontWeight: 700 }}>📤 Enviar por WhatsApp</h3>
        <Input label="WhatsApp do destinatário (opcional)" value={tel} onChange={setTel} placeholder="(85) 99999-0000" />
        <Btn full color="green" onClick={enviarWhatsApp}>💬 Enviar Checklist por WhatsApp</Btn>
      </Card>
    </div>
  );
}

// ─── FINANCEIRO ───
function Financeiro({ uid, clientes = [], imoveis = [] }) {
  const [comissoes, setComissoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [editando, setEditando] = useState(null);
  const [filtro, setFiltro] = useState("todos");
  const [form, setForm] = useState({ descricao: "", cliente: "", imovel: "", valor: "", percentual: "", valorImovel: "", status: "a_receber", previsao: "", observacao: "" });

  useEffect(() => {
    const q = query(collection(db, "financeiro"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => {
      setComissoes(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, [uid]);

  // 📤 Exportar CSV
  const exportarCSV = () => {
    const header = ["Descrição", "Cliente", "Imóvel", "Valor (R$)", "Status", "Previsão", "Observação"];
    const rows = comissoes.map(c => [
      c.descricao || "",
      c.cliente || "",
      c.imovel || "",
      c.valor || "0",
      c.status === "a_receber" ? "A Receber" : "Recebido",
      c.previsao || "",
      (c.observacao || "").replace(/,/g, ";"),
    ]);
    const csv = [header, ...rows].map(r => r.join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "comissoes-imovelPro.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const calcValorPorPercentual = (perc, valImovel) => {
    const p = parseFloat(perc) || 0;
    const v = parseFloat(String(valImovel).replace(/\D/g, "")) || 0;
    return p > 0 && v > 0 ? (v * p / 100).toFixed(2) : "";
  };

  const abrirNovo = () => {
    setEditando(null);
    setForm({ descricao: "", cliente: "", imovel: "", valor: "", percentual: "", valorImovel: "", status: "a_receber", previsao: "", observacao: "" });
    setModal(true);
  };

  const abrirEditar = (c) => {
    setEditando(c.id);
    setForm({ descricao: c.descricao || "", cliente: c.cliente || "", imovel: c.imovel || "", valor: c.valor || "", percentual: c.percentual || "", valorImovel: c.valorImovel || "", status: c.status || "a_receber", previsao: c.previsao || "", observacao: c.observacao || "" });
    setModal(true);
  };

  const salvar = async () => {
    if (!form.descricao || !form.valor) return alert("Preencha descrição e valor.");
    const dados = { ...form, uid, updatedAt: serverTimestamp() };
    if (editando) {
      await updateDoc(doc(db, "financeiro", editando), dados);
    } else {
      await addDoc(collection(db, "financeiro"), { ...dados, createdAt: serverTimestamp() });
    }
    setModal(false);
  };

  const excluir = async (id) => {
    if (!window.confirm("Excluir esta comissão?")) return;
    await deleteDoc(doc(db, "financeiro", id));
  };

  const marcarRecebida = async (c) => {
    await updateDoc(doc(db, "financeiro", c.id), { status: "recebida", updatedAt: serverTimestamp() });
  };

  const fmt = (v) => Number(v || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

  const filtradas = filtro === "todos" ? comissoes : comissoes.filter(c => c.status === filtro);
  const totalReceber = comissoes.filter(c => c.status === "a_receber").reduce((s, c) => s + (parseFloat(c.valor) || 0), 0);
  const totalRecebido = comissoes.filter(c => c.status === "recebida").reduce((s, c) => s + (parseFloat(c.valor) || 0), 0);
  const totalGeral = totalReceber + totalRecebido;

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>💵 Financeiro</h2>
        <div style={{ display: "flex", gap: 8 }}>
          <Btn color="surface" size="sm" onClick={exportarCSV} style={{ fontSize: 11 }}>📤 CSV</Btn>
          <Btn color="green" onClick={abrirNovo}>+ Nova</Btn>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 14 }}>
          <div style={{ color: COLORS.muted, fontSize: 10, fontWeight: 600, marginBottom: 4 }}>A RECEBER</div>
          <div style={{ color: COLORS.accent, fontSize: 18, fontWeight: 800 }}>{fmt(totalReceber)}</div>
          <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>{comissoes.filter(c => c.status === "a_receber").length} comissões</div>
        </div>
        <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 14 }}>
          <div style={{ color: COLORS.muted, fontSize: 10, fontWeight: 600, marginBottom: 4 }}>RECEBIDO</div>
          <div style={{ color: COLORS.green, fontSize: 18, fontWeight: 800 }}>{fmt(totalRecebido)}</div>
          <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2 }}>{comissoes.filter(c => c.status === "recebida").length} comissões</div>
        </div>
      </div>
      <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 14, marginBottom: 20, textAlign: "center" }}>
        <div style={{ color: COLORS.muted, fontSize: 10, fontWeight: 600, marginBottom: 4 }}>TOTAL GERAL</div>
        <div style={{ color: COLORS.purple, fontSize: 22, fontWeight: 800 }}>{fmt(totalGeral)}</div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {[["todos", "Todos"], ["a_receber", "A Receber"], ["recebida", "Recebido"]].map(([val, label]) => (
          <button key={val} onClick={() => setFiltro(val)} style={{ flex: 1, padding: "8px 0", background: filtro === val ? COLORS.accent : COLORS.surface, color: filtro === val ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 11 }}>{label}</button>
        ))}
      </div>

      {loading ? <div style={{ color: COLORS.muted, textAlign: "center", padding: 40 }}>Carregando...</div> : filtradas.length === 0 ? (
        <div style={{ color: COLORS.muted, textAlign: "center", padding: 40 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>💵</div>
          <div>Nenhuma comissão encontrada</div>
          <div style={{ fontSize: 12, marginTop: 6 }}>Toque em "+ Nova" para adicionar</div>
        </div>
      ) : filtradas.map(c => (
        <div key={c.id} style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 14, padding: 16, marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
            <div style={{ flex: 1 }}>
              <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 14, marginBottom: 2 }}>{c.descricao}</div>
              {c.cliente && <div style={{ color: COLORS.muted, fontSize: 12 }}>👤 {c.cliente}</div>}
              {c.imovel && <div style={{ color: COLORS.muted, fontSize: 12 }}>🏠 {c.imovel}</div>}
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ color: c.status === "recebida" ? COLORS.green : COLORS.accent, fontWeight: 800, fontSize: 16 }}>{fmt(c.valor)}</div>
              {c.percentual && <div style={{ color: COLORS.muted, fontSize: 11 }}>{c.percentual}%</div>}
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span style={{ background: c.status === "recebida" ? "#064E3B" : "#422006", color: c.status === "recebida" ? COLORS.green : COLORS.accent, borderRadius: 8, padding: "3px 10px", fontSize: 11, fontWeight: 700 }}>
                {c.status === "recebida" ? "✅ Recebido" : "⏳ A Receber"}
              </span>
              {c.previsao && <span style={{ color: COLORS.muted, fontSize: 11 }}>📅 {c.previsao}</span>}
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {c.status === "a_receber" && (
                <button onClick={() => marcarRecebida(c)} style={{ background: "#064E3B", border: "none", borderRadius: 8, padding: "5px 10px", color: COLORS.green, fontSize: 11, fontWeight: 700, cursor: "pointer" }}>✅ Receber</button>
              )}
              <button onClick={() => abrirEditar(c)} style={{ background: COLORS.surface, border: "none", borderRadius: 8, padding: "5px 10px", color: COLORS.text, fontSize: 11, cursor: "pointer" }}>✏️</button>
              <button onClick={() => excluir(c.id)} style={{ background: "#3B0000", border: "none", borderRadius: 8, padding: "5px 10px", color: COLORS.red, fontSize: 11, cursor: "pointer" }}>🗑️</button>
            </div>
          </div>
          {c.observacao && <div style={{ marginTop: 8, color: COLORS.muted, fontSize: 12, fontStyle: "italic", borderTop: `1px solid ${COLORS.cardBorder}`, paddingTop: 8 }}>💬 {c.observacao}</div>}
        </div>
      ))}

      {modal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 200, display: "flex", alignItems: "flex-end" }}>
          <div style={{ background: COLORS.card, borderRadius: "20px 20px 0 0", padding: 24, width: "100%", maxHeight: "90vh", overflowY: "auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <h3 style={{ color: COLORS.text, margin: 0, fontWeight: 800 }}>{editando ? "Editar Comissão" : "Nova Comissão"}</h3>
              <button onClick={() => setModal(false)} style={{ background: COLORS.surface, border: "none", borderRadius: 8, width: 32, height: 32, color: COLORS.text, cursor: "pointer", fontSize: 18 }}>×</button>
            </div>
            <Input label="Descrição *" value={form.descricao} onChange={v => setForm(p => ({ ...p, descricao: v }))} placeholder="Ex: Venda Apto Meireles" />

            {/* Seletor de Cliente */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ color: COLORS.muted, fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Cliente</div>
              {clientes.length > 0 && (
                <select
                  value=""
                  onChange={e => { if (e.target.value) setForm(p => ({ ...p, cliente: e.target.value })); }}
                  style={{ width: "100%", padding: "11px 14px", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.muted, fontSize: 13, outline: "none", marginBottom: 6 }}
                >
                  <option value="">👤 Selecionar cliente cadastrado...</option>
                  {clientes.map(cl => (
                    <option key={cl.id} value={cl.nome}>{cl.nome}{cl.telefone ? ` — ${cl.telefone}` : ""}</option>
                  ))}
                </select>
              )}
              <input
                value={form.cliente}
                onChange={e => setForm(p => ({ ...p, cliente: e.target.value }))}
                placeholder="Ou digite o nome do cliente"
                style={{ width: "100%", padding: "11px 14px", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.text, fontSize: 13, outline: "none", boxSizing: "border-box" }}
              />
            </div>

            {/* Seletor de Imóvel */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ color: COLORS.muted, fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Imóvel</div>
              {imoveis.length > 0 && (
                <select
                  value=""
                  onChange={e => {
                    const id = e.target.value; if (!id) return;
                    const im = imoveis.find(i => i.id === id);
                    if (!im) return;
                    const nomeImovel = im.titulo || im.tipo;
                    const valImovel = String(Number(im.valor || 0));
                    const val = calcValorPorPercentual(form.percentual, valImovel);
                    setForm(p => ({ ...p, imovel: nomeImovel, valorImovel: valImovel, ...(val ? { valor: val } : {}) }));
                  }}
                  style={{ width: "100%", padding: "11px 14px", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.muted, fontSize: 13, outline: "none", marginBottom: 6 }}
                >
                  <option value="">🏠 Selecionar imóvel cadastrado...</option>
                  {imoveis.map(im => (
                    <option key={im.id} value={im.id}>
                      {im.titulo || im.tipo} — R$ {Number(im.valor || 0).toLocaleString("pt-BR")}
                    </option>
                  ))}
                </select>
              )}
              {form.imovel ? (
                <div style={{ background: COLORS.surface, borderRadius: 10, padding: "10px 14px", borderLeft: `3px solid ${COLORS.accent}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700 }}>{form.imovel}</div>
                    {form.valorImovel && <div style={{ color: COLORS.muted, fontSize: 11 }}>R$ {Number(form.valorImovel).toLocaleString("pt-BR")}</div>}
                  </div>
                  <button onClick={() => setForm(p => ({ ...p, imovel: "", valorImovel: "" }))} style={{ background: "none", border: "none", color: COLORS.muted, cursor: "pointer", fontSize: 18 }}>×</button>
                </div>
              ) : (
                <input
                  value={form.imovel}
                  onChange={e => setForm(p => ({ ...p, imovel: e.target.value }))}
                  placeholder="Ou digite o nome do imóvel"
                  style={{ width: "100%", padding: "11px 14px", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, color: COLORS.text, fontSize: 13, outline: "none", boxSizing: "border-box" }}
                />
              )}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <Input label="% Comissão" value={form.percentual} onChange={v => { const val = calcValorPorPercentual(v, form.valorImovel); setForm(p => ({ ...p, percentual: v, ...(val ? { valor: val } : {}) })); }} placeholder="Ex: 6" />
              <Input label="Valor Imóvel (R$)" value={form.valorImovel} onChange={v => { const val = calcValorPorPercentual(form.percentual, v); setForm(p => ({ ...p, valorImovel: v, ...(val ? { valor: val } : {}) })); }} placeholder="Ex: 500000" />
            </div>
            <Input label="Valor da Comissão (R$) *" value={form.valor} onChange={v => setForm(p => ({ ...p, valor: v }))} placeholder="Ex: 30000" />
            <div style={{ marginBottom: 14 }}>
              <div style={{ color: COLORS.muted, fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Status</div>
              <div style={{ display: "flex", gap: 8 }}>
                {[["a_receber", "⏳ A Receber"], ["recebida", "✅ Recebido"]].map(([val, label]) => (
                  <button key={val} onClick={() => setForm(p => ({ ...p, status: val }))} style={{ flex: 1, padding: "10px 0", background: form.status === val ? (val === "recebida" ? "#064E3B" : "#422006") : COLORS.surface, color: form.status === val ? (val === "recebida" ? COLORS.green : COLORS.accent) : COLORS.muted, border: `1px solid ${form.status === val ? (val === "recebida" ? COLORS.green : COLORS.accent) : "transparent"}`, borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 12 }}>{label}</button>
                ))}
              </div>
            </div>
            <Input label="Previsão de recebimento" value={form.previsao} onChange={v => setForm(p => ({ ...p, previsao: v }))} placeholder="Ex: 15/06/2025" />
            <Input label="Observação" value={form.observacao} onChange={v => setForm(p => ({ ...p, observacao: v }))} placeholder="Anotações adicionais..." />
            <Btn full color="green" onClick={salvar}>{editando ? "💾 Salvar" : "✅ Adicionar Comissão"}</Btn>
          </div>
        </div>
      )}
    </div>
  );
}


// ─── NOTAS & TAREFAS POR VOZ ───
function Notas({ uid }) {
  const C = COLORS;
  const [tarefas, setTarefas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [aba, setAba] = useState("tarefas"); // "tarefas" | "notas"
  const [textoNovo, setTextoNovo] = useState("");
  const [prioridade, setPrioridade] = useState("normal"); // "alta" | "normal" | "baixa"
  const [escutando, setEscutando] = useState(false);
  const [suporte, setSuporte] = useState(true);
  const [notaLivre, setNotaLivre] = useState("");
  const [salvandoNota, setSalvandoNota] = useState(false);
  const [notaSalva, setNotaSalva] = useState(false);
  const [deletandoId, setDeletandoId] = useState(null);
  const reconRef = useRef(null);
  const inputRef = useRef(null);

  // Carrega tarefas do Firebase
  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "notas_tarefas"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => {
      const lista = snap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .sort((a, b) => {
          // Pendentes primeiro, depois por prioridade, depois por data
          if (a.feita !== b.feita) return a.feita ? 1 : -1;
          const pOrd = { alta: 0, normal: 1, baixa: 2 };
          if (pOrd[a.prioridade] !== pOrd[b.prioridade]) return pOrd[a.prioridade] - pOrd[b.prioridade];
          return (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0);
        });
      setTarefas(lista);
      setLoading(false);
    }, () => setLoading(false));
    return () => unsub();
  }, [uid]);

  // Carrega nota livre do Firebase
  useEffect(() => {
    if (!uid) return;
    getDoc(doc(db, "nota_livre", uid)).then(snap => {
      if (snap.exists()) setNotaLivre(snap.data().texto || "");
    });
  }, [uid]);

  // Verifica suporte a SpeechRecognition
  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) setSuporte(false);
  }, []);

  const adicionarTarefa = async (texto, prior = prioridade) => {
    const t = texto.trim();
    if (!t || !uid) return;
    await addDoc(collection(db, "notas_tarefas"), {
      texto: t, feita: false, prioridade: prior,
      uid, createdAt: serverTimestamp(),
    });
    setTextoNovo("");
    setPrioridade("normal");
  };

  const toggleFeita = async (tarefa) => {
    await updateDoc(doc(db, "notas_tarefas", tarefa.id), { feita: !tarefa.feita });
  };

  const excluir = async (id) => {
    setDeletandoId(id);
    try { await deleteDoc(doc(db, "notas_tarefas", id)); }
    catch (e) { alert("Erro ao excluir."); }
    setDeletandoId(null);
  };

  const salvarNotaLivre = async () => {
    if (!uid) return;
    setSalvandoNota(true);
    try {
      await setDoc(doc(db, "nota_livre", uid), { texto: notaLivre, updatedAt: serverTimestamp() });
      setNotaSalva(true);
      setTimeout(() => setNotaSalva(false), 2500);
    } catch (e) { alert("Erro ao salvar nota."); }
    setSalvandoNota(false);
  };

  const iniciarVoz = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;
    const rec = new SR();
    rec.lang = "pt-BR";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onstart = () => setEscutando(true);
    rec.onend = () => setEscutando(false);
    rec.onerror = (e) => {
      setEscutando(false);
      if (e.error === "not-allowed") alert("Permita o uso do microfone para usar essa função.");
    };
    rec.onresult = (e) => {
      const texto = e.results[0][0].transcript;
      // Detecta prioridade por palavras-chave na fala
      let prior = "normal";
      if (/urgent|urgente|importante|prioridade alta/i.test(texto)) prior = "alta";
      if (/baixa prioridade|quando puder|sem pressa/i.test(texto)) prior = "baixa";
      adicionarTarefa(texto, prior);
    };
    reconRef.current = rec;
    rec.start();
  };

  const pararVoz = () => {
    reconRef.current?.stop();
    setEscutando(false);
  };

  const COR_PRIOR = {
    alta:   { bg: "rgba(239,68,68,0.12)",  border: "#EF4444", texto: "#FCA5A5", label: "🔴 Alta" },
    normal: { bg: "rgba(59,130,246,0.12)", border: "#3B82F6", texto: "#93C5FD", label: "🔵 Normal" },
    baixa:  { bg: "rgba(100,116,139,0.1)", border: "#475569", texto: "#94A3B8", label: "⚪ Baixa" },
  };

  const pendentes = tarefas.filter(t => !t.feita);
  const feitas    = tarefas.filter(t => t.feita);

  return (
    <div>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
        <div>
          <h2 style={{ color: C.text, fontSize: 20, fontWeight: 900, margin: 0 }}>📝 Notas & Tarefas</h2>
          {pendentes.length > 0 && (
            <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>
              {pendentes.length} pendente{pendentes.length > 1 ? "s" : ""}
            </div>
          )}
        </div>
        {/* Botão de voz grande */}
        {suporte && aba === "tarefas" && (
          <button
            onPointerDown={iniciarVoz}
            onPointerUp={pararVoz}
            onPointerLeave={pararVoz}
            style={{
              width: 58, height: 58, borderRadius: "50%", border: "none", cursor: "pointer",
              background: escutando
                ? "linear-gradient(135deg, #EF4444, #B91C1C)"
                : "linear-gradient(135deg, #10B981, #059669)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 26, flexShrink: 0,
              boxShadow: escutando
                ? "0 0 0 6px rgba(239,68,68,0.25), 0 4px 20px rgba(239,68,68,0.4)"
                : "0 4px 16px rgba(16,185,129,0.4)",
              transition: "all 0.2s",
            }}
          >
            {escutando ? "⏹" : "🎙️"}
          </button>
        )}
      </div>

      {/* Indicador de escuta */}
      {escutando && (
        <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.4)",
          borderRadius: 12, padding: "10px 16px", marginBottom: 14,
          display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 10, height: 10, borderRadius: "50%", background: "#EF4444",
            animation: "pulse 1s infinite" }} />
          <span style={{ color: "#FCA5A5", fontWeight: 700, fontSize: 13 }}>
            Ouvindo... Fale sua tarefa e solte o botão
          </span>
        </div>
      )}

      {/* Abas */}
      <div style={{ display: "flex", background: "#111827", borderRadius: 12, padding: 4, marginBottom: 16, border: "1px solid #1E293B" }}>
        {[{ id: "tarefas", label: "✅ Tarefas" }, { id: "notas", label: "🗒️ Bloco de Notas" }].map(a => (
          <button key={a.id} onClick={() => setAba(a.id)} style={{
            flex: 1, padding: "9px 6px", borderRadius: 9, border: "none", cursor: "pointer",
            fontWeight: 700, fontSize: 13,
            background: aba === a.id ? C.accent : "transparent",
            color: aba === a.id ? "#0A0E1A" : C.muted,
          }}>{a.label}</button>
        ))}
      </div>

      {/* ── ABA TAREFAS ── */}
      {aba === "tarefas" && (
        <div>
          {/* Input nova tarefa */}
          <Card style={{ marginBottom: 14 }}>
            <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, textTransform: "uppercase",
              letterSpacing: 0.5, marginBottom: 10 }}>Nova Tarefa</div>
            <input
              ref={inputRef}
              value={textoNovo}
              onChange={e => setTextoNovo(e.target.value)}
              onKeyDown={e => e.key === "Enter" && adicionarTarefa(textoNovo)}
              placeholder="Digite ou use o 🎙️ microfone..."
              style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`,
                borderRadius: 10, padding: "10px 14px", color: C.text, fontSize: 14,
                boxSizing: "border-box", outline: "none", marginBottom: 10 }}
            />
            {/* Prioridade */}
            <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
              {Object.entries(COR_PRIOR).map(([k, v]) => (
                <button key={k} onClick={() => setPrioridade(k)} style={{
                  flex: 1, padding: "6px 4px", borderRadius: 8, border: `1.5px solid ${prioridade === k ? v.border : "#1E293B"}`,
                  background: prioridade === k ? v.bg : "transparent",
                  color: prioridade === k ? v.texto : C.muted,
                  fontSize: 11, fontWeight: 700, cursor: "pointer",
                }}>{v.label}</button>
              ))}
            </div>
            <Btn full color="accent" onClick={() => adicionarTarefa(textoNovo)}>
              ➕ Adicionar Tarefa
            </Btn>
            {suporte && (
              <div style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 8 }}>
                💡 Segure 🎙️ e fale. Diga "urgente" para marcar alta prioridade.
              </div>
            )}
          </Card>

          {/* Lista de pendentes */}
          {loading ? <Loading /> : pendentes.length === 0 && feitas.length === 0 ? (
            <div style={{ textAlign: "center", padding: "40px 20px" }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>🎯</div>
              <div style={{ color: C.muted, fontSize: 14 }}>Nenhuma tarefa ainda.</div>
              <div style={{ color: C.muted, fontSize: 12, marginTop: 4 }}>Use o microfone ou digite acima.</div>
            </div>
          ) : (
            <>
              {pendentes.length > 0 && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, textTransform: "uppercase",
                    letterSpacing: 0.5, marginBottom: 8 }}>Pendentes ({pendentes.length})</div>
                  {pendentes.map(t => {
                    const cp = COR_PRIOR[t.prioridade] || COR_PRIOR.normal;
                    return (
                      <div key={t.id} style={{ background: C.card, border: `1px solid ${C.cardBorder}`,
                        borderLeft: `3px solid ${cp.border}`, borderRadius: 12,
                        padding: "12px 14px", marginBottom: 8,
                        display: "flex", alignItems: "center", gap: 12 }}>
                        {/* Checkbox */}
                        <button onClick={() => toggleFeita(t)} style={{
                          width: 24, height: 24, borderRadius: 6, border: `2px solid ${cp.border}`,
                          background: "transparent", cursor: "pointer", flexShrink: 0,
                          display: "flex", alignItems: "center", justifyContent: "center",
                        }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ color: C.text, fontSize: 14, fontWeight: 600, lineHeight: 1.4 }}>
                            {t.texto}
                          </div>
                          <div style={{ color: cp.texto, fontSize: 10, fontWeight: 700, marginTop: 2 }}>
                            {cp.label}
                          </div>
                        </div>
                        <button onClick={() => excluir(t.id)} style={{
                          background: "transparent", border: "none", color: C.muted,
                          fontSize: 18, cursor: "pointer", flexShrink: 0, padding: "0 4px",
                          opacity: deletandoId === t.id ? 0.4 : 1,
                        }}>🗑️</button>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Feitas */}
              {feitas.length > 0 && (
                <div>
                  <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, textTransform: "uppercase",
                    letterSpacing: 0.5, marginBottom: 8 }}>Concluídas ({feitas.length})</div>
                  {feitas.map(t => (
                    <div key={t.id} style={{ background: C.card, border: `1px solid ${C.cardBorder}`,
                      borderRadius: 12, padding: "10px 14px", marginBottom: 8,
                      display: "flex", alignItems: "center", gap: 12, opacity: 0.6 }}>
                      <button onClick={() => toggleFeita(t)} style={{
                        width: 24, height: 24, borderRadius: 6,
                        background: C.green, border: "none", cursor: "pointer",
                        flexShrink: 0, fontSize: 14, display: "flex",
                        alignItems: "center", justifyContent: "center",
                      }}>✓</button>
                      <div style={{ flex: 1, color: C.muted, fontSize: 13,
                        textDecoration: "line-through" }}>{t.texto}</div>
                      <button onClick={() => excluir(t.id)} style={{
                        background: "transparent", border: "none", color: C.muted,
                        fontSize: 16, cursor: "pointer", flexShrink: 0,
                      }}>🗑️</button>
                    </div>
                  ))}
                  {/* Limpar todas concluídas */}
                  <Btn full color="surface" size="sm"
                    onClick={() => feitas.forEach(t => excluir(t.id))}
                    style={{ marginTop: 4, fontSize: 12, color: C.muted }}>
                    🧹 Limpar concluídas
                  </Btn>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ── ABA BLOCO DE NOTAS ── */}
      {aba === "notas" && (
        <div>
          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, textTransform: "uppercase",
              letterSpacing: 0.5, marginBottom: 10 }}>
              🗒️ Bloco de Notas Livre
            </div>
            <textarea
              value={notaLivre}
              onChange={e => setNotaLivre(e.target.value)}
              placeholder={"Anote aqui o que precisar:\n• Endereços de imóveis\n• Observações de visitas\n• Contatos rápidos\n• Qualquer coisa..."}
              rows={14}
              style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`,
                borderRadius: 10, padding: "12px 14px", color: C.text, fontSize: 14,
                boxSizing: "border-box", outline: "none", resize: "none",
                fontFamily: "inherit", lineHeight: 1.7 }}
            />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 8 }}>
              <span style={{ color: C.muted, fontSize: 11 }}>
                {notaLivre.length} caracteres
              </span>
              {notaSalva && (
                <span style={{ color: C.green, fontSize: 12, fontWeight: 700 }}>✅ Salvo!</span>
              )}
            </div>
          </Card>
          {notaSalva ? null : (
            <Btn full color="green" onClick={salvarNotaLivre}>
              {salvandoNota ? "Salvando..." : "💾 Salvar Nota"}
            </Btn>
          )}
        </div>
      )}
    </div>
  );
}


function Perfil({ uid, perfilData, setPerfilData }) {
  const C = COLORS;
  const [aba, setAba] = useState("dados"); // "dados" | "profissional" | "preview"
  const [form, setForm] = useState({
    nome: perfilData?.nome || "",
    sobrenome: perfilData?.sobrenome || "",
    creci: perfilData?.creci || "",
    telefone: perfilData?.telefone || "",
    email: perfilData?.email || "",
    foto: perfilData?.foto || "",
    cidade: perfilData?.cidade || "",
    estado: perfilData?.estado || "",
    bio: perfilData?.bio || "",
    anos: perfilData?.anos || "",
    instagram: perfilData?.instagram || "",
    site: perfilData?.site || "",
    especialidades: perfilData?.especialidades || [],
  });
  const [salvando, setSalvando] = useState(false);
  const [uploadandoFoto, setUploadandoFoto] = useState(false);
  const [sucesso, setSucesso] = useState(false);

  const f = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const ESPECIALIDADES_OPCOES = [
    "Residencial", "Comercial", "Industrial", "Rural",
    "Lançamentos", "Imóveis de Luxo", "Locação", "Temporada",
    "Terrenos", "Galpões",
  ];

  const toggleEspec = (item) => {
    setForm(prev => {
      const cur = prev.especialidades || [];
      return {
        ...prev,
        especialidades: cur.includes(item) ? cur.filter(x => x !== item) : [...cur, item],
      };
    });
  };

  const handleFoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadandoFoto(true);
    try {
      const url = await uploadFoto(file);
      f("foto", url);
    } catch (err) {
      alert("Erro ao enviar foto: " + err.message);
    } finally {
      setUploadandoFoto(false);
    }
  };

  const salvar = async () => {
    if (!form.nome.trim()) return alert("Digite seu nome.");
    if (!uid) return;
    setSalvando(true);
    try {
      await setDoc(doc(db, "perfil_corretor", uid), { ...form, updatedAt: serverTimestamp() });
      setPerfilData(form);
      setSucesso(true);
      setTimeout(() => setSucesso(false), 3000);
    } catch (err) {
      alert("Erro ao salvar: " + err.message);
    } finally {
      setSalvando(false);
    }
  };

  const nomeCompleto = `${form.nome} ${form.sobrenome}`.trim() || "Seu Nome";
  const ABAS = [
    { id: "dados", label: "Dados", icon: "👤" },
    { id: "profissional", label: "Profissional", icon: "🏆" },
    { id: "preview", label: "Cartão", icon: "🪪" },
  ];

  // ── PREVIEW: Cartão de Visitas Digital ──
  const CardVisitas = () => (
    <div style={{ borderRadius: 20, overflow: "hidden", boxShadow: "0 8px 40px rgba(0,0,0,0.6)", marginBottom: 20 }}>
      {/* Capa */}
      <div style={{
        background: "linear-gradient(135deg, #1E3A5F 0%, #0A0E1A 60%, #78350F 100%)",
        padding: "28px 20px 48px",
        position: "relative",
        textAlign: "center",
      }}>
        <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, opacity: 0.15,
          backgroundImage: "radial-gradient(circle at 20% 50%, #F59E0B 0%, transparent 50%), radial-gradient(circle at 80% 20%, #3B82F6 0%, transparent 40%)" }} />
        <div style={{ position: "relative" }}>
          {form.foto ? (
            <img src={form.foto} alt="Foto" style={{ width: 88, height: 88, borderRadius: "50%", objectFit: "cover",
              border: "3px solid #F59E0B", boxShadow: "0 4px 20px rgba(245,158,11,0.4)" }} />
          ) : (
            <div style={{ width: 88, height: 88, borderRadius: "50%", background: "#1E293B",
              border: "3px solid #F59E0B", display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 36, margin: "0 auto", boxShadow: "0 4px 20px rgba(245,158,11,0.3)" }}>🧑‍💼</div>
          )}
          <div style={{ color: "#F1F5F9", fontWeight: 900, fontSize: 20, marginTop: 10, letterSpacing: 0.3 }}>
            {nomeCompleto}
          </div>
          <div style={{ color: "#F59E0B", fontWeight: 700, fontSize: 12, marginTop: 3, letterSpacing: 1 }}>
            CORRETOR DE IMÓVEIS
          </div>
          {form.creci && (
            <div style={{ display: "inline-block", background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.4)",
              borderRadius: 20, padding: "3px 14px", color: "#FCD34D", fontSize: 11, fontWeight: 700, marginTop: 6 }}>
              CRECI {form.creci}
            </div>
          )}
          {form.cidade && (
            <div style={{ color: "#94A3B8", fontSize: 12, marginTop: 6 }}>
              📍 {form.cidade}{form.estado ? `, ${form.estado}` : ""}
            </div>
          )}
        </div>
      </div>

      {/* Corpo */}
      <div style={{ background: "#111827", padding: "20px 20px 24px", borderTop: "1px solid #1E293B" }}>
        {form.bio && (
          <div style={{ color: "#CBD5E1", fontSize: 13, lineHeight: 1.6, fontStyle: "italic",
            borderLeft: "3px solid #F59E0B", paddingLeft: 12, marginBottom: 16 }}>
            "{form.bio}"
          </div>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {form.telefone && (
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: "#064E3B",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>📱</div>
              <div>
                <div style={{ color: "#64748B", fontSize: 10, fontWeight: 700, textTransform: "uppercase" }}>WhatsApp</div>
                <div style={{ color: "#F1F5F9", fontSize: 14, fontWeight: 600 }}>{form.telefone}</div>
              </div>
            </div>
          )}
          {form.email && (
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10, background: "#1E3A8A",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>✉️</div>
              <div>
                <div style={{ color: "#64748B", fontSize: 10, fontWeight: 700, textTransform: "uppercase" }}>E-mail</div>
                <div style={{ color: "#F1F5F9", fontSize: 13, fontWeight: 600 }}>{form.email}</div>
              </div>
            </div>
          )}
          {form.instagram && (
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: 10,
                background: "linear-gradient(135deg,#833ab4,#fd1d1d,#fcb045)",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>📸</div>
              <div>
                <div style={{ color: "#64748B", fontSize: 10, fontWeight: 700, textTransform: "uppercase" }}>Instagram</div>
                <div style={{ color: "#F1F5F9", fontSize: 14, fontWeight: 600 }}>@{form.instagram.replace("@","")}</div>
              </div>
            </div>
          )}
        </div>

        {form.especialidades?.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <div style={{ color: "#64748B", fontSize: 10, fontWeight: 700, textTransform: "uppercase", marginBottom: 8 }}>
              Especialidades
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {form.especialidades.map(e => (
                <span key={e} style={{ background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)",
                  color: "#FCD34D", fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 20 }}>
                  {e}
                </span>
              ))}
            </div>
          </div>
        )}

        {form.anos && (
          <div style={{ marginTop: 16, background: "#1E293B", borderRadius: 12, padding: "12px 16px",
            display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontSize: 28, fontWeight: 900, color: "#F59E0B", lineHeight: 1 }}>{form.anos}</div>
            <div style={{ color: "#94A3B8", fontSize: 12, lineHeight: 1.4 }}>anos de<br/><span style={{ color: "#F1F5F9", fontWeight: 700 }}>experiência</span></div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div>
      {/* Header com avatar hero */}
      <div style={{ background: "linear-gradient(160deg, #1E293B 0%, #0A0E1A 100%)",
        borderRadius: 20, padding: "24px 20px 20px", marginBottom: 16,
        border: "1px solid #1E293B", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -30, right: -30, width: 140, height: 140,
          borderRadius: "50%", background: "radial-gradient(circle, rgba(245,158,11,0.12) 0%, transparent 70%)" }} />
        <div style={{ display: "flex", alignItems: "center", gap: 16, position: "relative" }}>
          <div style={{ position: "relative", flexShrink: 0 }}>
            {form.foto ? (
              <img src={form.foto} alt="Foto" style={{ width: 80, height: 80, borderRadius: "50%",
                objectFit: "cover", border: "3px solid #F59E0B", boxShadow: "0 0 20px rgba(245,158,11,0.3)" }} />
            ) : (
              <div style={{ width: 80, height: 80, borderRadius: "50%", background: "#1E293B",
                border: "3px solid #F59E0B", display: "flex", alignItems: "center",
                justifyContent: "center", fontSize: 34 }}>🧑‍💼</div>
            )}
            <label style={{ position: "absolute", bottom: 0, right: 0, background: "#F59E0B",
              borderRadius: "50%", width: 26, height: 26, display: "flex", alignItems: "center",
              justifyContent: "center", cursor: "pointer", fontSize: 13,
              boxShadow: "0 2px 8px rgba(0,0,0,0.5)" }}>
              {uploadandoFoto ? "⏳" : "📷"}
              <input type="file" accept="image/*" onChange={handleFoto} style={{ display: "none" }} />
            </label>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ color: "#F1F5F9", fontWeight: 900, fontSize: 18, lineHeight: 1.2, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              {nomeCompleto === " " ? "Seu Nome" : nomeCompleto}
            </div>
            {form.creci ? (
              <div style={{ color: "#F59E0B", fontSize: 12, fontWeight: 700, marginTop: 3 }}>CRECI {form.creci}</div>
            ) : (
              <div style={{ color: "#475569", fontSize: 12, marginTop: 3 }}>Complete seu perfil ↓</div>
            )}
            {form.cidade && (
              <div style={{ color: "#64748B", fontSize: 12, marginTop: 2 }}>
                📍 {form.cidade}{form.estado ? `, ${form.estado}` : ""}
              </div>
            )}
            {form.anos && (
              <div style={{ display: "inline-flex", alignItems: "center", gap: 5, background: "rgba(245,158,11,0.12)",
                border: "1px solid rgba(245,158,11,0.25)", borderRadius: 20, padding: "2px 10px", marginTop: 6 }}>
                <span style={{ color: "#FCD34D", fontSize: 11, fontWeight: 700 }}>⭐ {form.anos} anos de experiência</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Abas */}
      <div style={{ display: "flex", background: "#111827", borderRadius: 14, padding: 4, marginBottom: 16, border: "1px solid #1E293B" }}>
        {ABAS.map(a => (
          <button key={a.id} onClick={() => setAba(a.id)} style={{
            flex: 1, padding: "9px 6px", borderRadius: 10, border: "none", cursor: "pointer",
            fontWeight: 700, fontSize: 12, transition: "all 0.2s",
            background: aba === a.id ? "#F59E0B" : "transparent",
            color: aba === a.id ? "#0A0E1A" : "#64748B",
          }}>
            {a.icon} {a.label}
          </button>
        ))}
      </div>

      {/* ABA: DADOS PESSOAIS */}
      {aba === "dados" && (
        <div>
          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 14, letterSpacing: 0.5 }}>
              👤 Dados Pessoais
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Input label="Nome" value={form.nome} onChange={v => f("nome", v)} placeholder="João" />
              <Input label="Sobrenome" value={form.sobrenome} onChange={v => f("sobrenome", v)} placeholder="Silva" />
            </div>
            <Input label="WhatsApp" value={form.telefone} onChange={v => f("telefone", v)} placeholder="(11) 99999-9999" type="tel" />
            <Input label="E-mail" value={form.email} onChange={v => f("email", v)} placeholder="corretor@email.com" type="email" />
          </Card>

          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 14, letterSpacing: 0.5 }}>
              📍 Localização
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 80px", gap: 12 }}>
              <Input label="Cidade" value={form.cidade} onChange={v => f("cidade", v)} placeholder="São Paulo" />
              <Input label="Estado" value={form.estado} onChange={v => f("estado", v)} placeholder="SP" />
            </div>
          </Card>

          <Card style={{ marginBottom: 16 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 14, letterSpacing: 0.5 }}>
              🔗 Redes Sociais
            </div>
            <Input label="Instagram (sem @)" value={form.instagram} onChange={v => f("instagram", v)} placeholder="seu.perfil" />
            <Input label="Site / Link" value={form.site} onChange={v => f("site", v)} placeholder="https://seusite.com.br" />
          </Card>
        </div>
      )}

      {/* ABA: PROFISSIONAL */}
      {aba === "profissional" && (
        <div>
          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 14, letterSpacing: 0.5 }}>
              🏆 Dados Profissionais
            </div>
            <Input label="CRECI" value={form.creci} onChange={v => f("creci", v)} placeholder="Ex: 123456-F" />
            <Input label="Anos de Experiência" value={form.anos} onChange={v => f("anos", v)} placeholder="Ex: 8" type="number" />
          </Card>

          <Card style={{ marginBottom: 12 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 12, letterSpacing: 0.5 }}>
              💬 Bio / Apresentação
            </div>
            <textarea
              value={form.bio}
              onChange={e => f("bio", e.target.value)}
              placeholder="Conte um pouco sobre você e seu trabalho..."
              maxLength={160}
              rows={3}
              style={{ width: "100%", background: "#1E293B", border: "1px solid #1E293B", borderRadius: 10,
                padding: "10px 14px", color: "#F1F5F9", fontSize: 14, boxSizing: "border-box",
                outline: "none", resize: "none", fontFamily: "inherit", lineHeight: 1.5 }}
            />
            <div style={{ color: "#475569", fontSize: 11, textAlign: "right", marginTop: 4 }}>
              {form.bio?.length || 0}/160 caracteres
            </div>
          </Card>

          <Card style={{ marginBottom: 16 }}>
            <div style={{ color: "#64748B", fontSize: 11, fontWeight: 700, textTransform: "uppercase", marginBottom: 14, letterSpacing: 0.5 }}>
              🏠 Especialidades
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
              {ESPECIALIDADES_OPCOES.map(item => {
                const ativo = form.especialidades?.includes(item);
                return (
                  <button key={item} onClick={() => toggleEspec(item)} style={{
                    padding: "7px 13px", borderRadius: 20, border: ativo ? "1.5px solid #F59E0B" : "1.5px solid #1E293B",
                    background: ativo ? "rgba(245,158,11,0.15)" : "#1E293B",
                    color: ativo ? "#FCD34D" : "#64748B",
                    fontSize: 12, fontWeight: 700, cursor: "pointer", transition: "all 0.15s",
                  }}>
                    {ativo ? "✓ " : ""}{item}
                  </button>
                );
              })}
            </div>
          </Card>
        </div>
      )}

      {/* ABA: PREVIEW CARTÃO */}
      {aba === "preview" && (
        <div>
          <div style={{ color: "#64748B", fontSize: 12, textAlign: "center", marginBottom: 14 }}>
            Pré-visualização do seu cartão digital
          </div>
          <CardVisitas />
          <div style={{ background: "#111827", border: "1px solid #1E293B", borderRadius: 12,
            padding: "12px 16px", color: "#64748B", fontSize: 12, textAlign: "center" }}>
            💡 Este cartão é gerado automaticamente com seus dados.<br/>
            Salve o perfil para atualizar.
          </div>
        </div>
      )}

      {/* Feedback + Botão Salvar */}
      {sucesso && (
        <div style={{ background: "#064E3B", border: "1px solid #10B981", borderRadius: 12,
          padding: "12px 16px", color: "#10B981", fontWeight: 700, fontSize: 14,
          textAlign: "center", marginBottom: 12, marginTop: 4 }}>
          ✅ Perfil salvo com sucesso!
        </div>
      )}

      <Btn full color="green" onClick={salvar} style={{ marginBottom: 8, marginTop: 4 }}>
        {salvando ? "Salvando..." : "💾 Salvar Perfil"}
      </Btn>
    </div>
  );
}

// ─── MEU LINK ───
function MeuLink({ uid, user }) {
  const C = COLORS;
  const BASE_URL = "https://imovepro01.netlify.app";

  // BUG #1 CORRIGIDO: dados salvos no Firebase em vez de localStorage
  const [wa, setWa]         = useState("");
  const [fbPage, setFbPage] = useState("");
  const [igUser, setIgUser] = useState("");
  const [links, setLinks]   = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [novaOrigem, setNovaOrigem] = useState("");
  const [copiado, setCopiado]       = useState(null);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [abaCanal, setAbaCanal]       = useState("whatsapp");

  // Carrega dados do Firebase na montagem
  useEffect(() => {
    if (!uid) return;
    const ref = doc(db, "meulink", uid);
    getDoc(ref).then(snap => {
      if (snap.exists()) {
        const d = snap.data();
        setWa(d.wa || user?.phoneNumber?.replace(/\D/g, "") || "");
        setFbPage(d.fbPage || "");
        setIgUser(d.igUser || "");
        setLinks(d.links || []);
      } else {
        // Pré-preenche WhatsApp do perfil se disponível
        setWa(user?.phoneNumber?.replace(/\D/g, "") || "");
      }
      setCarregando(false);
    }).catch(() => setCarregando(false));
  }, [uid]);

  // Salva no Firebase ao mudar (debounced via useEffect)
  useEffect(() => {
    if (carregando || !uid) return;
    const ref = doc(db, "meulink", uid);
    const timer = setTimeout(() => {
      setDoc(ref, { wa, fbPage, igUser, links }, { merge: true })
        .catch(e => console.error("Erro ao salvar MeuLink:", e));
    }, 800);
    return () => clearTimeout(timer);
  }, [wa, fbPage, igUser, links, carregando, uid]);

  const CANAIS = [
    { id: "whatsapp",  emoji: "💬", label: "WhatsApp",  cor: "#25D366" },
    { id: "facebook",  emoji: "📘", label: "Facebook",  cor: "#1877F2" },
    { id: "instagram", emoji: "📸", label: "Instagram", cor: "#E1306C" },
  ];

  const gerarLink = (origem) => {
    const params = new URLSearchParams({ uid, wa: wa || "00000000000", origem });
    return `${BASE_URL}/captacao?${params.toString()}`;
  };

  const copiar = (texto, key) => {
    navigator.clipboard.writeText(texto).then(() => {
      setCopiado(key);
      setTimeout(() => setCopiado(null), 2000);
    });
  };

  const adicionarLink = () => {
    const nome = novaOrigem.trim();
    if (!nome) return;
    if (links.find(l => l.toLowerCase() === nome.toLowerCase())) {
      alert("Já existe um link com esse nome!"); return;
    }
    setLinks(prev => [...prev, nome]);
    setNovaOrigem("");
    setMostrarForm(false);
  };

  const removerLink = (origem) => {
    setLinks(prev => prev.filter(l => l !== origem));
  };

  // Gera link de compartilhamento para cada canal
  const compartilharCanal = (captacaoLink, canal) => {
    const txt = encodeURIComponent(`🏡 Encontre seu imóvel ideal! Preencha e receba atendimento personalizado:\n${captacaoLink}`);
    if (canal === "whatsapp")  return `https://wa.me/?text=${txt}`;
    if (canal === "facebook")  return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(captacaoLink)}`;
    if (canal === "instagram") return null; // Instagram não tem share URL — copia o link
    return captacaoLink;
  };

  const canalAtual = CANAIS.find(c => c.id === abaCanal);

  if (carregando) return (
    <div style={{ textAlign: "center", padding: 48, color: COLORS.muted, fontSize: 14 }}>
      🔗 Carregando seus links...
    </div>
  );

  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <div style={{ color: C.text, fontWeight: 800, fontSize: 20, marginBottom: 4 }}>🔗 Meu Link de Captação</div>
        <div style={{ color: C.muted, fontSize: 13 }}>Crie links por origem — cada lead chega direto no seu CRM.</div>
      </div>

      {/* ── Configurar Canais ── */}
      <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 16, padding: 18, marginBottom: 14 }}>
        <div style={{ color: C.text, fontWeight: 700, fontSize: 14, marginBottom: 14 }}>⚙️ Configure seus canais de notificação</div>

        {/* Abas dos canais */}
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          {CANAIS.map(canal => (
            <button key={canal.id} onClick={() => setAbaCanal(canal.id)}
              style={{
                flex: 1, padding: "9px 0", borderRadius: 10, border: "none", cursor: "pointer", fontWeight: 700, fontSize: 12,
                background: abaCanal === canal.id ? canal.cor : C.surface,
                color: abaCanal === canal.id ? "#fff" : C.muted,
                transition: "all 0.15s",
              }}>
              {canal.emoji} {canal.label}
            </button>
          ))}
        </div>

        {/* WhatsApp */}
        {abaCanal === "whatsapp" && (
          <div>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 5, fontWeight: 700, textTransform: "uppercase" }}>
              Seu número (com DDD, sem + ou espaços)
            </label>
            <input
              type="tel"
              value={wa}
              onChange={e => setWa(e.target.value.replace(/\D/g, ""))}
              placeholder="Ex: 85999990000"
              style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "11px 14px", color: C.text, fontSize: 15, boxSizing: "border-box", outline: "none" }}
            />
            <div style={{ color: C.muted, fontSize: 11, marginTop: 6 }}>
              📲 Quando um lead preencher o formulário, você recebe a mensagem aqui.
            </div>
          </div>
        )}

        {/* Facebook */}
        {abaCanal === "facebook" && (
          <div>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 5, fontWeight: 700, textTransform: "uppercase" }}>
              URL ou nome da sua Página do Facebook
            </label>
            <input
              type="text"
              value={fbPage}
              onChange={e => setFbPage(e.target.value.trim())}
              placeholder="Ex: facebook.com/seunegocio ou seunegocio"
              style={{ width: "100%", background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "11px 14px", color: C.text, fontSize: 15, boxSizing: "border-box", outline: "none" }}
            />
            <div style={{ color: C.muted, fontSize: 11, marginTop: 6 }}>
              📘 O link de captação pode ser compartilhado diretamente na bio ou em posts.
            </div>
            {fbPage && (
              <button
                onClick={() => window.open(`https://facebook.com/${fbPage.replace(/.*facebook\.com\//i, "")}`, "_blank")}
                style={{ marginTop: 10, background: "#1877F2", color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                📘 Abrir Página
              </button>
            )}
          </div>
        )}

        {/* Instagram */}
        {abaCanal === "instagram" && (
          <div>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 5, fontWeight: 700, textTransform: "uppercase" }}>
              Seu @ do Instagram (sem o @)
            </label>
            <div style={{ display: "flex", alignItems: "center", gap: 0 }}>
              <span style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRight: "none", borderRadius: "10px 0 0 10px", padding: "11px 12px", color: C.muted, fontSize: 15 }}>@</span>
              <input
                type="text"
                value={igUser}
                onChange={e => setIgUser(e.target.value.replace(/[@\s]/g, "").trim())}
                placeholder="seuperfil"
                style={{ flex: 1, background: C.surface, border: `1px solid ${C.cardBorder}`, borderLeft: "none", borderRadius: "0 10px 10px 0", padding: "11px 14px", color: C.text, fontSize: 15, outline: "none" }}
              />
            </div>
            <div style={{ color: C.muted, fontSize: 11, marginTop: 6 }}>
              📸 Cole o link de captação na bio do seu perfil para capturar leads do Instagram.
            </div>
            {igUser && (
              <button
                onClick={() => window.open(`https://instagram.com/${igUser}`, "_blank")}
                style={{ marginTop: 10, background: "#E1306C", color: "#fff", border: "none", borderRadius: 8, padding: "8px 16px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                📸 Abrir Perfil
              </button>
            )}
          </div>
        )}
      </div>

      {/* ── Links de captação ── */}
      <div style={{ background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 16, padding: 18, marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: links.length > 0 ? 14 : 0 }}>
          <div style={{ color: C.text, fontWeight: 700, fontSize: 14 }}>📋 Seus links de captação</div>
          <button
            onClick={() => { setMostrarForm(v => !v); setNovaOrigem(""); }}
            style={{ background: C.accent, color: "#0A0E1A", border: "none", borderRadius: 10, padding: "7px 14px", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>
            ＋ Novo link
          </button>
        </div>

        {/* Formulário novo link */}
        {mostrarForm && (
          <div style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 12, padding: 14, marginBottom: links.length > 0 ? 14 : 0 }}>
            <label style={{ display: "block", color: C.muted, fontSize: 11, marginBottom: 6, fontWeight: 700, textTransform: "uppercase" }}>Nome da origem</label>
            <input
              type="text"
              value={novaOrigem}
              onChange={e => setNovaOrigem(e.target.value)}
              onKeyDown={e => e.key === "Enter" && adicionarLink()}
              placeholder="Ex: Instagram, TikTok, Outdoor..."
              autoFocus
              style={{ width: "100%", background: C.card, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "11px 14px", color: C.text, fontSize: 14, boxSizing: "border-box", outline: "none", marginBottom: 10 }}
            />
            {/* Atalhos rápidos */}
            <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
              {["WhatsApp", "Facebook", "Instagram", "TikTok", "Google Ads", "Outdoor"].map(s => (
                <button key={s} onClick={() => setNovaOrigem(s)}
                  style={{ background: novaOrigem === s ? C.accent : C.card, color: novaOrigem === s ? "#0A0E1A" : C.muted, border: `1px solid ${C.cardBorder}`, borderRadius: 20, padding: "4px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                  {s === "WhatsApp" ? "💬" : s === "Facebook" ? "📘" : s === "Instagram" ? "📸" : s === "TikTok" ? "🎵" : s === "Google Ads" ? "🔍" : "🪧"} {s}
                </button>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={adicionarLink}
                style={{ flex: 1, background: C.accent, color: "#0A0E1A", border: "none", borderRadius: 10, padding: "11px 0", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>
                ✅ Criar Link
              </button>
              <button onClick={() => setMostrarForm(false)}
                style={{ background: C.surface, color: C.muted, border: `1px solid ${C.cardBorder}`, borderRadius: 10, padding: "11px 16px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                Cancelar
              </button>
            </div>
          </div>
        )}

        {/* Nenhum link ainda */}
        {links.length === 0 && !mostrarForm && (
          <div style={{ textAlign: "center", padding: "28px 0", color: C.muted, fontSize: 13 }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🔗</div>
            Nenhum link criado ainda.<br />
            <span style={{ color: C.accent, fontWeight: 700 }}>Clique em "+ Novo link" para começar!</span>
          </div>
        )}

        {/* Lista de links */}
        {links.map((o, idx) => {
          const link = gerarLink(o);
          // detecta o canal pelo nome da origem
          const canalDetectado = CANAIS.find(c => o.toLowerCase().includes(c.id) || o.toLowerCase().includes(c.label.toLowerCase()));
          const corCanal = canalDetectado?.cor || C.accent;
          const emojiCanal = canalDetectado?.emoji || "🔗";
          return (
            <div key={o} style={{ borderTop: idx === 0 && !mostrarForm ? "none" : `1px solid ${C.cardBorder}`, paddingTop: idx === 0 ? 0 : 14, paddingBottom: 14 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 18 }}>{emojiCanal}</span>
                  <div style={{ color: C.text, fontWeight: 700, fontSize: 14 }}>{o}</div>
                </div>
                <button onClick={() => removerLink(o)}
                  style={{ background: "transparent", color: "#EF4444", border: "none", fontSize: 18, cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>
                  ✕
                </button>
              </div>
              <div style={{ background: C.surface, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "8px 12px", fontSize: 11, color: C.muted, wordBreak: "break-all", marginBottom: 10 }}>
                {link}
              </div>
              {/* Botões de ação */}
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button onClick={() => copiar(link, o)}
                  style={{ flex: "1 1 120px", background: copiado === o ? C.green : C.accent, color: copiado === o ? "#fff" : "#0A0E1A", border: "none", borderRadius: 8, padding: "9px 0", fontWeight: 800, fontSize: 12, cursor: "pointer" }}>
                  {copiado === o ? "✅ Copiado!" : "📋 Copiar"}
                </button>
                {/* WhatsApp share */}
                {wa && (
                  <button onClick={() => window.open(compartilharCanal(link, "whatsapp"), "_blank")}
                    style={{ background: "#25D366", color: "#fff", border: "none", borderRadius: 8, padding: "9px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                    💬
                  </button>
                )}
                {/* Facebook share */}
                <button onClick={() => window.open(compartilharCanal(link, "facebook"), "_blank")}
                  style={{ background: "#1877F2", color: "#fff", border: "none", borderRadius: 8, padding: "9px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                  📘
                </button>
                {/* Instagram — copia link (não tem share URL) */}
                <button onClick={() => copiar(link, `ig-${o}`)}
                  style={{ background: "#E1306C", color: "#fff", border: "none", borderRadius: 8, padding: "9px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}
                  title="Copiar para colar na bio do Instagram">
                  {copiado === `ig-${o}` ? "✅" : "📸"}
                </button>
                <button onClick={() => window.open(link, "_blank")}
                  style={{ background: C.surface, color: C.text, border: `1px solid ${C.cardBorder}`, borderRadius: 8, padding: "9px 12px", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                  👁️
                </button>
              </div>
              {copiado === `ig-${o}` && (
                <div style={{ color: "#E1306C", fontSize: 11, marginTop: 6, fontWeight: 600 }}>
                  📸 Link copiado! Cole na bio do seu Instagram.
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ── Dica ── */}
      <div style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.25)", borderRadius: 14, padding: 16 }}>
        <div style={{ color: C.accent, fontWeight: 700, fontSize: 13, marginBottom: 8 }}>💡 Como usar</div>
        <div style={{ color: C.muted, fontSize: 12, lineHeight: 1.8 }}>
          1. Configure seu <strong style={{ color: "#25D366" }}>💬 WhatsApp</strong>, <strong style={{ color: "#1877F2" }}>📘 Facebook</strong> e <strong style={{ color: "#E1306C" }}>📸 Instagram</strong> acima.<br />
          2. Clique em <strong style={{ color: C.text }}>+ Novo link</strong> e escolha a origem (ex: Instagram, Facebook...).<br />
          3. Copie e compartilhe nos botões 💬 📘 📸 de cada link.<br />
          4. Cada lead vai direto para o seu <strong style={{ color: C.text }}>CRM → coluna Lead</strong>.<br />
          5. Você recebe notificação no WhatsApp na hora! 🚀
        </div>
      </div>
    </div>
  );
}

export default function App({ uid: uidProp, user, assinatura, onSair }) {
  // BUG #2 CORRIGIDO: nunca usar UID de fallback — se não tiver uid real, bloqueia
  const CORRETOR_UID = uidProp || null;
  if (!CORRETOR_UID) {
    return (
      <div style={{ background: "#0A0E1A", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
        <div style={{ textAlign: "center", padding: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🔒</div>
          <div style={{ color: "#EF4444", fontWeight: 800, fontSize: 18, marginBottom: 8 }}>Sessão inválida</div>
          <div style={{ color: "#64748B", fontSize: 14 }}>Faça login para continuar.</div>
        </div>
      </div>
    );
  }
  const [active, setActive] = useState("dashboard");
  const [installPrompt, setInstallPrompt] = useState(null);
  const [showInstall, setShowInstall] = useState(false);

  // ── Preferência WhatsApp: "normal" | "business" | null (pergunta) ──
  const [waPref, setWaPref] = useState(() => localStorage.getItem("waPref") || null);
  const [waPendente, setWaPendente] = useState(null); // { url } aguardando escolha

  // Substitui todos os window.open(wa.me...) — chama isso em vez de window.open direto
  const abrirWhatsApp = useCallback((url) => {
    const pref = localStorage.getItem("waPref");
    const urlFinal = (p) => {
      if (p === "business") return url.replace("https://wa.me", "https://api.whatsapp.com/send").replace("wa.me", "api.whatsapp.com/send");
      return url; // normal
    };
    if (pref) {
      window.open(urlFinal(pref), "_blank");
    } else {
      setWaPendente({ url });
    }
  }, []);

  const escolherWa = (tipo) => {
    localStorage.setItem("waPref", tipo);
    setWaPref(tipo);
    if (waPendente) {
      const url = tipo === "business"
        ? waPendente.url.replace("https://wa.me/", "https://api.whatsapp.com/send?phone=").replace("?text=", "&text=")
        : waPendente.url;
      window.open(url, "_blank");
      setWaPendente(null);
    }
  };

  // Registra o handler global para que qualquer componente use abrirWhatsApp()
  useEffect(() => {
    registrarAbrirWhatsApp((url) => {
      const pref = localStorage.getItem("waPref");
      const urlFinal = (p) => p === "business"
        ? url.replace("https://wa.me/", "https://api.whatsapp.com/send?phone=").replace("?text=", "&text=")
        : url;
      if (pref) {
        window.open(urlFinal(pref), "_blank");
      } else {
        setWaPendente({ url });
      }
    });
  }, []);

  // Captura o evento de instalação PWA
  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setInstallPrompt(e);
      setShowInstall(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const instalarApp = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === "accepted") setShowInstall(false);
    setInstallPrompt(null);
  };
  const [imoveis, setImoveis] = useState([]);
  const [clientes, setClientes] = useState([]);
  const [processos, setProcessos] = useState([]);
  const [correspondentes, setCorrespondentes] = useState([]);
  const [loadingImoveis, setLoadingImoveis] = useState(true);
  const [loadingClientes, setLoadingClientes] = useState(true);
  const [loadingProcessos, setLoadingProcessos] = useState(true);
  const [loadingCorrespondentes, setLoadingCorrespondentes] = useState(true);
  const [notifProcesso, setNotifProcesso] = useState(null); // { cliente, etapa, banco }
  const [notifLead, setNotifLead] = useState(null); // { nome, origem }
  const [perfilData, setPerfilData] = useState(null);
  const [showBannerPush, setShowBannerPush] = useState(false);

  // ── Sistema de Notificações v9 ──
  const notif = useNotificacoes({ uid: CORRETOR_UID, imoveis, processos, setActive });

  // Mostra banner de permissão push 5 segundos após login (1 vez por sessão)
  useEffect(() => {
    if (!CORRETOR_UID) return;
    if (notif.permissao === "granted") return;
    if (sessionStorage.getItem("push_banner_shown")) return;
    const timer = setTimeout(() => {
      setShowBannerPush(true);
      sessionStorage.setItem("push_banner_shown", "1");
    }, 5000);
    return () => clearTimeout(timer);
  }, [CORRETOR_UID, notif.permissao]);

  // Carrega perfil do corretor
  useEffect(() => {
    if (!CORRETOR_UID) return;
    const ref = doc(db, "perfil_corretor", CORRETOR_UID);
    const unsub = onSnapshot(ref, snap => {
      if (snap.exists()) setPerfilData(snap.data());
    });
    return () => unsub();
  }, []);

  // Carrega dados do corretor
  useEffect(() => {
    const uid = CORRETOR_UID;

    const q1 = query(collection(db, "imoveis"), where("uid", "==", uid));
    const unsub1 = onSnapshot(q1, snap => { setImoveis(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)))); setLoadingImoveis(false); }, () => setLoadingImoveis(false));

    const q2 = query(collection(db, "negocios"), where("uid", "==", uid));
    const unsub2 = onSnapshot(q2, snap => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)));
      setClientes(lista);
      setLoadingClientes(false);
    }, () => setLoadingClientes(false));

    const q3 = query(collection(db, "processos"), where("uid", "==", uid));
    const processosRef_inner = { prev: [] };
    const unsub3 = onSnapshot(q3, snap => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)));

      // Detectar processo atualizado pelo correspondente
      const prevMap = Object.fromEntries(processosRef_inner.prev.map(p => [p.id, p]));
      lista.forEach(p => {
        const anterior = prevMap[p.id];
        if (anterior && p.updatedByCorrespondente && (
          !anterior.updatedByCorrespondente ||
          p.updatedByCorrespondente.seconds !== anterior.updatedByCorrespondente?.seconds
        )) {
          tocarSomProcesso();
          setNotifProcesso({ cliente: p.cliente, etapa: p.etapa, banco: p.banco });
          setTimeout(() => setNotifProcesso(null), 6000);
        }
      });
      processosRef_inner.prev = lista;

      setProcessos(lista);
      setLoadingProcessos(false);
    }, () => setLoadingProcessos(false));

    const q4 = query(collection(db, "correspondentes"), where("uid", "==", uid));
    const unsub4 = onSnapshot(q4, snap => { setCorrespondentes(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b) => (a.nome || "").localeCompare(b.nome || ""))); setLoadingCorrespondentes(false); }, () => setLoadingCorrespondentes(false));

    // ── Listener global de leads WhatsApp — toca cha-ching em qualquer tela ──
    const q5 = query(collection(db, "whatsapp_leads"), where("uid", "==", uid));
    const leadsIdsGlobal = { prev: null }; // null = primeira carga, não dispara
    const unsub5 = onSnapshot(q5, snap => {
      const pendentes = snap.docs
        .map(d => ({ id: d.id, ...d.data() }))
        .filter(l => l.status === "pendente");
      const idsAgora = pendentes.map(l => l.id);

      if (leadsIdsGlobal.prev !== null) {
        const novos = pendentes.filter(l => !leadsIdsGlobal.prev.includes(l.id));
        if (novos.length > 0) {
          tocarSomDinheiro(); // 💰 Cha-ching!
          const lead = novos[0];
          setNotifLead({ nome: lead.nome || lead.remetente || "Novo lead", origem: lead.tipoNegocio || lead.interesse || "WhatsApp" });
          setTimeout(() => setNotifLead(null), 7000);
        }
      }
      leadsIdsGlobal.prev = idsAgora;
    }, () => {});

    return () => { unsub1(); unsub2(); unsub3(); unsub4(); unsub5(); };
  }, []);

  const nomeCompleto = perfilData?.nome && perfilData?.sobrenome
    ? `${perfilData.nome} ${perfilData.sobrenome}`
    : perfilData?.nome || user?.displayName?.split("|")[0]?.trim() || user?.email?.split("@")[0] || "Corretor";
  const creci = perfilData?.creci || null;

  const pages = {
    dashboard: <Dashboard imoveis={imoveis} clientes={clientes} processos={processos} setActive={setActive} nomeCompleto={nomeCompleto} creci={creci} fotoPerfil={perfilData?.foto || null} />,
    imoveis: <Imoveis imoveis={imoveis} loading={loadingImoveis} uid={CORRETOR_UID} perfilData={perfilData} />,
    agenda: <Agenda uid={CORRETOR_UID} imoveis={imoveis} clientes={clientes} />,
    bancario: <Bancario processos={processos} clientes={clientes} imoveis={imoveis} loading={loadingProcessos} uid={CORRETOR_UID} correspondentes={correspondentes} loadingCorrespondentes={loadingCorrespondentes} />,
    calculadora: <Calculadora />,
    comissao: <Comissao imoveis={imoveis} />,
    avaliacao: <Avaliacao uid={CORRETOR_UID} />,
    documentos: <Documentos uid={CORRETOR_UID} />,
    financeiro: <Financeiro uid={CORRETOR_UID} clientes={clientes} imoveis={imoveis} />,
    crm: <CRM uid={CORRETOR_UID} />,
    notas: <Notas uid={CORRETOR_UID} />,
    meulink: <MeuLink uid={CORRETOR_UID} user={user} />,
    perfil: <Perfil uid={CORRETOR_UID} perfilData={perfilData} setPerfilData={setPerfilData} />,
  };

  return (
    <div onClick={desbloquearAudio} onTouchStart={desbloquearAudio} style={{ background: COLORS.bg, minHeight: "100vh", maxWidth: 430, margin: "0 auto", fontFamily: "'Segoe UI', system-ui, sans-serif", paddingBottom: 80 }}>

      {/* Modal de escolha WhatsApp normal vs Business */}
      {waPendente && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 999, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "#1E293B", borderRadius: "20px 20px 0 0", padding: 24, width: "100%", maxWidth: 430 }}>
            <div style={{ color: "#F1F5F9", fontWeight: 800, fontSize: 16, marginBottom: 6 }}>💬 Abrir com qual WhatsApp?</div>
            <div style={{ color: "#64748B", fontSize: 13, marginBottom: 20 }}>Sua escolha será salva. Você pode mudar nas configurações.</div>
            <button onClick={() => escolherWa("normal")} style={{ width: "100%", background: "#25D366", border: "none", borderRadius: 14, padding: "14px 0", color: "#fff", fontWeight: 800, fontSize: 15, cursor: "pointer", marginBottom: 10 }}>
              📱 WhatsApp Pessoal
            </button>
            <button onClick={() => escolherWa("business")} style={{ width: "100%", background: "#128C7E", border: "none", borderRadius: 14, padding: "14px 0", color: "#fff", fontWeight: 800, fontSize: 15, cursor: "pointer", marginBottom: 10 }}>
              💼 WhatsApp Business
            </button>
            <button onClick={() => setWaPendente(null)} style={{ width: "100%", background: "transparent", border: "1px solid #334155", borderRadius: 14, padding: "12px 0", color: "#64748B", fontWeight: 600, fontSize: 14, cursor: "pointer" }}>
              Cancelar
            </button>
          </div>
        </div>
      )}
      <div style={{ background: COLORS.card, borderBottom: `1px solid ${COLORS.cardBorder}`, padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div onClick={() => setActive("perfil")} style={{ cursor: "pointer", flexShrink: 0 }}>
            {perfilData?.foto ? (
              <img src={perfilData.foto} alt="Foto" style={{ width: 36, height: 36, borderRadius: "50%", objectFit: "cover", border: "2px solid #F59E0B" }} />
            ) : (
              <div style={{ width: 36, height: 36, borderRadius: 10, background: COLORS.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🏡</div>
            )}
          </div>
          <div onClick={() => setActive("perfil")} style={{ cursor: "pointer" }}>
            <div style={{ color: COLORS.text, fontWeight: 800, fontSize: 14, lineHeight: 1 }}>
              {nomeCompleto?.split(" ")[0] || "Corretor"}
            </div>
            {creci ? (
              <div style={{ color: COLORS.accent, fontSize: 10, fontWeight: 700 }}>CRECI {creci}</div>
            ) : assinatura?.status === "trial" ? (
              <div style={{ color: COLORS.accent, fontSize: 10, fontWeight: 600 }}>⏳ TRIAL GRATUITO</div>
            ) : (
              <div style={{ color: COLORS.green, fontSize: 10, fontWeight: 600 }}>✅ PRO ATIVO</div>
            )}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={() => { localStorage.removeItem("waPref"); setWaPref(null); }} style={{ background: COLORS.surface, border: "none", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 15 }} title={waPref === "business" ? "WhatsApp Business ativo — clique para trocar" : waPref === "normal" ? "WhatsApp Pessoal ativo — clique para trocar" : "Escolher WhatsApp"}>
            {waPref === "business" ? "💼" : waPref === "normal" ? "📱" : "💬"}
          </button>
          {/* 🔔 Botão Central de Notificações */}
          <BotaoNotificacoes
            naoLidas={notif.naoLidas}
            onClick={() => { notif.setShowCentral(true); notif.marcarTodasLidas(); }}
          />
          {onSair && (
            <button onClick={onSair} style={{ background: COLORS.surface, border: "none", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 15 }} title="Sair">🚪</button>
          )}
        </div>
      </div>
      <div style={{ padding: "20px 16px" }}>{pages[active]}</div>

      {/* Banner de notificação — correspondente atualizou processo */}
      {notifProcesso && (
        <div style={{ position: "fixed", top: 64, left: "50%", transform: "translateX(-50%)", width: "calc(100% - 32px)", maxWidth: 398, zIndex: 300, boxSizing: "border-box" }}>
          <div style={{ background: "#0F172A", border: "2px solid #F59E0B", borderRadius: 16, padding: "14px 16px", display: "flex", alignItems: "flex-start", gap: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.7)" }}>
            <div style={{ fontSize: 28, flexShrink: 0 }}>🏦</div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "#F59E0B", fontWeight: 800, fontSize: 13, marginBottom: 2 }}>📋 Correspondente atualizou o processo!</div>
              <div style={{ color: "#F1F5F9", fontWeight: 700, fontSize: 14 }}>{notifProcesso.cliente}</div>
              <div style={{ color: "#64748B", fontSize: 12 }}>{notifProcesso.banco}</div>
            </div>
            <button onClick={() => setNotifProcesso(null)} style={{ background: "transparent", border: "none", color: "#64748B", cursor: "pointer", fontSize: 18, padding: 0, flexShrink: 0 }}>×</button>
          </div>
        </div>
      )}

      {/* Banner de notificação — novo lead chegou! */}
      {notifLead && (
        <div style={{ position: "fixed", top: notifProcesso ? 140 : 64, left: "50%", transform: "translateX(-50%)", width: "calc(100% - 32px)", maxWidth: 398, zIndex: 299, boxSizing: "border-box" }}>
          <div style={{ background: "#0F172A", border: "2px solid #10B981", borderRadius: 16, padding: "14px 16px", display: "flex", alignItems: "flex-start", gap: 12, boxShadow: "0 8px 32px rgba(0,0,0,0.7)" }}>
            <div style={{ fontSize: 28, flexShrink: 0 }}>💰</div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "#10B981", fontWeight: 800, fontSize: 13, marginBottom: 2 }}>🎯 Novo lead chegou!</div>
              <div style={{ color: "#F1F5F9", fontWeight: 700, fontSize: 14 }}>{notifLead.nome}</div>
              {notifLead.origem ? <div style={{ color: "#64748B", fontSize: 12 }}>{notifLead.origem}</div> : null}
            </div>
            <button onClick={() => setNotifLead(null)} style={{ background: "transparent", border: "none", color: "#64748B", cursor: "pointer", fontSize: 18, padding: 0, flexShrink: 0 }}>×</button>
          </div>
        </div>
      )}

      {/* Banner de instalação PWA */}
      {showInstall && (
        <div style={{ position: "fixed", bottom: 64, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, zIndex: 200, padding: "0 16px", boxSizing: "border-box" }}>
          <div style={{ background: "#1E293B", border: "1px solid #F59E0B", borderRadius: 16, padding: "12px 16px", display: "flex", alignItems: "center", gap: 12, boxShadow: "0 4px 24px rgba(0,0,0,0.6)" }}>
            <div style={{ fontSize: 28 }}>📲</div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "#F1F5F9", fontWeight: 700, fontSize: 13 }}>Instalar ImóvelPro</div>
              <div style={{ color: "#64748B", fontSize: 11 }}>Adicione à tela inicial</div>
            </div>
            <button onClick={() => setShowInstall(false)} style={{ background: "transparent", border: "none", color: "#64748B", fontSize: 18, cursor: "pointer" }}>✕</button>
            <button onClick={instalarApp} style={{ background: "#F59E0B", border: "none", borderRadius: 10, padding: "8px 12px", color: "#000", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>Instalar</button>
          </div>
        </div>
      )}

      {/* ── 🔔 SISTEMA DE NOTIFICAÇÕES v9 ── */}

      {/* Toasts flutuantes */}
      <ToastContainer toasts={notif.toasts} onDismiss={notif.dismissToast} />

      {/* Central de notificações (painel lateral) */}
      {notif.showCentral && (
        <CentralNotificacoes
          historico={notif.historico}
          naoLidas={notif.naoLidas}
          onClose={() => notif.setShowCentral(false)}
          onMarcarLidas={notif.marcarTodasLidas}
          onNav={setActive}
          permissao={notif.permissao}
          solicitarPermissao={async () => {
            await notif.solicitarPermissao();
            setShowBannerPush(false);
          }}
        />
      )}

      {/* Banner de permissão push (aparece 1x por sessão) */}
      {showBannerPush && !showInstall && (
        <BannerPermissaoPush
          permissao={notif.permissao}
          onSolicitar={async () => {
            await notif.solicitarPermissao();
            setShowBannerPush(false);
          }}
          onDismiss={() => setShowBannerPush(false)}
        />
      )}

      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: COLORS.card, borderTop: `1px solid ${COLORS.cardBorder}`, zIndex: 100 }}>
        <div style={{ display: "flex", overflowX: "auto", padding: "6px 4px 8px", scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}>
          {NAV_ITEMS.map(item => (
            <button key={item.id} onClick={() => setActive(item.id)} style={{
              background: active === item.id ? "rgba(245,158,11,0.1)" : "none",
              border: "none", borderRadius: 10, cursor: "pointer",
              display: "flex", flexDirection: "column", alignItems: "center",
              gap: 4, flexShrink: 0, minWidth: 58, padding: "6px 4px",
              transition: "background 0.15s",
            }}>
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              <span style={{
                color: active === item.id ? COLORS.accent : COLORS.muted,
                fontSize: 10, fontWeight: active === item.id ? 700 : 500,
                whiteSpace: "nowrap",
              }}>{item.label}</span>
              {active === item.id && (
                <div style={{ width: 20, height: 2, borderRadius: 1, background: COLORS.accent, marginTop: -2 }} />
              )}
            </button>
          ))}
        </div>
        <style>{`div::-webkit-scrollbar { display: none; }`}</style>
      </div>
    </div>
  );
}
