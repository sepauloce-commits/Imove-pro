import { useState, useEffect, useRef } from "react";
import { db, auth } from "./firebase";
import WhatsAppLeads from "./WhatsAppLeads";
import { abrirWhatsApp } from "./sons";
import {
  collection, addDoc, updateDoc, deleteDoc,
  doc, onSnapshot, serverTimestamp, query, where
} from "firebase/firestore";

// ── Som de dinheiro — novo lead no Pipeline ──
function tocarSomDinheiro() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();

    const nota = (freq, start, dur, gain = 0.35, tipo = "sine") => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = tipo;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      g.gain.setValueAtTime(0, ctx.currentTime + start);
      g.gain.linearRampToValueAtTime(gain, ctx.currentTime + start + 0.01);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.05);
    };

    // Som de caixa registradora / dinheiro entrando
    // "Ca-ching!" — nota grave + cling metálico agudo
    nota(180,  0,    0.15, 0.5,  "triangle"); // batida grave (caixa)
    nota(1200, 0.05, 0.08, 0.4,  "square");   // cling agudo
    nota(1600, 0.10, 0.06, 0.3,  "square");   // harmônico
    nota(900,  0.18, 0.25, 0.25, "sine");     // ressonância final
    nota(1100, 0.20, 0.20, 0.2,  "sine");
  } catch (e) {
    // fallback silencioso
  }
}

const COLORS = {
  bg: "#0A0E1A", card: "#111827", cardBorder: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B", orange: "#F97316",
};

const ETAPAS_FUNIL = [
  { id: "lead", label: "Lead", icon: "🎯", color: "#3B82F6" },
  { id: "contato", label: "Contato", icon: "📞", color: "#8B5CF6" },
  { id: "visita", label: "Visita", icon: "🏠", color: "#F97316" },
  { id: "proposta", label: "Proposta", icon: "📋", color: "#F59E0B" },
  { id: "fechado", label: "Fechado", icon: "🏆", color: "#10B981" },
  { id: "perdido", label: "Perdido", icon: "❌", color: "#EF4444" },
];

const TAGS = [
  { id: "quente", label: "🔥 Quente", color: "#EF4444" },
  { id: "morno", label: "🌡️ Morno", color: "#F97316" },
  { id: "frio", label: "❄️ Frio", color: "#3B82F6" },
  { id: "urgente", label: "⚡ Urgente", color: "#F59E0B" },
  { id: "vip", label: "⭐ VIP", color: "#8B5CF6" },
];

function Card({ children, style = {} }) {
  return <div style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 16, padding: 20, ...style }}>{children}</div>;
}

function Input({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14, boxSizing: "border-box", outline: "none" }} />
    </div>
  );
}

function Sel({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
        {options.map(o => typeof o === "string" ? <option key={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, color = "accent", size = "md", full = false, style = {} }) {
  const bg = { accent: COLORS.accent, green: COLORS.green, red: COLORS.red, blue: COLORS.blue, surface: COLORS.surface, purple: COLORS.purple, orange: COLORS.orange };
  const tc = { accent: "#0A0E1A", green: "#fff", red: "#fff", blue: "#fff", surface: COLORS.text, purple: "#fff", orange: "#fff" };
  return (
    <button onClick={onClick} style={{ background: bg[color] || COLORS.accent, color: tc[color] || "#fff", border: "none", borderRadius: 10, padding: size === "sm" ? "6px 12px" : "11px 22px", fontSize: size === "sm" ? 12 : 14, fontWeight: 700, cursor: "pointer", width: full ? "100%" : "auto", ...style }}>
      {children}
    </button>
  );
}

function Badge({ color, children }) {
  const colors = { green: { bg: "#064E3B", text: "#6EE7B7" }, red: { bg: "#7F1D1D", text: "#FCA5A5" }, yellow: { bg: "#78350F", text: "#FCD34D" }, blue: { bg: "#1E3A8A", text: "#93C5FD" }, purple: { bg: "#4C1D95", text: "#C4B5FD" }, orange: { bg: "#7C2D12", text: "#FED7AA" } };
  const c = colors[color] || colors.blue;
  return <span style={{ background: c.bg, color: c.text, padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{children}</span>;
}

// ─── PIPELINE ───
function Pipeline({ negócios, setNegócios, uid }) {
  const [view, setView] = useState("board");
  const [saving, setSaving] = useState(false);
  const [sel, setSel] = useState(null);
  const empty = { nome: "", telefone: "", interesse: "", valorEstimado: "", etapa: "lead", tags: [], origem: "Instagram", observacoes: "" };
  const [form, setForm] = useState(empty);
  const [editId, setEditId] = useState(null);

  const salvar = async () => {
    if (!form.nome.trim()) return alert("Digite o nome do lead");
    setSaving(true);
    try {
      if (editId) {
        await updateDoc(doc(db, "negocios", editId), { ...form, valorEstimado: Number(form.valorEstimado) || 0, updatedAt: serverTimestamp() });
      } else {
        await addDoc(collection(db, "negocios"), { ...form, valorEstimado: Number(form.valorEstimado) || 0, uid, createdAt: serverTimestamp(), ultimoContato: serverTimestamp() });
      }
      setView("board"); setForm(empty); setEditId(null);
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const moverEtapa = async (negocio, novaEtapa) => {
    await updateDoc(doc(db, "negocios", negocio.id), { etapa: novaEtapa, updatedAt: serverTimestamp() });
  };

  const excluir = async (id) => {
    if (!window.confirm("Excluir este negócio?")) return;
    await deleteDoc(doc(db, "negocios", id));
    setSel(null); setView("board");
  };

  const toggleTag = (tag) => {
    const tags = form.tags || [];
    setForm({ ...form, tags: tags.includes(tag) ? tags.filter(t => t !== tag) : [...tags, tag] });
  };

  const getTag = (tagId) => TAGS.find(t => t.id === tagId);
  const getEtapa = (etapaId) => ETAPAS_FUNIL.find(e => e.id === etapaId);

  const totalPipeline = negócios.filter(n => n.etapa !== "perdido").reduce((a, n) => a + (Number(n.valorEstimado) || 0), 0);

  if (view === "form") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => { setView("board"); setForm(empty); setEditId(null); }}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>{editId ? "✏️ Editar Negócio" : "🎯 Novo Lead"}</h2>
      </div>
      <Card>
        <Input label="Nome do Lead/Cliente" value={form.nome} onChange={v => setForm({ ...form, nome: v })} placeholder="Ex: João Silva" />
        <Input label="Telefone/WhatsApp" value={form.telefone} onChange={v => setForm({ ...form, telefone: v })} placeholder="(85) 99999-0000" />
        <Input label="Interesse (imóvel)" value={form.interesse} onChange={v => setForm({ ...form, interesse: v })} placeholder="Ex: Apto 3 quartos Meireles" />
        <Input label="Valor Estimado (R$)" type="number" value={form.valorEstimado} onChange={v => setForm({ ...form, valorEstimado: v })} placeholder="500000" />
        <Sel label="Etapa do Funil" value={form.etapa} onChange={v => setForm({ ...form, etapa: v })}
          options={ETAPAS_FUNIL.map(e => ({ value: e.id, label: `${e.icon} ${e.label}` }))} />
        <Sel label="Origem do Lead" value={form.origem} onChange={v => setForm({ ...form, origem: v })}
          options={["Instagram", "WhatsApp", "Indicação", "Site", "OLX/ZAP", "Ligação", "Outro"]} />
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 8, fontWeight: 600, textTransform: "uppercase" }}>Tags</label>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {TAGS.map(t => (
              <button key={t.id} onClick={() => toggleTag(t.id)} style={{ background: (form.tags || []).includes(t.id) ? t.color : COLORS.surface, color: (form.tags || []).includes(t.id) ? "#fff" : COLORS.muted, border: "none", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <Input label="Observações" value={form.observacoes} onChange={v => setForm({ ...form, observacoes: v })} placeholder="Anotações sobre o cliente..." />
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : `💾 ${editId ? "Salvar" : "Adicionar Lead"}`}
        </Btn>
        {editId && <Btn full color="red" onClick={() => excluir(editId)} style={{ marginTop: 10 }}>🗑️ Excluir</Btn>}
      </Card>
    </div>
  );

  if (view === "detalhe" && sel) {
    const n = negócios.find(x => x.id === sel.id) || sel;
    const etapa = getEtapa(n.etapa);

    // ── Histórico inline ──
    const [historico, setHistorico] = useState([]);
    const [notaRapida, setNotaRapida] = useState("");
    const [salvandoNota, setSalvandoNota] = useState(false);

    useEffect(() => {
      if (!uid || !n.id) return;
      const q = query(collection(db, "contatos"), where("uid", "==", uid), where("negocioId", "==", n.id));
      const unsub = onSnapshot(q, snap => {
        setHistorico(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0)));
      }, () => {});
      return unsub;
    }, [uid, n.id]);

    const salvarNota = async () => {
      if (!notaRapida.trim()) return;
      setSalvandoNota(true);
      try {
        await addDoc(collection(db, "contatos"), {
          tipo: "Nota", nota: notaRapida, negocioId: n.id,
          nomeCliente: n.nome, uid,
          data: new Date().toISOString().split("T")[0],
          createdAt: serverTimestamp(),
        });
        await updateDoc(doc(db, "negocios", n.id), { ultimoContato: serverTimestamp() });
        setNotaRapida("");
      } catch (e) { alert("Erro: " + e.message); }
      setSalvandoNota(false);
    };

    const tipoIconH = { WhatsApp: "💬", Ligação: "📞", Visita: "🏠", Email: "📧", Reunião: "🤝", Nota: "📝", Outro: "📋" };
    return (
      <div>
        <Btn color="surface" size="sm" onClick={() => { setSel(null); setView("board"); }} style={{ marginBottom: 16 }}>← Voltar</Btn>
        <Card style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
            <div>
              <div style={{ color: COLORS.text, fontWeight: 800, fontSize: 18 }}>{n.nome}</div>
              <div style={{ color: COLORS.muted, fontSize: 13 }}>{n.telefone}</div>
              <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 4 }}>📍 {n.interesse}</div>
            </div>
            <div style={{ background: etapa?.color + "22", color: etapa?.color, padding: "6px 14px", borderRadius: 20, fontSize: 13, fontWeight: 700 }}>
              {etapa?.icon} {etapa?.label}
            </div>
          </div>
          {(n.tags || []).length > 0 && (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
              {(n.tags || []).map(t => { const tag = getTag(t); return tag ? <span key={t} style={{ background: tag.color + "22", color: tag.color, padding: "4px 12px", borderRadius: 20, fontSize: 11, fontWeight: 700 }}>{tag.label}</span> : null; })}
            </div>
          )}
          {n.valorEstimado > 0 && (
            <div style={{ color: COLORS.accent, fontSize: 18, fontWeight: 800, marginBottom: 14 }}>
              💰 R$ {Number(n.valorEstimado).toLocaleString("pt-BR")}
            </div>
          )}
          {[["📡 Origem", n.origem], ["📝 Observações", n.observacoes]].filter(([, v]) => v).map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
              <span style={{ color: COLORS.muted, fontSize: 13 }}>{k}</span>
              <span style={{ color: COLORS.text, fontSize: 13, fontWeight: 600, maxWidth: "60%", textAlign: "right" }}>{v}</span>
            </div>
          ))}
        </Card>

        {/* Mover etapa */}
        <Card style={{ marginBottom: 12 }}>
          <h3 style={{ color: COLORS.text, margin: "0 0 14px", fontSize: 14, fontWeight: 700 }}>🔄 Mover para Etapa</h3>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {ETAPAS_FUNIL.map(e => (
              <button key={e.id} onClick={() => moverEtapa(n, e.id)} style={{ background: n.etapa === e.id ? e.color : COLORS.surface, color: n.etapa === e.id ? "#fff" : COLORS.muted, border: "none", borderRadius: 10, padding: "8px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
                {e.icon} {e.label}
              </button>
            ))}
          </div>
        </Card>

        {/* ── Histórico inline ── */}
        <Card style={{ marginBottom: 12 }}>
          <h3 style={{ color: COLORS.text, margin: "0 0 12px", fontSize: 14, fontWeight: 700 }}>📋 Histórico de Interações</h3>
          {/* Campo nota rápida */}
          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            <input
              value={notaRapida}
              onChange={e => setNotaRapida(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && notaRapida.trim()) salvarNota(); }}
              placeholder="Registrar nota rápida... (Enter para salvar)"
              style={{ flex: 1, background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "9px 13px", color: COLORS.text, fontSize: 13, outline: "none" }}
            />
            <button onClick={salvarNota} disabled={salvandoNota || !notaRapida.trim()} style={{ background: COLORS.accent, border: "none", borderRadius: 10, padding: "0 14px", color: "#0A0E1A", fontWeight: 800, fontSize: 14, cursor: "pointer", opacity: (!notaRapida.trim() || salvandoNota) ? 0.5 : 1 }}>+</button>
          </div>
          {historico.length === 0 ? (
            <div style={{ color: COLORS.muted, fontSize: 13, textAlign: "center", padding: "12px 0" }}>Nenhuma interação registrada ainda.</div>
          ) : historico.slice(0, 8).map(h => (
            <div key={h.id} style={{ display: "flex", gap: 10, padding: "8px 0", borderTop: `1px solid ${COLORS.cardBorder}`, alignItems: "flex-start" }}>
              <span style={{ fontSize: 16, flexShrink: 0, marginTop: 1 }}>{tipoIconH[h.tipo] || "📋"}</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 }}>
                  <span style={{ color: COLORS.muted, fontSize: 11, fontWeight: 700 }}>{h.tipo}</span>
                  <span style={{ color: COLORS.muted, fontSize: 11 }}>{h.data}</span>
                </div>
                <div style={{ color: COLORS.text, fontSize: 13, lineHeight: 1.4 }}>{h.nota}</div>
              </div>
            </div>
          ))}
          {historico.length > 8 && (
            <div style={{ color: COLORS.muted, fontSize: 12, textAlign: "center", paddingTop: 8 }}>
              + {historico.length - 8} interações anteriores — veja em Histórico
            </div>
          )}
        </Card>

        <div style={{ display: "flex", gap: 8 }}>
          <Btn full color="green" onClick={() => abrirWhatsApp(`https://wa.me/55${(n.telefone || "").replace(/\D/g, "")}`)}>💬 WhatsApp</Btn>
          <Btn full color="blue" onClick={() => { setForm({ nome: n.nome, telefone: n.telefone, interesse: n.interesse, valorEstimado: String(n.valorEstimado || ""), etapa: n.etapa, tags: n.tags || [], origem: n.origem || "Outro", observacoes: n.observacoes || "" }); setEditId(n.id); setView("form"); }}>✏️ Editar</Btn>
        </div>
      </div>
    );
  }

  // Board view
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <div>
          <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>🎯 Pipeline</h2>
          <div style={{ color: COLORS.accent, fontSize: 12, fontWeight: 600, marginTop: 2 }}>
            💰 R$ {totalPipeline.toLocaleString("pt-BR")} em negócios
          </div>
        </div>
        <Btn size="sm" onClick={() => { setForm(empty); setEditId(null); setView("form"); }}>+ Lead</Btn>
      </div>

      {ETAPAS_FUNIL.map(etapa => {
        const items = negócios.filter(n => n.etapa === etapa.id);
        return (
          <div key={etapa.id} style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: "50%", background: etapa.color }} />
                <span style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>{etapa.icon} {etapa.label}</span>
                <span style={{ background: COLORS.surface, color: COLORS.muted, borderRadius: 20, padding: "2px 10px", fontSize: 11, fontWeight: 700 }}>{items.length}</span>
              </div>
              {items.length > 0 && (
                <span style={{ color: COLORS.muted, fontSize: 11 }}>
                  R$ {items.reduce((a, n) => a + (Number(n.valorEstimado) || 0), 0).toLocaleString("pt-BR")}
                </span>
              )}
            </div>
            {items.length === 0 ? (
              <div style={{ background: COLORS.surface, borderRadius: 12, padding: "14px", textAlign: "center", color: COLORS.muted, fontSize: 12, border: `1px dashed ${COLORS.cardBorder}` }}>
                Nenhum lead nesta etapa
              </div>
            ) : (
              items.map(n => (
                <div key={n.id} onClick={() => { setSel(n); setView("detalhe"); }} style={{ background: COLORS.card, border: `1px solid ${COLORS.cardBorder}`, borderLeft: `3px solid ${etapa.color}`, borderRadius: 12, padding: "12px 14px", marginBottom: 8, cursor: "pointer", transition: "all 0.2s" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 14 }}>{n.nome}</div>
                      <div style={{ color: COLORS.muted, fontSize: 12 }}>{n.interesse}</div>
                      {(n.tags || []).length > 0 && (
                        <div style={{ display: "flex", gap: 4, marginTop: 6, flexWrap: "wrap" }}>
                          {(n.tags || []).map(t => { const tag = getTag(t); return tag ? <span key={t} style={{ background: tag.color + "22", color: tag.color, padding: "2px 8px", borderRadius: 20, fontSize: 10, fontWeight: 700 }}>{tag.label}</span> : null; })}
                        </div>
                      )}
                    </div>
                    {n.valorEstimado > 0 && (
                      <div style={{ color: COLORS.accent, fontSize: 13, fontWeight: 700, flexShrink: 0, marginLeft: 8 }}>
                        R$ {Number(n.valorEstimado).toLocaleString("pt-BR")}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── HISTÓRICO DE CONTATOS ───
function Historico({ negócios, uid }) {
  const [contatos, setContatos] = useState([]);
  const [view, setView] = useState("list");
  const [saving, setSaving] = useState(false);
  const empty = { tipo: "WhatsApp", negocioId: "", nota: "", data: new Date().toISOString().split("T")[0] };
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "contatos"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => setContatos(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)))), () => {});
    return unsub;
  }, [uid]);

  const salvar = async () => {
    if (!form.nota.trim()) return alert("Digite uma anotação");
    setSaving(true);
    try {
      const negocio = negócios.find(n => n.id === form.negocioId);
      await addDoc(collection(db, "contatos"), { ...form, nomeCliente: negocio?.nome || "", uid, createdAt: serverTimestamp() });
      if (form.negocioId) {
        await updateDoc(doc(db, "negocios", form.negocioId), { ultimoContato: serverTimestamp() });
      }
      setForm(empty); setView("list");
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const tipoIcon = { WhatsApp: "💬", Ligação: "📞", Visita: "🏠", Email: "📧", Reunião: "🤝", Outro: "📝" };
  const tipoCor = { WhatsApp: "green", Ligação: "blue", Visita: "orange", Email: "purple", Reunião: "accent", Outro: "surface" };

  if (view === "form") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>📞 Registrar Contato</h2>
      </div>
      <Card>
        <Sel label="Tipo de Contato" value={form.tipo} onChange={v => setForm({ ...form, tipo: v })}
          options={["WhatsApp", "Ligação", "Visita", "Email", "Reunião", "Outro"]} />
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Lead/Cliente</label>
          <select value={form.negocioId} onChange={e => setForm({ ...form, negocioId: e.target.value })}
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
            <option value="">— Selecione (opcional) —</option>
            {negócios.map(n => <option key={n.id} value={n.id}>{n.nome}</option>)}
          </select>
        </div>
        <Input label="Data" type="date" value={form.data} onChange={v => setForm({ ...form, data: v })} />
        <Input label="Anotação / O que foi discutido" value={form.nota} onChange={v => setForm({ ...form, nota: v })} placeholder="Ex: Cliente tem interesse, vai visitar sábado..." />
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : "💾 Registrar Contato"}
        </Btn>
      </Card>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>📞 Histórico</h2>
        <Btn size="sm" onClick={() => setView("form")}>+ Registrar</Btn>
      </div>
      {contatos.length === 0 ? (
        <Card><p style={{ color: COLORS.muted, textAlign: "center", margin: 0 }}>Nenhum contato registrado ainda.</p></Card>
      ) : contatos.map(c => (
        <Card key={c.id} style={{ marginBottom: 10 }}>
          <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <div style={{ fontSize: 24, flexShrink: 0 }}>{tipoIcon[c.tipo] || "📝"}</div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <Badge color={tipoCor[c.tipo] || "blue"}>{c.tipo}</Badge>
                <span style={{ color: COLORS.muted, fontSize: 11 }}>{c.data}</span>
              </div>
              {c.nomeCliente && <div style={{ color: COLORS.accent, fontSize: 12, fontWeight: 600, marginBottom: 4 }}>👤 {c.nomeCliente}</div>}
              <div style={{ color: COLORS.text, fontSize: 13, lineHeight: 1.5 }}>{c.nota}</div>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ─── TAREFAS E FOLLOW-UP ───
function Tarefas({ negócios, uid }) {
  const [tarefas, setTarefas] = useState([]);
  const [view, setView] = useState("list");
  const [saving, setSaving] = useState(false);
  const [filtro, setFiltro] = useState("pendente");
  const empty = { titulo: "", negocioId: "", prazo: "", prioridade: "Normal", status: "pendente", tipo: "Follow-up" };
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "tarefas"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => setTarefas(snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)))), () => {});
    return unsub;
  }, [uid]);

  const salvar = async () => {
    if (!form.titulo.trim()) return alert("Digite o título da tarefa");
    setSaving(true);
    try {
      await addDoc(collection(db, "tarefas"), { ...form, uid, createdAt: serverTimestamp() });
      setForm(empty); setView("list");
    } catch (e) { alert("Erro: " + e.message); }
    setSaving(false);
  };

  const concluir = async (id) => {
    await updateDoc(doc(db, "tarefas", id), { status: "concluida", updatedAt: serverTimestamp() });
  };

  const excluir = async (id) => {
    await deleteDoc(doc(db, "tarefas", id));
  };

  const hoje = new Date().toISOString().split("T")[0];
  const filtradas = tarefas.filter(t => {
    if (filtro === "pendente") return t.status === "pendente";
    if (filtro === "hoje") return t.status === "pendente" && t.prazo === hoje;
    if (filtro === "atrasada") return t.status === "pendente" && t.prazo && t.prazo < hoje;
    if (filtro === "concluida") return t.status === "concluida";
    return true;
  });

  const prioridadeCor = { Alta: COLORS.red, Normal: COLORS.accent, Baixa: COLORS.muted };
  const tipoIcon = { "Follow-up": "📞", "Visita": "🏠", "Proposta": "📋", "Documentação": "📄", "Outro": "📝" };

  const vencidas = tarefas.filter(t => t.status === "pendente" && t.prazo && t.prazo < hoje).length;
  const hoje_count = tarefas.filter(t => t.status === "pendente" && t.prazo === hoje).length;

  if (view === "form") return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <Btn color="surface" size="sm" onClick={() => setView("list")}>← Voltar</Btn>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 18, fontWeight: 800 }}>📋 Nova Tarefa</h2>
      </div>
      <Card>
        <Input label="Título da Tarefa" value={form.titulo} onChange={v => setForm({ ...form, titulo: v })} placeholder="Ex: Ligar para João amanhã" />
        <Sel label="Tipo" value={form.tipo} onChange={v => setForm({ ...form, tipo: v })}
          options={["Follow-up", "Visita", "Proposta", "Documentação", "Outro"]} />
        <div style={{ marginBottom: 14 }}>
          <label style={{ display: "block", color: COLORS.muted, fontSize: 12, marginBottom: 5, fontWeight: 600, textTransform: "uppercase" }}>Lead/Cliente</label>
          <select value={form.negocioId} onChange={e => setForm({ ...form, negocioId: e.target.value })}
            style={{ width: "100%", background: COLORS.surface, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "10px 14px", color: COLORS.text, fontSize: 14 }}>
            <option value="">— Selecione (opcional) —</option>
            {negócios.map(n => <option key={n.id} value={n.id}>{n.nome}</option>)}
          </select>
        </div>
        <Input label="Prazo" type="date" value={form.prazo} onChange={v => setForm({ ...form, prazo: v })} />
        <Sel label="Prioridade" value={form.prioridade} onChange={v => setForm({ ...form, prioridade: v })}
          options={["Alta", "Normal", "Baixa"]} />
        <Btn full color="accent" onClick={salvar} style={{ opacity: saving ? 0.7 : 1 }}>
          {saving ? "⏳ Salvando..." : "💾 Criar Tarefa"}
        </Btn>
      </Card>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <h2 style={{ color: COLORS.text, margin: 0, fontSize: 20, fontWeight: 800 }}>📋 Tarefas</h2>
        <Btn size="sm" onClick={() => setView("form")}>+ Nova</Btn>
      </div>

      {(vencidas > 0 || hoje_count > 0) && (
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          {vencidas > 0 && <div style={{ background: "#7F1D1D", color: "#FCA5A5", borderRadius: 12, padding: "8px 14px", fontSize: 12, fontWeight: 700, flex: 1, textAlign: "center" }}>⚠️ {vencidas} atrasada{vencidas > 1 ? "s" : ""}</div>}
          {hoje_count > 0 && <div style={{ background: "#78350F", color: "#FCD34D", borderRadius: 12, padding: "8px 14px", fontSize: 12, fontWeight: 700, flex: 1, textAlign: "center" }}>📅 {hoje_count} para hoje</div>}
        </div>
      )}

      <div style={{ display: "flex", gap: 8, marginBottom: 16, overflowX: "auto" }}>
        {[["pendente", "Pendentes"], ["hoje", "Hoje"], ["atrasada", "Atrasadas"], ["concluida", "Concluídas"]].map(([id, label]) => (
          <button key={id} onClick={() => setFiltro(id)} style={{ background: filtro === id ? COLORS.accent : COLORS.surface, color: filtro === id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 20, padding: "6px 14px", fontSize: 12, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" }}>{label}</button>
        ))}
      </div>

      {filtradas.length === 0 ? (
        <Card><p style={{ color: COLORS.muted, textAlign: "center", margin: 0 }}>Nenhuma tarefa aqui.</p></Card>
      ) : filtradas.map(t => {
        const negocio = negócios.find(n => n.id === t.negocioId);
        const atrasada = t.status === "pendente" && t.prazo && t.prazo < hoje;
        return (
          <Card key={t.id} style={{ marginBottom: 10, opacity: t.status === "concluida" ? 0.6 : 1, borderLeft: `3px solid ${atrasada ? COLORS.red : prioridadeCor[t.prioridade] || COLORS.accent}` }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div style={{ fontSize: 20, flexShrink: 0 }}>{tipoIcon[t.tipo] || "📝"}</div>
              <div style={{ flex: 1 }}>
                <div style={{ color: t.status === "concluida" ? COLORS.muted : COLORS.text, fontWeight: 700, fontSize: 14, textDecoration: t.status === "concluida" ? "line-through" : "none" }}>{t.titulo}</div>
                {negocio && <div style={{ color: COLORS.accent, fontSize: 12, marginTop: 2 }}>👤 {negocio.nome}</div>}
                <div style={{ display: "flex", gap: 8, marginTop: 6, alignItems: "center" }}>
                  {t.prazo && <span style={{ color: atrasada ? COLORS.red : COLORS.muted, fontSize: 11, fontWeight: atrasada ? 700 : 400 }}>{atrasada ? "⚠️ " : "📅 "}{t.prazo}</span>}
                  <span style={{ color: prioridadeCor[t.prioridade], fontSize: 11, fontWeight: 700 }}>{t.prioridade}</span>
                </div>
              </div>
              <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
                {t.status === "pendente" && <Btn size="sm" color="green" onClick={() => concluir(t.id)}>✓</Btn>}
                <Btn size="sm" color="red" onClick={() => excluir(t.id)}>×</Btn>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}

// ─── ALERTAS DE LEADS ───
function diasDesde(ts) {
  if (!ts) return null;
  const secs = ts?.seconds ?? ts;
  return Math.floor((Date.now() / 1000 - secs) / 86400);
}

function AlertasLeads({ negócios, uid }) {
  const [tarefasCRM, setTarefasCRM] = useState([]);
  const [dismissed, setDismissed] = useState(() => {
    try { return JSON.parse(localStorage.getItem("crm_alertas_dismissed") || "[]"); } catch { return []; }
  });

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "tarefas"), where("uid", "==", uid));
    const unsub = onSnapshot(q, s => setTarefasCRM(s.docs.map(d => ({ id: d.id, ...d.data() }))), () => {});
    return unsub;
  }, [uid]);

  const dispensar = (id) => {
    const novos = [...dismissed, id];
    setDismissed(novos);
    try { localStorage.setItem("crm_alertas_dismissed", JSON.stringify(novos)); } catch {}
  };

  const hoje = new Date().toISOString().split("T")[0];
  const ativos = negócios.filter(n => n.etapa !== "fechado" && n.etapa !== "perdido");

  const alertas = [];

  // Follow-ups vencidos hoje
  const fuHoje = tarefasCRM.filter(t => t.status === "pendente" && t.prazo === hoje);
  fuHoje.forEach(t => {
    const neg = negócios.find(n => n.id === t.negocioId);
    alertas.push({ id: `fu-hoje-${t.id}`, nivel: "urgente", icone: "📞", titulo: "Follow-up para HOJE", desc: `${t.titulo}${neg ? ` · ${neg.nome}` : ""}`, tipo: t.tipo || "Follow-up" });
  });

  // Follow-ups atrasados
  const fuAtrasados = tarefasCRM.filter(t => t.status === "pendente" && t.prazo && t.prazo < hoje);
  fuAtrasados.forEach(t => {
    const neg = negócios.find(n => n.id === t.negocioId);
    const diasAtraso = Math.round((new Date(hoje) - new Date(t.prazo)) / 86400000);
    alertas.push({ id: `fu-atrasado-${t.id}`, nivel: "urgente", icone: "⚠️", titulo: `Follow-up atrasado ${diasAtraso}d`, desc: `${t.titulo}${neg ? ` · ${neg.nome}` : ""}`, tipo: t.tipo || "Follow-up" });
  });

  // Lead VIP/Urgente sem contato
  ativos.filter(n => n.tags?.includes("urgente") || n.tags?.includes("vip")).forEach(n => {
    const dias = diasDesde(n.ultimoContato || n.createdAt);
    if (dias >= 1)
      alertas.push({ id: `vip-${n.id}`, nivel: "urgente", icone: n.tags?.includes("vip") ? "⭐" : "⚡", titulo: n.tags?.includes("vip") ? "Lead VIP sem retorno" : "Lead Urgente esperando", desc: `${n.nome} — ${dias}d sem contato · ${n.interesse || ""}`, telefone: n.telefone });
  });

  // Lead alto valor parado
  ativos.filter(n => (Number(n.valorEstimado) || 0) >= 500000 && (n.etapa === "lead" || n.etapa === "contato")).forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 2)
      alertas.push({ id: `rico-${n.id}`, nivel: "urgente", icone: "💰", titulo: "Negócio alto valor parado", desc: `${n.nome} · R$ ${Number(n.valorEstimado).toLocaleString("pt-BR")} · ${dias}d`, telefone: n.telefone });
  });

  // Leads quentes esfriando (3+ dias)
  ativos.filter(n => n.tags?.includes("quente") && !n.tags?.includes("urgente") && !n.tags?.includes("vip")).forEach(n => {
    const dias = diasDesde(n.ultimoContato || n.updatedAt || n.createdAt);
    if (dias >= 3)
      alertas.push({ id: `quente-${n.id}`, nivel: "atencao", icone: "🔥", titulo: "Lead quente esfriando", desc: `${n.nome} — ${dias}d sem contato · ${n.interesse || ""}`, telefone: n.telefone });
  });

  // Proposta parada (5+ dias)
  ativos.filter(n => n.etapa === "proposta").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 5)
      alertas.push({ id: `prop-${n.id}`, nivel: "atencao", icone: "📋", titulo: "Proposta sem resposta", desc: `${n.nome} — proposta aberta há ${dias} dias`, telefone: n.telefone });
  });

  // Pós-visita sem follow-up (3+ dias)
  ativos.filter(n => n.etapa === "visita").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 3)
      alertas.push({ id: `visita-${n.id}`, nivel: "atencao", icone: "🏠", titulo: "Follow-up pós-visita", desc: `${n.nome} visitou há ${dias} dias — ligue agora!`, telefone: n.telefone });
  });

  // Contato sem avançar (5+ dias)
  ativos.filter(n => n.etapa === "contato").forEach(n => {
    const dias = diasDesde(n.updatedAt || n.createdAt);
    if (dias >= 5)
      alertas.push({ id: `cont-${n.id}`, nivel: "aviso", icone: "📞", titulo: "Funil parado em Contato", desc: `${n.nome} — ${dias}d sem avançar · agende uma visita`, telefone: n.telefone });
  });

  // Lead frio na entrada (7+ dias)
  ativos.filter(n => n.etapa === "lead").forEach(n => {
    const dias = diasDesde(n.createdAt);
    if (dias >= 7)
      alertas.push({ id: `frio-${n.id}`, nivel: "aviso", icone: "❄️", titulo: "Lead sem contato inicial", desc: `${n.nome} — ${dias}d na entrada do funil`, telefone: n.telefone });
  });

  const visiveis = alertas.filter(a => !dismissed.includes(a.id));
  const urgentes = visiveis.filter(a => a.nivel === "urgente");
  const atencao = visiveis.filter(a => a.nivel === "atencao");
  const avisos = visiveis.filter(a => a.nivel === "aviso");

  const COR_NIVEL = {
    urgente: { bg: "rgba(239,68,68,0.10)", border: "#EF4444", label: "URGENTE", tc: "#EF4444" },
    atencao: { bg: "rgba(245,158,11,0.10)", border: "#F59E0B", label: "ATENÇÃO", tc: "#F59E0B" },
    aviso:   { bg: "rgba(59,130,246,0.10)", border: "#3B82F6", label: "AVISO",  tc: "#3B82F6" },
  };

  const renderAlerta = (a) => {
    const c = COR_NIVEL[a.nivel];
    return (
      <div key={a.id} style={{ background: c.bg, border: `1px solid ${c.border}`, borderRadius: 14, padding: "12px 14px", marginBottom: 10, display: "flex", alignItems: "flex-start", gap: 10 }}>
        <span style={{ fontSize: 22, flexShrink: 0 }}>{a.icone}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ color: c.tc, fontSize: 10, fontWeight: 800, textTransform: "uppercase", marginBottom: 2 }}>{c.label}</div>
          <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700, marginBottom: 3 }}>{a.titulo}</div>
          <div style={{ color: COLORS.muted, fontSize: 11, lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.desc}</div>
          {a.telefone && (
            <button
              onClick={() => window.open(`https://wa.me/55${a.telefone.replace(/\D/g, "")}`, "_blank")}
              style={{ marginTop: 8, background: "#25D366", color: "#fff", border: "none", borderRadius: 8, padding: "5px 12px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}
            >💬 WhatsApp</button>
          )}
        </div>
        <button onClick={() => dispensar(a.id)} style={{ background: "transparent", color: COLORS.muted, border: "none", fontSize: 18, cursor: "pointer", flexShrink: 0, padding: "0 2px", lineHeight: 1 }}>✕</button>
      </div>
    );
  };

  if (visiveis.length === 0) return (
    <div>
      <h2 style={{ color: COLORS.text, fontSize: 18, fontWeight: 800, margin: "0 0 20px" }}>🔔 Alertas de Leads</h2>
      <div style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.25)", borderRadius: 16, padding: "32px 20px", textAlign: "center" }}>
        <div style={{ fontSize: 40, marginBottom: 10 }}>✅</div>
        <div style={{ color: "#10B981", fontWeight: 800, fontSize: 15 }}>Nenhum alerta no momento</div>
        <div style={{ color: COLORS.muted, fontSize: 12, marginTop: 6 }}>Todos os seus leads estão em dia. Continue assim!</div>
      </div>
    </div>
  );

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <h2 style={{ color: COLORS.text, fontSize: 18, fontWeight: 800, margin: 0 }}>🔔 Alertas de Leads</h2>
        <div style={{ background: "#7F1D1D", color: "#FCA5A5", borderRadius: 20, padding: "4px 12px", fontSize: 12, fontWeight: 700 }}>
          {visiveis.length} ativo{visiveis.length > 1 ? "s" : ""}
        </div>
      </div>

      {/* Resumo */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {urgentes.length > 0 && <div style={{ flex: 1, background: "rgba(239,68,68,0.12)", border: "1px solid #EF4444", borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
          <div style={{ color: "#EF4444", fontWeight: 900, fontSize: 20 }}>{urgentes.length}</div>
          <div style={{ color: "#FCA5A5", fontSize: 10, fontWeight: 700 }}>URGENTE{urgentes.length > 1 ? "S" : ""}</div>
        </div>}
        {atencao.length > 0 && <div style={{ flex: 1, background: "rgba(245,158,11,0.10)", border: "1px solid #F59E0B", borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
          <div style={{ color: "#F59E0B", fontWeight: 900, fontSize: 20 }}>{atencao.length}</div>
          <div style={{ color: "#FCD34D", fontSize: 10, fontWeight: 700 }}>ATENÇÃO</div>
        </div>}
        {avisos.length > 0 && <div style={{ flex: 1, background: "rgba(59,130,246,0.10)", border: "1px solid #3B82F6", borderRadius: 12, padding: "10px 8px", textAlign: "center" }}>
          <div style={{ color: "#3B82F6", fontWeight: 900, fontSize: 20 }}>{avisos.length}</div>
          <div style={{ color: "#93C5FD", fontSize: 10, fontWeight: 700 }}>AVISO{avisos.length > 1 ? "S" : ""}</div>
        </div>}
      </div>

      {urgentes.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ color: "#EF4444", fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>🔴 Urgentes</div>
          {urgentes.map(renderAlerta)}
        </div>
      )}
      {atencao.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ color: "#F59E0B", fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>🟡 Atenção</div>
          {atencao.map(renderAlerta)}
        </div>
      )}
      {avisos.length > 0 && (
        <div>
          <div style={{ color: "#3B82F6", fontSize: 11, fontWeight: 800, textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>🔵 Avisos</div>
          {avisos.map(renderAlerta)}
        </div>
      )}

      <button onClick={() => { setDismissed([]); try { localStorage.removeItem("crm_alertas_dismissed"); } catch {} }}
        style={{ marginTop: 16, background: "transparent", color: COLORS.muted, border: `1px solid ${COLORS.cardBorder}`, borderRadius: 10, padding: "8px 16px", fontSize: 12, cursor: "pointer", width: "100%" }}>
        🔄 Reexibir alertas dispensados
      </button>
    </div>
  );
}

// ─── RELATÓRIOS ───
function Relatorios({ negócios }) {
  const total = negócios.length;
  const porEtapa = ETAPAS_FUNIL.map(e => ({ ...e, count: negócios.filter(n => n.etapa === e.id).length, valor: negócios.filter(n => n.etapa === e.id).reduce((a, n) => a + (Number(n.valorEstimado) || 0), 0) }));
  const fechados = negócios.filter(n => n.etapa === "fechado").length;
  const perdidos = negócios.filter(n => n.etapa === "perdido").length;
  const conversao = total > 0 ? ((fechados / total) * 100).toFixed(0) : 0;
  const totalPipeline = negócios.filter(n => !["perdido"].includes(n.etapa)).reduce((a, n) => a + (Number(n.valorEstimado) || 0), 0);
  const totalFechado = negócios.filter(n => n.etapa === "fechado").reduce((a, n) => a + (Number(n.valorEstimado) || 0), 0);

  const porOrigem = ["Instagram", "WhatsApp", "Indicação", "Site", "OLX/ZAP", "Ligação", "Outro"].map(o => ({
    origem: o,
    count: negócios.filter(n => n.origem === o).length
  })).filter(o => o.count > 0).sort((a, b) => b.count - a.count);

  const fmt = v => v.toLocaleString("pt-BR", { maximumFractionDigits: 0 });

  return (
    <div>
      <h2 style={{ color: COLORS.text, margin: "0 0 20px", fontSize: 20, fontWeight: 800 }}>📊 Relatórios CRM</h2>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
        {[
          { label: "Total de Leads", value: total, icon: "🎯", color: COLORS.blue },
          { label: "Taxa Conversão", value: `${conversao}%`, icon: "📈", color: COLORS.green },
          { label: "Pipeline Total", value: `R$${fmt(totalPipeline)}`, icon: "💰", color: COLORS.accent },
          { label: "Negócios Fechados", value: `R$${fmt(totalFechado)}`, icon: "🏆", color: COLORS.purple },
        ].map(s => (
          <Card key={s.label} style={{ padding: 16 }}>
            <div style={{ fontSize: 22 }}>{s.icon}</div>
            <div style={{ color: s.color, fontSize: 18, fontWeight: 800, margin: "6px 0 2px", lineHeight: 1 }}>{s.value}</div>
            <div style={{ color: COLORS.muted, fontSize: 11 }}>{s.label}</div>
          </Card>
        ))}
      </div>

      <Card style={{ marginBottom: 16 }}>
        <h3 style={{ color: COLORS.text, margin: "0 0 16px", fontSize: 15, fontWeight: 700 }}>🔄 Funil de Vendas</h3>
        {porEtapa.map(e => (
          <div key={e.id} style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <span style={{ color: COLORS.text, fontSize: 13 }}>{e.icon} {e.label}</span>
              <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                <span style={{ color: COLORS.muted, fontSize: 11 }}>R$ {fmt(e.valor)}</span>
                <span style={{ color: e.color, fontWeight: 700, fontSize: 13 }}>{e.count}</span>
              </div>
            </div>
            <div style={{ background: COLORS.surface, borderRadius: 6, height: 8 }}>
              <div style={{ background: e.color, height: 8, borderRadius: 6, width: total > 0 ? `${(e.count / total) * 100}%` : "0%", transition: "width 0.5s" }} />
            </div>
          </div>
        ))}
      </Card>

      {porOrigem.length > 0 && (
        <Card>
          <h3 style={{ color: COLORS.text, margin: "0 0 16px", fontSize: 15, fontWeight: 700 }}>📡 Origem dos Leads</h3>
          {porOrigem.map(o => (
            <div key={o.origem} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${COLORS.cardBorder}` }}>
              <span style={{ color: COLORS.text, fontSize: 13 }}>{o.origem}</span>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ background: COLORS.surface, borderRadius: 4, height: 6, width: 80 }}>
                  <div style={{ background: COLORS.accent, height: 6, borderRadius: 4, width: `${(o.count / total) * 100}%` }} />
                </div>
                <span style={{ color: COLORS.accent, fontWeight: 700, fontSize: 13, minWidth: 20, textAlign: "right" }}>{o.count}</span>
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

// ─── CRM PRINCIPAL ───
export default function CRM({ uid }) {
  const [aba, setAba] = useState("pipeline");
  const [negócios, setNegócios] = useState([]);
  const negociosIdsRef = useRef(null); // rastreia IDs conhecidos

  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "negocios"), where("uid", "==", uid));
    const unsub = onSnapshot(q, snap => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a,b)=>((b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)));

      // Detectar novos leads no pipeline e tocar som de dinheiro
      const idsAgora = lista.map(n => n.id);
      if (negociosIdsRef.current !== null) {
        const novos = lista.filter(n => !negociosIdsRef.current.includes(n.id));
        if (novos.length > 0) {
          tocarSomDinheiro();
        }
      }
      negociosIdsRef.current = idsAgora;

      setNegócios(lista);
    }, () => {});
    return unsub;
  }, [uid]);

  const abas = [
    { id: "alertas", icon: "🔔", label: "Alertas" },
    { id: "pipeline", icon: "🎯", label: "Pipeline" },
    { id: "whatsapp", icon: "📱", label: "WhatsApp" },
    { id: "historico", icon: "📞", label: "Histórico" },
    { id: "tarefas", icon: "📋", label: "Tarefas" },
    { id: "relatorios", icon: "📊", label: "Relatórios" },
  ];

  return (
    <div>
      {/* Sub-navegação CRM */}
      <div style={{ display: "flex", background: COLORS.surface, borderRadius: 14, padding: 4, marginBottom: 20, gap: 4, overflowX: "auto" }}>
        {abas.map(a => (
          <button key={a.id} onClick={() => setAba(a.id)} style={{ flex: 1, minWidth: 48, padding: "8px 4px", background: aba === a.id ? COLORS.accent : "transparent", color: aba === a.id ? "#0A0E1A" : COLORS.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 11, display: "flex", flexDirection: "column", alignItems: "center", gap: 2, position: "relative" }}>
            <span style={{ fontSize: 16 }}>{a.icon}</span>
            <span>{a.label}</span>
          </button>
        ))}
      </div>

      {aba === "alertas" && <AlertasLeads negócios={negócios} uid={uid} />}
      {aba === "pipeline" && <Pipeline negócios={negócios} setNegócios={setNegócios} uid={uid} />}
      {aba === "whatsapp" && <WhatsAppLeads uid={uid} />}
      {aba === "historico" && <Historico negócios={negócios} uid={uid} />}
      {aba === "tarefas" && <Tarefas negócios={negócios} uid={uid} />}
      {aba === "relatorios" && <Relatorios negócios={negócios} />}
    </div>
  );
}
