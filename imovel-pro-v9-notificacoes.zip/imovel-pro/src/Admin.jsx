import { useState, useEffect } from "react";
import { db } from "./firebase";
import { tocarSomDinheiro } from "./sons";
import {
  collection, onSnapshot, doc, updateDoc, addDoc,
  serverTimestamp, query, orderBy, deleteDoc, setDoc
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth } from "./firebase";

const C = {
  bg: "#0A0E1A", card: "#111827", border: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6",
  text: "#F1F5F9", muted: "#64748B", surface: "#1E293B",
};

const ADMIN_UIDS = ["SEU_UID_ADMIN_AQUI"]; // substitua pelo seu UID do Firebase

function gerarCodigo() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "IMOPRO-";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function fmt(data) {
  if (!data) return "—";
  const d = data?.toDate?.() || new Date(data);
  return d.toLocaleDateString("pt-BR");
}

export default function Admin({ user }) {
  const [aba, setAba] = useState("assinantes");
  const [assinantes, setAssinantes] = useState([]);
  const [codigos, setCodigos] = useState([]);
  const [gerandoCodigo, setGerandoCodigo] = useState(false);
  const [codigoGerado, setCodigoGerado] = useState(null);
  const [modalAlt, setModalAlt] = useState(null);
  const [diasExtra, setDiasExtra] = useState("30");

  useEffect(() => {
    const q1 = query(collection(db, "assinaturas"), orderBy("criadoEm", "desc"));
    const unsub1 = onSnapshot(q1, snap => setAssinantes(snap.docs.map(d => ({ id: d.id, ...d.data() }))));

    const q2 = query(collection(db, "codigos_ativacao"), orderBy("criadoEm", "desc"));
    const unsub2 = onSnapshot(q2, snap => setCodigos(snap.docs.map(d => ({ id: d.id, ...d.data() }))));

    return () => { unsub1(); unsub2(); };
  }, []);

  const ativarManual = async (assinante) => {
    const dias = parseInt(diasExtra) || 30;
    const vencimento = new Date();
    vencimento.setDate(vencimento.getDate() + dias);
    await updateDoc(doc(db, "assinaturas", assinante.id), {
      status: "ativa",
      plano: "mensal",
      vencimento,
      ativadoEm: serverTimestamp(),
      ativadoPor: "admin",
    });
    tocarSomDinheiro(); // 💰 Assinatura ativada pelo admin!
    setModalAlt(null);
  };

  const cancelarAssinatura = async (assinante) => {
    if (!window.confirm(`Cancelar assinatura de ${assinante.nome || assinante.email}?`)) return;
    await updateDoc(doc(db, "assinaturas", assinante.id), {
      status: "cancelada",
      ativa: false,
      canceladoEm: serverTimestamp(),
    });
  };

  const gerarNovoCodigo = async () => {
    setGerandoCodigo(true);
    const codigo = gerarCodigo();
    const vencimento = new Date();
    vencimento.setDate(vencimento.getDate() + 7);
    await setDoc(doc(db, "codigos_ativacao", codigo), {
      codigo,
      usado: false,
      criadoEm: serverTimestamp(),
      criadoPor: user.uid,
      expiraEm: vencimento,
    });
    setCodigoGerado(codigo);
    setGerandoCodigo(false);
  };

  const copiarCodigo = (codigo) => {
    navigator.clipboard.writeText(codigo);
    alert(`Código copiado: ${codigo}`);
  };

  const totalAtivos = assinantes.filter(a => a.status === "ativa").length;
  const totalTrial = assinantes.filter(a => a.status === "trial").length;
  const receitaMensal = totalAtivos * 49;

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "'Segoe UI', system-ui, sans-serif", padding: "20px 16px", maxWidth: 500, margin: "0 auto" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <div style={{ color: C.accent, fontWeight: 900, fontSize: 20 }}>🛡️ Admin</div>
          <div style={{ color: C.muted, fontSize: 12 }}>ImóvelPro — Painel de Gestão</div>
        </div>
        <button onClick={() => signOut(auth)} style={{ background: C.surface, border: "none", borderRadius: 10, padding: "8px 14px", color: C.muted, fontSize: 13, cursor: "pointer" }}>Sair</button>
      </div>

      {/* Cards resumo */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 24 }}>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 14, textAlign: "center" }}>
          <div style={{ color: C.green, fontSize: 22, fontWeight: 900 }}>{totalAtivos}</div>
          <div style={{ color: C.muted, fontSize: 10, fontWeight: 600 }}>ATIVOS</div>
        </div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 14, textAlign: "center" }}>
          <div style={{ color: C.accent, fontSize: 22, fontWeight: 900 }}>{totalTrial}</div>
          <div style={{ color: C.muted, fontSize: 10, fontWeight: 600 }}>TRIAL</div>
        </div>
        <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 14, textAlign: "center" }}>
          <div style={{ color: C.purple, fontSize: 18, fontWeight: 900 }}>R${receitaMensal}</div>
          <div style={{ color: C.muted, fontSize: 10, fontWeight: 600 }}>MRR</div>
        </div>
      </div>

      {/* Abas */}
      <div style={{ display: "flex", background: C.surface, borderRadius: 12, padding: 4, marginBottom: 20 }}>
        {[["assinantes", "👥 Assinantes"], ["codigos", "🔑 Códigos"]].map(([id, label]) => (
          <button key={id} onClick={() => setAba(id)} style={{ flex: 1, padding: "10px", background: aba === id ? C.accent : "transparent", color: aba === id ? "#0A0E1A" : C.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 13 }}>
            {label}
          </button>
        ))}
      </div>

      {/* Assinantes */}
      {aba === "assinantes" && (
        <div>
          {assinantes.length === 0
            ? <div style={{ color: C.muted, textAlign: "center", padding: 40 }}>Nenhum assinante ainda</div>
            : assinantes.map(a => (
              <div key={a.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 14, padding: 16, marginBottom: 12 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                  <div>
                    <div style={{ color: C.text, fontWeight: 700, fontSize: 14 }}>{a.nome || a.email}</div>
                    <div style={{ color: C.muted, fontSize: 12 }}>{a.email}</div>
                  </div>
                  <span style={{
                    background: a.status === "ativa" ? "#064E3B" : a.status === "trial" ? "#422006" : "#3B0000",
                    color: a.status === "ativa" ? C.green : a.status === "trial" ? C.accent : C.red,
                    borderRadius: 8, padding: "4px 10px", fontSize: 11, fontWeight: 700, height: "fit-content"
                  }}>
                    {a.status === "ativa" ? "✅ Ativo" : a.status === "trial" ? "⏳ Trial" : "❌ Inativo"}
                  </span>
                </div>
                <div style={{ color: C.muted, fontSize: 12, marginBottom: 10 }}>
                  Vence: {fmt(a.vencimento)} • Cadastro: {fmt(a.criadoEm)}
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button onClick={() => setModalAlt(a)} style={{ background: "#064E3B", border: "none", borderRadius: 8, padding: "6px 12px", color: C.green, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
                    ✅ Ativar
                  </button>
                  <button onClick={() => cancelarAssinatura(a)} style={{ background: "#3B0000", border: "none", borderRadius: 8, padding: "6px 12px", color: C.red, fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
                    ❌ Cancelar
                  </button>
                </div>
              </div>
            ))
          }
        </div>
      )}

      {/* Códigos */}
      {aba === "codigos" && (
        <div>
          <button onClick={gerarNovoCodigo} disabled={gerandoCodigo} style={{ background: C.accent, border: "none", borderRadius: 12, padding: "14px 24px", color: "#0A0E1A", fontWeight: 800, fontSize: 15, cursor: "pointer", width: "100%", marginBottom: 16 }}>
            {gerandoCodigo ? "Gerando..." : "🔑 Gerar Novo Código"}
          </button>

          {codigoGerado && (
            <div style={{ background: "#064E3B", border: `1px solid ${C.green}`, borderRadius: 14, padding: 16, marginBottom: 16, textAlign: "center" }}>
              <div style={{ color: C.muted, fontSize: 12, marginBottom: 6 }}>Código gerado:</div>
              <div style={{ color: C.green, fontSize: 22, fontWeight: 900, letterSpacing: 2 }}>{codigoGerado}</div>
              <button onClick={() => copiarCodigo(codigoGerado)} style={{ background: C.green, border: "none", borderRadius: 8, padding: "8px 20px", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", marginTop: 12 }}>
                📋 Copiar Código
              </button>
            </div>
          )}

          {codigos.map(c => (
            <div key={c.id} style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 12, padding: 14, marginBottom: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ color: c.usado ? C.muted : C.text, fontWeight: 700, fontSize: 14, letterSpacing: 1 }}>{c.codigo}</div>
                <div style={{ color: C.muted, fontSize: 11, marginTop: 2 }}>Criado: {fmt(c.criadoEm)}</div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span style={{ background: c.usado ? "#3B0000" : "#064E3B", color: c.usado ? C.red : C.green, borderRadius: 8, padding: "4px 10px", fontSize: 11, fontWeight: 700 }}>
                  {c.usado ? "Usado" : "Disponível"}
                </span>
                {!c.usado && (
                  <button onClick={() => copiarCodigo(c.codigo)} style={{ background: C.surface, border: "none", borderRadius: 8, padding: "6px 10px", color: C.text, fontSize: 12, cursor: "pointer" }}>
                    📋
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal ativar */}
      {modalAlt && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: C.card, borderRadius: 20, padding: 24, width: "100%", maxWidth: 360 }}>
            <div style={{ color: C.text, fontWeight: 800, fontSize: 16, marginBottom: 6 }}>Ativar assinatura</div>
            <div style={{ color: C.muted, fontSize: 13, marginBottom: 20 }}>{modalAlt.nome || modalAlt.email}</div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ color: C.muted, fontSize: 12, fontWeight: 600, marginBottom: 8 }}>Quantos dias de acesso?</div>
              <div style={{ display: "flex", gap: 8 }}>
                {["30", "60", "90"].map(d => (
                  <button key={d} onClick={() => setDiasExtra(d)} style={{ flex: 1, padding: "10px 0", background: diasExtra === d ? C.green : C.surface, color: diasExtra === d ? "#fff" : C.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 14 }}>{d}d</button>
                ))}
              </div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setModalAlt(null)} style={{ flex: 1, background: C.surface, border: "none", borderRadius: 12, padding: 14, color: C.text, fontWeight: 700, cursor: "pointer" }}>Cancelar</button>
              <button onClick={() => ativarManual(modalAlt)} style={{ flex: 1, background: C.green, border: "none", borderRadius: 12, padding: 14, color: "#fff", fontWeight: 700, cursor: "pointer" }}>✅ Ativar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
