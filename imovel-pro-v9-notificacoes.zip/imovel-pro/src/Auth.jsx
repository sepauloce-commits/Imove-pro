import { useState } from "react";
import { auth } from "./firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile
} from "firebase/auth";

const C = {
  bg: "#0A0E1A", card: "#111827", border: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  text: "#F1F5F9", muted: "#64748B", surface: "#1E293B",
};

function Input({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: "block", color: C.muted, fontSize: 12, marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</label>
      <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        style={{ width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 16px", color: C.text, fontSize: 15, boxSizing: "border-box", outline: "none" }} />
    </div>
  );
}

function Btn({ children, onClick, color = "accent", full = false, loading = false, style = {} }) {
  const bg = { accent: C.accent, surface: C.surface, green: C.green, red: C.red };
  const tc = { accent: "#0A0E1A", surface: C.text, green: "#fff", red: "#fff" };
  return (
    <button onClick={onClick} disabled={loading} style={{ background: bg[color], color: tc[color], border: "none", borderRadius: 12, padding: "13px 24px", fontSize: 15, fontWeight: 700, cursor: loading ? "not-allowed" : "pointer", width: full ? "100%" : "auto", opacity: loading ? 0.7 : 1, ...style }}>
      {loading ? "⏳ Aguarde..." : children}
    </button>
  );
}

export default function Auth() {
  const [tela, setTela] = useState("login"); // login | cadastro | recuperar
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirma, setConfirma] = useState("");
  const [creci, setCreci] = useState("");
  const [tel, setTel] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState({ tipo: "", texto: "" });

  const mostrarMsg = (tipo, texto) => { setMsg({ tipo, texto }); setTimeout(() => setMsg({ tipo: "", texto: "" }), 4000); };

  const login = async () => {
    if (!email || !senha) return mostrarMsg("erro", "Preencha e-mail e senha");
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email.trim(), senha);
    } catch (e) {
      const erros = { "auth/user-not-found": "E-mail não cadastrado", "auth/wrong-password": "Senha incorreta", "auth/invalid-email": "E-mail inválido", "auth/invalid-credential": "E-mail ou senha incorretos" };
      mostrarMsg("erro", erros[e.code] || "Erro ao entrar");
    }
    setLoading(false);
  };

  const cadastrar = async () => {
    if (!nome || !email || !senha) return mostrarMsg("erro", "Preencha todos os campos obrigatórios");
    if (senha.length < 6) return mostrarMsg("erro", "Senha deve ter pelo menos 6 caracteres");
    if (senha !== confirma) return mostrarMsg("erro", "As senhas não coincidem");
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), senha);
      await updateProfile(cred.user, { displayName: `${nome}${creci ? ` | CRECI: ${creci}` : ""}${tel ? ` | ${tel}` : ""}` });
      mostrarMsg("ok", "Conta criada com sucesso!");
    } catch (e) {
      const erros = { "auth/email-already-in-use": "Este e-mail já está cadastrado", "auth/weak-password": "Senha muito fraca (mín. 6 caracteres)", "auth/invalid-email": "E-mail inválido" };
      mostrarMsg("erro", erros[e.code] || "Erro ao cadastrar");
    }
    setLoading(false);
  };

  const recuperar = async () => {
    if (!email) return mostrarMsg("erro", "Digite seu e-mail");
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      mostrarMsg("ok", "E-mail de recuperação enviado! Verifique sua caixa de entrada.");
      setTimeout(() => setTela("login"), 3000);
    } catch (e) {
      mostrarMsg("erro", "E-mail não encontrado");
    }
    setLoading(false);
  };

  return (
    <div style={{ background: C.bg, minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      
      {/* Logo */}
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <div style={{ width: 72, height: 72, borderRadius: 20, background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, margin: "0 auto 14px" }}>🏡</div>
        <div style={{ color: C.text, fontSize: 26, fontWeight: 900, letterSpacing: -0.5 }}>ImóvelPro</div>
        <div style={{ color: C.muted, fontSize: 13, marginTop: 4 }}>Sistema completo para corretores</div>
      </div>

      {/* Card */}
      <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 20, padding: 28, width: "100%", maxWidth: 400 }}>
        
        {/* Tabs */}
        {tela !== "recuperar" && (
          <div style={{ display: "flex", background: C.surface, borderRadius: 12, padding: 4, marginBottom: 24 }}>
            {[["login", "Entrar"], ["cadastro", "Criar Conta"]].map(([id, label]) => (
              <button key={id} onClick={() => { setTela(id); setMsg({ tipo: "", texto: "" }); }} style={{ flex: 1, padding: "10px", background: tela === id ? C.accent : "transparent", color: tela === id ? "#0A0E1A" : C.muted, border: "none", borderRadius: 10, fontWeight: 700, cursor: "pointer", fontSize: 14, transition: "all 0.2s" }}>
                {label}
              </button>
            ))}
          </div>
        )}

        {/* Mensagem */}
        {msg.texto && (
          <div style={{ background: msg.tipo === "ok" ? "#064E3B" : "#7F1D1D", color: msg.tipo === "ok" ? "#6EE7B7" : "#FCA5A5", borderRadius: 10, padding: "12px 16px", marginBottom: 16, fontSize: 13, fontWeight: 600 }}>
            {msg.tipo === "ok" ? "✅ " : "❌ "}{msg.texto}
          </div>
        )}

        {/* LOGIN */}
        {tela === "login" && (
          <>
            <Input label="E-mail" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" />
            <Input label="Senha" type="password" value={senha} onChange={setSenha} placeholder="••••••••" />
            <Btn full color="accent" onClick={login} loading={loading}>🔑 Entrar no ImóvelPro</Btn>
            <button onClick={() => { setTela("recuperar"); setMsg({ tipo: "", texto: "" }); }} style={{ background: "none", border: "none", color: C.muted, fontSize: 13, cursor: "pointer", marginTop: 16, width: "100%", textAlign: "center" }}>
              Esqueceu a senha? Recuperar acesso
            </button>
          </>
        )}

        {/* CADASTRO */}
        {tela === "cadastro" && (
          <>
            <Input label="Nome Completo *" value={nome} onChange={setNome} placeholder="Ex: João da Silva" />
            <Input label="E-mail *" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" />
            <Input label="CRECI (opcional)" value={creci} onChange={setCreci} placeholder="Ex: 12345-F" />
            <Input label="WhatsApp (opcional)" value={tel} onChange={setTel} placeholder="(11) 99999-0000" />
            <Input label="Senha * (mín. 6 caracteres)" type="password" value={senha} onChange={setSenha} placeholder="••••••••" />
            <Input label="Confirmar Senha *" type="password" value={confirma} onChange={setConfirma} placeholder="••••••••" />
            <Btn full color="green" onClick={cadastrar} loading={loading}>🚀 Criar Minha Conta</Btn>
            <p style={{ color: C.muted, fontSize: 11, textAlign: "center", marginTop: 12, lineHeight: 1.5 }}>
              Ao criar sua conta você concorda com os termos de uso do ImóvelPro.
            </p>
          </>
        )}

        {/* RECUPERAR SENHA */}
        {tela === "recuperar" && (
          <>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ fontSize: 36 }}>🔒</div>
              <div style={{ color: C.text, fontWeight: 700, fontSize: 16, marginTop: 8 }}>Recuperar Senha</div>
              <div style={{ color: C.muted, fontSize: 13, marginTop: 4 }}>Digite seu e-mail para receber o link de recuperação</div>
            </div>
            <Input label="E-mail cadastrado" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" />
            <Btn full color="accent" onClick={recuperar} loading={loading}>📧 Enviar Link de Recuperação</Btn>
            <button onClick={() => { setTela("login"); setMsg({ tipo: "", texto: "" }); }} style={{ background: "none", border: "none", color: C.muted, fontSize: 13, cursor: "pointer", marginTop: 16, width: "100%", textAlign: "center" }}>
              ← Voltar para o login
            </button>
          </>
        )}
      </div>

      <div style={{ color: C.muted, fontSize: 11, marginTop: 24, textAlign: "center" }}>
        ImóvelPro © 2025 • Todos os direitos reservados
      </div>
    </div>
  );
}
