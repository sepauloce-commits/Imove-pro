import { useState } from "react";
import { db } from "./firebase";
import { doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { tocarSomDinheiro } from "./sons";

const C = {
  bg: "#0A0E1A", card: "#111827", border: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6",
  text: "#F1F5F9", muted: "#64748B", surface: "#1E293B",
};

// ── SUBSTITUA pelo seu link real do Mercado Pago ──
const MP_LINK_PIX = "https://mpago.la/1hHDpYf";
const MP_LINK_CARTAO = "https://mpago.la/1hHDpYf";
const WHATSAPP_SUPORTE = "5585989785513";

function Btn({ children, onClick, color = "accent", full = false, style = {} }) {
  const cores = {
    accent: { bg: C.accent, text: "#0A0E1A" },
    green: { bg: C.green, text: "#fff" },
    surface: { bg: C.surface, text: C.text },
    blue: { bg: C.blue, text: "#fff" },
    red: { bg: C.red, text: "#fff" },
  };
  return (
    <button onClick={onClick} style={{
      background: cores[color].bg, color: cores[color].text,
      border: "none", borderRadius: 14, padding: "14px 24px",
      fontSize: 15, fontWeight: 700, cursor: "pointer",
      width: full ? "100%" : "auto", ...style
    }}>
      {children}
    </button>
  );
}

export default function Assinatura({ user, assinatura, onAtualizar, onSair }) {
  const [tela, setTela] = useState("planos"); // planos | pagar | aguardando
  const [metodoPag, setMetodoPag] = useState(null);
  const [codigoAtivacao, setCodigoAtivacao] = useState("");
  const [msgAtivacao, setMsgAtivacao] = useState({ tipo: "", texto: "" });
  const [ativando, setAtivando] = useState(false);

  const diasTrial = () => {
    if (!assinatura?.vencimento) return 0;
    const venc = assinatura.vencimento?.toDate?.() || new Date(assinatura.vencimento);
    const diff = Math.ceil((venc - new Date()) / (1000 * 60 * 60 * 24));
    return Math.max(0, diff);
  };

  const abrirPagamento = (metodo) => {
    setMetodoPag(metodo);
    const link = metodo === "pix" ? MP_LINK_PIX : MP_LINK_CARTAO;
    window.open(link, "_blank");
    setTela("aguardando");
  };

  const ativarCodigo = async () => {
    if (!codigoAtivacao.trim()) return setMsgAtivacao({ tipo: "erro", texto: "Digite o código de ativação" });
    setAtivando(true);
    try {
      // Verificar código no Firestore
      const { doc: docFn, getDoc } = await import("firebase/firestore");
      const codeRef = docFn(db, "codigos_ativacao", codigoAtivacao.trim().toUpperCase());
      const codeSnap = await getDoc(codeRef);

      if (!codeSnap.exists()) {
        setMsgAtivacao({ tipo: "erro", texto: "Código inválido ou expirado" });
        setAtivando(false);
        return;
      }

      const codeData = codeSnap.data();
      if (codeData.usado) {
        setMsgAtivacao({ tipo: "erro", texto: "Este código já foi utilizado" });
        setAtivando(false);
        return;
      }

      // Ativar assinatura por 30 dias
      const vencimento = new Date();
      vencimento.setDate(vencimento.getDate() + 30);

      const { updateDoc: updFn } = await import("firebase/firestore");
      await updFn(docFn(db, "assinaturas", user.uid), {
        status: "ativa",
        plano: "mensal",
        vencimento,
        ativadoEm: serverTimestamp(),
        codigoUsado: codigoAtivacao.trim().toUpperCase(),
      });

      // Marcar código como usado
      await updFn(codeRef, { usado: true, usadoPor: user.uid, usadoEm: serverTimestamp() });

      tocarSomDinheiro(); // 💰 Cha-ching! Assinatura ativada
      setMsgAtivacao({ tipo: "ok", texto: "✅ Assinatura ativada com sucesso!" });
      setTimeout(() => onAtualizar(), 1500);
    } catch (e) {
      setMsgAtivacao({ tipo: "erro", texto: "Erro ao ativar. Tente novamente." });
    }
    setAtivando(false);
  };

  const abrirSuporte = () => {
    const msg = `Olá! Acabei de realizar o pagamento do ImóvelPro.\nE-mail: ${user.email}\nNome: ${user.displayName || ""}`;
    window.open(`https://wa.me/${WHATSAPP_SUPORTE}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  return (
    <div style={{ background: C.bg, minHeight: "100vh", fontFamily: "'Segoe UI', system-ui, sans-serif", padding: "24px 16px" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 40, height: 40, borderRadius: 12, background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🏡</div>
          <div style={{ color: C.text, fontWeight: 900, fontSize: 18 }}>ImóvelPro</div>
        </div>
        <button onClick={onSair} style={{ background: C.surface, border: "none", borderRadius: 10, padding: "8px 14px", color: C.muted, fontSize: 13, cursor: "pointer" }}>Sair</button>
      </div>

      {tela === "planos" && (
        <>
          {/* Banner trial */}
          {assinatura?.status === "trial" && diasTrial() > 0 && (
            <div style={{ background: "linear-gradient(135deg, #064E3B, #065F46)", border: `1px solid ${C.green}`, borderRadius: 16, padding: 16, marginBottom: 24, textAlign: "center" }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>🎉</div>
              <div style={{ color: C.green, fontWeight: 800, fontSize: 16 }}>Período de teste ativo!</div>
              <div style={{ color: "#6EE7B7", fontSize: 13, marginTop: 4 }}>Você tem <strong>{diasTrial()} dias</strong> grátis restantes</div>
            </div>
          )}

          {assinatura?.status !== "trial" && (
            <div style={{ background: "#3B0000", border: `1px solid ${C.red}`, borderRadius: 16, padding: 16, marginBottom: 24, textAlign: "center" }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>⚠️</div>
              <div style={{ color: C.red, fontWeight: 800, fontSize: 16 }}>Assinatura vencida</div>
              <div style={{ color: "#FCA5A5", fontSize: 13, marginTop: 4 }}>Renove para continuar usando o ImóvelPro</div>
            </div>
          )}

          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <div style={{ color: C.text, fontSize: 22, fontWeight: 900 }}>Assine e venda mais</div>
            <div style={{ color: C.muted, fontSize: 14, marginTop: 6 }}>Ferramentas completas para corretores de imóveis</div>
          </div>

          {/* Card de plano */}
          <div style={{ background: C.card, border: `2px solid ${C.accent}`, borderRadius: 20, padding: 24, marginBottom: 20, position: "relative" }}>
            <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: C.accent, color: "#0A0E1A", borderRadius: 20, padding: "4px 16px", fontSize: 12, fontWeight: 800 }}>MAIS POPULAR</div>

            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div style={{ color: C.muted, fontSize: 13, marginBottom: 4 }}>Plano Profissional</div>
              <div style={{ color: C.text, fontSize: 42, fontWeight: 900, lineHeight: 1 }}>R$ 49</div>
              <div style={{ color: C.muted, fontSize: 14 }}>/mês</div>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 }}>
              {[
                "🏠 Cadastro ilimitado de imóveis",
                "👥 Gestão de clientes (CRM)",
                "🏦 Acompanhamento bancário",
                "🧮 Calculadora de financiamento",
                "💰 Controle de comissões",
                "📊 Avaliação de imóveis",
                "📄 Checklist de documentos",
                "💵 Financeiro completo",
                "☁️ Dados na nuvem (Firebase)",
                "📱 App instalável no celular",
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ color: C.green, fontSize: 16 }}>✓</span>
                  <span style={{ color: C.text, fontSize: 14 }}>{item}</span>
                </div>
              ))}
            </div>

            <Btn full color="accent" onClick={() => setTela("pagar")}>💳 Assinar Agora — R$ 49/mês</Btn>
          </div>

          {/* Código de ativação */}
          <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 20, marginBottom: 20 }}>
            <div style={{ color: C.text, fontWeight: 700, fontSize: 15, marginBottom: 4 }}>🔑 Tenho um código de ativação</div>
            <div style={{ color: C.muted, fontSize: 12, marginBottom: 14 }}>Se você recebeu um código, insira abaixo para ativar sua assinatura</div>
            <div style={{ display: "flex", gap: 8 }}>
              <input
                value={codigoAtivacao}
                onChange={e => setCodigoAtivacao(e.target.value.toUpperCase())}
                placeholder="Ex: IMOPRO-XXXX"
                style={{ flex: 1, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: "11px 14px", color: C.text, fontSize: 14, outline: "none", letterSpacing: 1 }}
              />
              <button onClick={ativarCodigo} disabled={ativando} style={{ background: C.green, border: "none", borderRadius: 10, padding: "11px 18px", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
                {ativando ? "..." : "Ativar"}
              </button>
            </div>
            {msgAtivacao.texto && (
              <div style={{ marginTop: 10, color: msgAtivacao.tipo === "ok" ? C.green : C.red, fontSize: 13, fontWeight: 600 }}>
                {msgAtivacao.texto}
              </div>
            )}
          </div>

          <div style={{ color: C.muted, fontSize: 12, textAlign: "center", lineHeight: 1.6 }}>
            Dúvidas? Fale com o suporte via WhatsApp
            <br />
            <button onClick={abrirSuporte} style={{ background: "none", border: "none", color: "#25D366", fontSize: 13, fontWeight: 700, cursor: "pointer", marginTop: 4 }}>💬 Abrir WhatsApp</button>
          </div>
        </>
      )}

      {tela === "pagar" && (
        <>
          <button onClick={() => setTela("planos")} style={{ background: "none", border: "none", color: C.muted, fontSize: 14, cursor: "pointer", marginBottom: 24, display: "flex", alignItems: "center", gap: 6 }}>
            ← Voltar
          </button>

          <div style={{ textAlign: "center", marginBottom: 28 }}>
            <div style={{ color: C.text, fontSize: 20, fontWeight: 900 }}>Escolha a forma de pagamento</div>
            <div style={{ color: C.muted, fontSize: 14, marginTop: 6 }}>Plano Profissional — R$ 49/mês</div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {/* PIX */}
            <button onClick={() => abrirPagamento("pix")} style={{ background: C.card, border: `1px solid #00B894`, borderRadius: 18, padding: 20, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{ width: 52, height: 52, background: "#00B894", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0 }}>◆</div>
              <div>
                <div style={{ color: C.text, fontWeight: 800, fontSize: 16 }}>Pix</div>
                <div style={{ color: "#00B894", fontSize: 13, fontWeight: 600 }}>Aprovação imediata</div>
                <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>Pague com QR Code ou chave Pix</div>
              </div>
            </button>

            {/* Cartão */}
            <button onClick={() => abrirPagamento("cartao")} style={{ background: C.card, border: `1px solid ${C.blue}`, borderRadius: 18, padding: 20, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{ width: 52, height: 52, background: C.blue, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0 }}>💳</div>
              <div>
                <div style={{ color: C.text, fontWeight: 800, fontSize: 16 }}>Cartão de Crédito</div>
                <div style={{ color: C.blue, fontSize: 13, fontWeight: 600 }}>Parcelamento disponível</div>
                <div style={{ color: C.muted, fontSize: 12, marginTop: 2 }}>Visa, Mastercard, Elo e mais</div>
              </div>
            </button>
          </div>

          <div style={{ marginTop: 20, color: C.muted, fontSize: 12, textAlign: "center" }}>
            🔒 Pagamento seguro via Mercado Pago
          </div>
        </>
      )}

      {tela === "aguardando" && (
        <>
          <div style={{ textAlign: "center", padding: "40px 0" }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>{metodoPag === "pix" ? "◆" : "💳"}</div>
            <div style={{ color: C.text, fontSize: 20, fontWeight: 900, marginBottom: 8 }}>Aguardando pagamento</div>
            <div style={{ color: C.muted, fontSize: 14, lineHeight: 1.6, marginBottom: 32 }}>
              {metodoPag === "pix"
                ? "Complete o pagamento via Pix na janela que abriu. Após confirmação, entre em contato via WhatsApp para ativar seu acesso."
                : "Complete o pagamento na janela que abriu. Após confirmação, entre em contato via WhatsApp para ativar seu acesso."
              }
            </div>

            <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 20, marginBottom: 24, textAlign: "left" }}>
              <div style={{ color: C.text, fontWeight: 700, marginBottom: 12 }}>Após o pagamento:</div>
              {["1. Tire um print do comprovante", "2. Entre em contato via WhatsApp abaixo", "3. Envie o comprovante e seu e-mail", "4. Acesso liberado em até 10 minutos"].map((s, i) => (
                <div key={i} style={{ color: C.muted, fontSize: 13, marginBottom: 8 }}>{s}</div>
              ))}
            </div>

            <Btn full color="green" onClick={abrirSuporte} style={{ marginBottom: 12 }}>💬 Enviar Comprovante no WhatsApp</Btn>
            <Btn full color="surface" onClick={() => setTela("planos")}>← Voltar</Btn>

            <div style={{ marginTop: 20 }}>
              <div style={{ color: C.muted, fontSize: 12, marginBottom: 10 }}>Já tem código de ativação?</div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  value={codigoAtivacao}
                  onChange={e => setCodigoAtivacao(e.target.value.toUpperCase())}
                  placeholder="IMOPRO-XXXX"
                  style={{ flex: 1, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: "11px 14px", color: C.text, fontSize: 14, outline: "none" }}
                />
                <button onClick={ativarCodigo} style={{ background: C.green, border: "none", borderRadius: 10, padding: "11px 18px", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
                  Ativar
                </button>
              </div>
              {msgAtivacao.texto && (
                <div style={{ marginTop: 8, color: msgAtivacao.tipo === "ok" ? C.green : C.red, fontSize: 13 }}>
                  {msgAtivacao.texto}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
