/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║        ImóvelPro — Webhook WhatsApp → Leads IA          ║
 * ║  Compatível com: Z-API e Evolution API                  ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * DEPLOY:
 *   npm install -g firebase-tools
 *   firebase login
 *   firebase init functions   (selecione o projeto imove-pro-4d827)
 *   cd functions && npm install
 *   firebase deploy --only functions
 *
 * VARIÁVEIS DE AMBIENTE (configure antes do deploy):
 *   firebase functions:config:set anthropic.key="SUA_CHAVE_ANTHROPIC"
 *   firebase functions:config:set corretor.uid="eugenio-lima-corretor"
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();
const db = admin.firestore();

// ── Palavras-chave para pré-filtragem rápida (evita chamar IA p/ mensagens irrelevantes) ──
const KEYWORDS = [
  "casa", "apart", "apto", "imóvel", "imovel", "terreno", "lote", "sobrado",
  "kitnet", "studio", "cobertura", "sala", "comercial", "galpão", "chácara",
  "sítio", "venda", "compra", "aluguel", "locação", "aluga", "vende", "compro",
  "procuro", "quero", "busco", "quarto", "suite", "suíte", "banheiro", "garagem",
  "condomínio", "financiamento", "m²", "m2", "área", "valor", "preço", "corretor",
  "imobiliária", "fgts", "meireles", "aldeota", "varjota", "cocó", "pinheiro",
];

function pareceImobiliario(texto) {
  const lower = (texto || "").toLowerCase();
  return KEYWORDS.some(kw => lower.includes(kw));
}

// ── Chama a IA Claude para classificar e extrair dados do lead ──
async function classificarComIA(mensagem, remetente) {
  const ANTHROPIC_KEY = functions.config().anthropic?.key;
  if (!ANTHROPIC_KEY) throw new Error("Chave Anthropic não configurada.");

  const prompt = `Você é um assistente de corretor de imóveis. Analise esta mensagem de WhatsApp e determine se ela é relacionada a imóveis (compra, venda, locação, aluguel, terrenos, lotes, casas, apartamentos, etc).

Mensagem: "${mensagem}"
Remetente: "${remetente}"

Se for imobiliária, extraia os dados. Retorne APENAS um JSON (sem markdown):
{
  "ehImobiliario": true,
  "nome": "nome do remetente ou vazio",
  "telefone": "telefone extraído ou vazio",
  "tipoNegocio": "Compra" | "Venda" | "Locação" | "Indefinido",
  "tipoImovel": "Casa" | "Apartamento" | "Terreno" | "Lote" | "Comercial" | "Outro" | "Indefinido",
  "interesse": "resumo do interesse (max 60 chars)",
  "valorEstimado": numero ou 0,
  "bairro": "bairro mencionado ou vazio",
  "observacoes": "pontos relevantes (max 100 chars)",
  "urgencia": "Alta" | "Normal" | "Baixa"
}

Se não for imobiliária: {"ehImobiliario": false}`;

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001", // Haiku = rápido e barato para classificação
      max_tokens: 300,
      messages: [{ role: "user", content: prompt }],
    }),
  });

  const data = await res.json();
  const text = data.content?.[0]?.text || "{}";
  try {
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch {
    return { ehImobiliario: false };
  }
}

// ── Normaliza payload dos diferentes provedores ──
function normalizarPayload(body) {
  // Z-API
  if (body.phone !== undefined && body.text !== undefined) {
    return {
      remetente: String(body.phone),
      mensagem: body.text?.message || body.text || "",
      tipo: body.type || "text",
      fromMe: body.fromMe || false,
    };
  }

  // Evolution API
  if (body.data?.key !== undefined) {
    const msg = body.data;
    const texto =
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      "";
    return {
      remetente: msg.key?.remoteJid?.replace("@s.whatsapp.net", "") || "",
      mensagem: texto,
      tipo: body.event || "messages.upsert",
      fromMe: msg.key?.fromMe || false,
    };
  }

  // Fallback genérico
  return {
    remetente: body.from || body.phone || body.sender || "desconhecido",
    mensagem: body.body || body.message || body.text || "",
    tipo: "text",
    fromMe: false,
  };
}

// ── Webhook principal ──
exports.whatsappWebhook = functions
  .region("us-central1")
  .https.onRequest(async (req, res) => {

    // Aceita GET (verificação do webhook)
    if (req.method === "GET") {
      return res.status(200).json({ status: "ok", service: "ImóvelPro WhatsApp Leads" });
    }

    if (req.method !== "POST") {
      return res.status(405).json({ error: "Método não permitido" });
    }

    try {
      const body = req.body;
      const { remetente, mensagem, tipo, fromMe } = normalizarPayload(body);

      // Ignora mensagens enviadas pelo próprio número
      if (fromMe) return res.status(200).json({ skip: "fromMe" });

      // Ignora mensagens vazias ou sem texto
      if (!mensagem || mensagem.trim().length < 5) {
        return res.status(200).json({ skip: "empty" });
      }

      // Busca UID do corretor configurado
      const CORRETOR_UID = functions.config().corretor?.uid || "eugenio-lima-corretor";

      // Pré-filtragem por palavras-chave (economiza chamadas à IA)
      const passouFiltro = pareceImobiliario(mensagem);

      let classificacao = { ehImobiliario: false };

      if (passouFiltro) {
        // Classifica com IA
        classificacao = await classificarComIA(mensagem, remetente);
      }

      // Salva o log da mensagem (sempre, para auditoria)
      await db.collection("whatsapp_log").add({
        uid: CORRETOR_UID,
        remetente,
        mensagem,
        tipo,
        passouFiltroKeyword: passouFiltro,
        classificadoComoLead: classificacao.ehImobiliario,
        criadoEm: admin.firestore.FieldValue.serverTimestamp(),
        payloadOriginal: JSON.stringify(body).substring(0, 500),
      });

      // Se for lead imobiliário, salva para o app processar
      if (classificacao.ehImobiliario) {
        await db.collection("whatsapp_leads").add({
          uid: CORRETOR_UID,
          remetente,
          nome: classificacao.nome || remetente,
          telefone: classificacao.telefone || remetente,
          mensagemOriginal: mensagem,
          tipoNegocio: classificacao.tipoNegocio || "Indefinido",
          tipoImovel: classificacao.tipoImovel || "Indefinido",
          interesse: classificacao.interesse || "",
          valorEstimado: Number(classificacao.valorEstimado) || 0,
          bairro: classificacao.bairro || "",
          observacoes: classificacao.observacoes || "",
          urgencia: classificacao.urgencia || "Normal",
          status: "pendente",
          origem: "whatsapp_automatico",
          criadoEm: admin.firestore.FieldValue.serverTimestamp(),
        });

        console.log(`✅ Lead criado: ${remetente} — ${classificacao.interesse}`);
        return res.status(200).json({ lead: true, interesse: classificacao.interesse });
      }

      return res.status(200).json({ lead: false, skip: "nao_imobiliario" });

    } catch (err) {
      console.error("Erro no webhook:", err);
      return res.status(500).json({ error: err.message });
    }
  });
