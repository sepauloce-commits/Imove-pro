# 📱 ImóvelPro — Guia de Instalação no Celular

## 🚀 Passo a Passo para Publicar (Vercel — GRÁTIS)

### ✅ PASSO 1 — Criar conta gratuita
1. Acesse: https://vercel.com
2. Clique em **"Sign Up"**
3. Entre com sua conta **Google** ou **GitHub**

---

### ✅ PASSO 2 — Criar conta no GitHub (se não tiver)
1. Acesse: https://github.com
2. Crie uma conta gratuita
3. Clique em **"New repository"**
4. Nome: `imovel-pro`
5. Marque como **Public**
6. Clique **"Create repository"**

---

### ✅ PASSO 3 — Subir os arquivos
1. Na página do repositório criado, clique em **"uploading an existing file"**
2. Arraste **TODOS os arquivos** desta pasta para o GitHub
3. Clique em **"Commit changes"**

**Estrutura de arquivos que você deve enviar:**
```
imovel-pro/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── main.jsx
│   └── App.jsx
└── public/
    ├── icon-192.png
    ├── icon-512.png
    └── favicon.ico
```

---

### ✅ PASSO 4 — Publicar na Vercel
1. Acesse: https://vercel.com/new
2. Clique em **"Import Git Repository"**
3. Selecione seu repositório `imovel-pro`
4. A Vercel detecta automaticamente que é **Vite**
5. Clique em **"Deploy"**
6. Aguarde ~2 minutos
7. Pronto! Você recebe um link tipo: `https://imovel-pro.vercel.app`

---

### ✅ PASSO 5 — Instalar no celular

#### 📱 Android (Chrome):
1. Abra o link no **Chrome**
2. Aparece banner **"Adicionar à tela inicial"** — toque nele
3. Ou: toque nos **3 pontinhos** → "Adicionar à tela inicial"
4. O app aparece como ícone na tela inicial! ✅

#### 🍎 iPhone (Safari):
1. Abra o link no **Safari** (obrigatório, não Chrome)
2. Toque no ícone de **compartilhar** (quadrado com seta)
3. Role para baixo → **"Adicionar à Tela de Início"**
4. Toque em **"Adicionar"**
5. O app aparece como ícone na tela inicial! ✅

---

## 💡 Dicas

- O app funciona **offline** após instalado
- Atualizações aparecem automaticamente
- Parece um app nativo, sem barra do navegador
- Você pode compartilhar o link com outros corretores

---

## 🆘 Precisa de ajuda?

Se travar em algum passo, tire print da tela de erro
e peça ajuda ao Claude mostrando onde parou.
