# 📱 Guia de Integração WhatsApp → Leads IA

## O que foi adicionado

- **Nova aba "📱 WhatsApp"** dentro do CRM (Leads)
- **Firebase Function** (`functions/index.js`) que recebe mensagens via webhook
- **IA Claude** classifica automaticamente cada mensagem recebida
- **Monitor em tempo real** — leads aparecem no app instantaneamente
- **Simulador de teste** para testar a IA sem precisar do webhook

---

## Fluxo completo

```
Mensagem chega no seu WhatsApp
        ↓
Z-API ou Evolution API detecta
        ↓
Envia para o webhook (Firebase Function)
        ↓
Pré-filtro por palavras-chave imobiliárias
        ↓
IA Claude analisa e extrai dados do lead
        ↓
Lead aparece em "📱 WhatsApp → Pendentes"
        ↓
Você aperta "✅ Enviar para CRM"
        ↓
Lead entra no Pipeline do CRM 🎯
```

---

## Passo 1 — Deploy do Webhook (Firebase Functions)

```bash
# Instale as ferramentas Firebase (se ainda não tiver)
npm install -g firebase-tools

# Faça login
firebase login

# Na raiz do projeto, inicialize as functions
firebase init functions
# Escolha: Use an existing project → imove-pro-4d827
# Linguagem: JavaScript
# ESLint: Não
# Instalar dependências: Sim

# Entre na pasta functions e instale as dependências
cd functions
npm install

# Configure sua chave da API Anthropic
firebase functions:config:set anthropic.key="SUA_CHAVE_AQUI"
firebase functions:config:set corretor.uid="eugenio-lima-corretor"

# Faça o deploy
firebase deploy --only functions
```

Após o deploy, você terá a URL:
```
https://us-central1-imove-pro-4d827.cloudfunctions.net/whatsappWebhook
```

---

## Passo 2 — Escolha seu provedor WhatsApp

### Opção A: Z-API (mais fácil, R$70/mês)

1. Acesse **app.z-api.io** e crie uma conta
2. Crie uma nova instância
3. Conecte seu WhatsApp pelo QR Code
4. Vá em **Webhooks** → **Ao receber mensagem**
5. Cole a URL do webhook e salve
6. Copie o **Instance ID** e o **Token** para configurar no app

### Opção B: Evolution API (gratuito, self-hosted)

**Deploy fácil no Railway:**
1. Acesse **railway.app** e crie conta
2. Novo projeto → Deploy from GitHub → `EvolutionAPI/evolution-api`
3. Configure a variável `AUTHENTICATION_API_KEY` com uma senha sua
4. Acesse a URL gerada + `/instance/create` para criar instância
5. Conecte pelo QR Code em `/instance/qrcode/{instance}`
6. Configure o webhook em `/webhook/set/{instance}`:
   ```json
   {
     "url": "https://us-central1-imove-pro-4d827.cloudfunctions.net/whatsappWebhook",
     "webhook_by_events": true,
     "events": ["MESSAGES_UPSERT"]
   }
   ```

---

## Passo 3 — Configurar no App

1. Abra o app → **CRM (Leads)** → aba **📱 WhatsApp**
2. Vá em **⚙️ Config**
3. Escolha seu provedor (Z-API ou Evolution)
4. Preencha as credenciais
5. Clique em **🔍** para testar a conexão
6. Copie a URL do Webhook e configure no seu provedor

---

## Passo 4 — Testar

1. Na aba **🧪 Testar IA**, digite uma mensagem simulada:
   > "Oi, estou procurando um apartamento de 3 quartos no Meireles, até 600 mil, pode ser financiado"

2. Clique em **✨ Testar com IA**
3. O lead aparecerá na aba **📨 Monitor → Pendentes**
4. Clique **✅ Enviar para CRM**

---

## Regras do Firestore (adicionar no Console Firebase)

```json
{
  "rules_version": "2",
  "service": "cloud.firestore",
  "match": /databases/{database}/documents {
    match /whatsapp_leads/{doc} {
      allow read, write: if request.auth != null;
    }
    match /whatsapp_log/{doc} {
      allow read: if request.auth != null;
      allow write: if true; // webhook sem autenticação
    }
    match /config_whatsapp/{doc} {
      allow read, write: if request.auth != null;
    }
  }
}
```

---

## Como obter sua chave da API Anthropic

1. Acesse **console.anthropic.com**
2. Vá em **API Keys** → **Create Key**
3. Copie a chave (começa com `sk-ant-...`)
4. Use no comando `firebase functions:config:set anthropic.key="sk-ant-..."`

---

## Custo estimado

| Serviço | Custo |
|---------|-------|
| Z-API | R$70/mês |
| Evolution API | Gratuito (Railway ~$5/mês) |
| Firebase Functions | Gratuito até 2M chamadas/mês |
| Claude Haiku (IA) | ~$0.001 por mensagem classificada |
| **Total (Z-API)** | **~R$75/mês** |
| **Total (Evolution)** | **~R$30/mês** |

---

## Suporte

Qualquer dúvida na configuração, abra a aba **🧪 Testar IA** no app
e simule mensagens para verificar se a IA está classificando corretamente
antes de ativar o webhook de produção.
