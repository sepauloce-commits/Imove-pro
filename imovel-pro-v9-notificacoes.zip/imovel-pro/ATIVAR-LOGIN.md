# 🔐 Ativar Login no Firebase

## PASSO OBRIGATÓRIO — Ativar autenticação por e-mail

1. Acesse: https://console.firebase.google.com
2. Clique no projeto **imove-pro-19810**
3. No menu esquerdo → clique em **"Authentication"** (ou Bancos de dados → Authentication)
4. Clique em **"Primeiros passos"** ou **"Get started"**
5. Clique em **"E-mail/senha"** (Email/Password)
6. Ative o **primeiro toggle** (E-mail/Senha)
7. Clique em **"Salvar"**

✅ Pronto! Agora o login vai funcionar.

---

## PASSO 2 — Criar índice no Firestore (necessário para busca por usuário)

1. No Firebase → **Firestore Database** → **Índices**
2. Clique em **"Criar índice"**
3. Crie 3 índices (um para cada coleção):

**Imóveis:**
- Coleção: imoveis
- Campo 1: uid (Crescente)
- Campo 2: createdAt (Decrescente)

**Clientes:**
- Coleção: clientes  
- Campo 1: uid (Crescente)
- Campo 2: createdAt (Decrescente)

**Processos:**
- Coleção: processos
- Campo 1: uid (Crescente)
- Campo 2: createdAt (Decrescente)

4. Aguarde alguns minutos para os índices ficarem prontos (ícone verde)

---

## Pronto! O app vai funcionar com login separado por corretor.
